---
name: re-android-native
description: "Reversing Android native libraries: ARM/ARM64 binaries, JNI conventions, NEON crypto, static/dynamic registration, and unpacking native protections. Use this skill when an app's core logic lives in a .so file and you need to analyze or hook it."
---

# Android Native Reversing

## Overview

Android `.so` files are ELF for ARM/AArch64, usually stripped, linked against `libc` (bionic). Logic hides here to defeat Java-level analysis.

## Orientation

```bash
file lib/arm64-v8a/libfoo.so
readelf -d libfoo.so | grep NEEDED
readelf -s libfoo.so | head -20          # stripped? dynsym survives
nm -D libfoo.so | grep -E "Java_|JNI_OnLoad"
```

## JNI conventions

Static registration: exported `Java_<mangled_pkg>_<Class>_<method>`.

```c
JNIEXPORT jboolean JNICALL Java_com_target_Native_check(JNIEnv* env, jobject thiz, jstring s);
```

Mangling: `_` → `_1`, `.` → `_`, `/` → `_`.

Dynamic registration: `JNI_OnLoad` calls `RegisterNatives` with a table:

```c
static JNINativeMethod methods[] = {
  {"check", "(Ljava/lang/String;)Z", (void*)check_impl},
};
```

Find the table in `.data.rel.ro`, then the function pointers.

## Analysis

```bash
# IDA or Ghidra: load as AARCH64 little-endian
# radare2 quick pass
r2 -A libfoo.so
> afl~check
> pdf @ sym.Java_com_target_Native_check
```

Bionic-specific: no `libpthread` (merged), TLS access via `__aeabi_read_tp`, `pthread_create` in libc.

## Crypto patterns

AArch64 AES: `aese`, `aesd`, `aesmc`, `aesimc`. SHA: `sha256h`, `sha256su0`. If you see those, the binary uses hardware crypto — the key schedule is the interesting part.

NEON: `ld1`, `st1`, `eor v0.16b` — a byte-wise XOR loop over 16 bytes is usually a stream cipher or an obfuscation layer.

## Unpacking native protectors

Signals: high entropy `.text`, `mmap(PROT_EXEC)` early, `mprotect` loops, custom linker.

```javascript
// Frida: catch every mprotect that makes a region executable, then dump it
const mp = Module.findExportByName(null, "mprotect");
Interceptor.attach(mp, {
  onEnter(a) {
    const prot = a[2].toInt32();
    if (prot & 0x4) console.log("RX:", a[0], a[1]);
  }
});
```

Dump the region after decryption with `Memory.readByteArray` after a delay, then verify the recovered ELF header.

## Hooking

```javascript
// offset-based hook on a stripped .so
const base = Module.findBaseAddress("libfoo.so");
Interceptor.attach(base.add(0x4A2C), {
  onEnter(args) { console.log("r0", args[0], "r1", args[1]); },
  onLeave(ret) { console.log("ret", ret); }
});
```

ARM64 arguments: `args[0..7]` map to `x0..x7`.

## Emulation of one function

```python
# Unicorn ARM64
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM
uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
```

Map the `.so` segments at their `p_vaddr`, set `x0` to the input pointer, run. JNI calls must be stubbed.

## Pitfalls

- ARM Thumb does not exist on AArch64; if the loader says Thumb you are looking at ARM32.
- Function pointers in `RegisterNatives` tables are relocated at load — use the runtime value, not the file offset.
- PAC/BTI (`paciasp`, `bti c`) on Android 12+ binaries confuses naive hooking; Frida handles it.

## Verification

Calling the native method from Java with a known input returns the same value your analysis predicts.
