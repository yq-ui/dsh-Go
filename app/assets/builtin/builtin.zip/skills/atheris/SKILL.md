---
name: atheris
description: "Fuzzing Python code with Atheris: writing harnesses, using sanitizers, and finding bugs in Python and native extensions. Use this skill when the target is Python code or a Python C extension."
---

# Atheris

## Overview

Atheris is libFuzzer for Python. It fuzzes pure Python and can catch native crashes in C extensions.

## Install and run

```bash
pip install atheris
python3 fuzz.py -max_total_time=60
```

## Harness

```python
import atheris, sys

def test_one_input(data: bytes):
    fdp = atheris.FuzzedDataProvider(data)
    s = fdp.ConsumeUnicodeNoSurrogates(64)
    n = fdp.ConsumeIntInRange(0, 1000)
    target(s, n)

atheris.Setup(sys.argv, test_one_input)
atheris.Fuzz()
```

## Consuming typed data

```python
fdp = atheris.FuzzedDataProvider(data)
fdp.ConsumeInt(4)
fdp.ConsumeIntInRange(1, 100)
fdp.ConsumeBool()
fdp.ConsumeBytes(32)
fdp.ConsumeUnicode(16)
fdp.ConsumeRegularFloat()
fdp.ConsumeRemainingBytes()
```

## Coverage

```bash
# bytecode coverage needs the tracer
python3 fuzz.py -print_final_stats=1
```

Native extensions:

```bash
# build the extension with ASAN or run with libdislocator
LD_PRELOAD=libdislocator.so python3 fuzz.py
```

## Catching exceptions

By default Atheris treats uncaught exceptions as findings. Filter expected ones:

```python
def test_one_input(data):
    try:
        target(data)
    except ValueError:
        return
```

## Structure-aware input via protobuf

```python
import atheris
from my_pb2 import Msg

def test_one_input(data):
    m = Msg()
    try:
        m.ParseFromString(data)
    except Exception:
        return
    handle(m)
```

## Pitfalls

- Pure-Python fuzzing is slow; restrict the input space with `ConsumeIntInRange`.
- Global mutable state persists between iterations — reset it in the harness.
- `-max_total_time` alone may not be enough; check the corpus grows.

## Verification

A reported crash must reproduce by running the harness with the saved input file.
