---
name: specialized-file-analyzer
description: "Analyzing non-executable and uncommon file formats encountered in reverse engineering: archives, databases, documents, game asset containers, save files, and custom binary formats. Use this skill when the artifact is a data file rather than code and you need to parse its structure."
---

# Specialized File Analysis

## Overview

Most RE targets ship data: containers, saves, configs, assets. The method is the same as binaries — find the magic, the length fields, and the pointers — but the tools are different.

## First pass

```bash
file sample.bin
xxd sample.bin | head -40
binwalk sample.bin           # embedded signatures, compression, filesystems
ent sample.bin               # entropy profile
strings -a -n 8 sample.bin | head -30
```

`binwalk -e` carves embedded payloads. `binwalk -E` plots entropy — a sudden drop marks a compressed or encrypted region boundary.

## Structural inference

1. **Magic.** First 4–8 bytes repeated across samples of the same type.
2. **Lengths.** Look for a 32-bit value equal to the remaining file size, then a 32-bit count followed by that many records.
3. **Alignment.** Records usually start at 4/8/16-byte boundaries; misalignment means a wrong field width.
4. **Pointers.** In containers, 32-bit or 64-bit values that, added to a base, land on a recognizable structure.

## Common formats

| Magic | Format |
|---|---|
| `PK\x03\x04` | ZIP (and any ZIP-based: docx, xlsx, apk, jar) |
| `\x1f\x8b` | gzip |
| `7z\xbc\xaf` | 7-Zip |
| `Rar!\x1a\x07` | RAR |
| `SQLite format 3\0` | SQLite database |
| `\x89PNG` | PNG (chunks: length, type, data, crc) |
| `DDS ` | DDS texture |
| `UnityFS\0` | Unity asset bundle |
| `\x00\x00\x00\x00` + ASCII header | many game containers |
| `BZh` | bzip2 |
| `\x28\xb5\x2f\xfd` | Zstandard |
| `\x04\x22\x4d\x18` | LZ4 frame |

## Parsing ZIP-family

```python
import zipfile
z = zipfile.ZipFile("sample.apk")
for i in z.infolist():
    print(i.filename, i.file_size, i.compress_type)
```

Encrypted entries: check the general-purpose bit flag `0x1`; AES-ZIP uses `0x63` in the extra field.

## Parsing SQLite

```bash
sqlite3 app.db ".tables"
sqlite3 app.db ".schema users"
sqlite3 -header -csv app.db "select * from users limit 5;"
python3 -c "import sqlite3;c=sqlite3.connect('app.db');print(c.execute('select name from sqlite_master').fetchall())"
```

WAL files (`-wal`) hold uncommitted pages — copy the triple (`db`, `-wal`, `-shm`) together.

## Custom binary with Kaitai

```yaml
meta:
  id: myfmt
  endian: le
seq:
  - id: magic
    contents: "MYFMT"
  - id: version
    type: u2
  - id: count
    type: u4
  - id: entries
    type: entry
    repeat: expr
    repeat-expr: count
types:
  entry:
    seq:
      - id: name_len
        type: u2
      - id: name
        type: str
        encoding: UTF-8
        size: name_len
      - id: offset
        type: u4
```

```bash
kaitai-struct-compiler -t python myfmt.ksy
```

Kaitai validates your layout: if parsing desyncs, the field widths are wrong.

## Pitfalls

- Endianness: read both interpretations until one gives sane lengths.
- Compressed-then-encrypted is common; entropy stays high after decompression attempts.
- Unicode strings often appear as UTF-16LE with interleaved nulls — `strings -e l`.

## Verification

Repack: parse the file, rebuild it byte-identically. If the rebuild matches, the layout is right.
