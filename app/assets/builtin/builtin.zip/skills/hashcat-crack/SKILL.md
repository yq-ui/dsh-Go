---
name: hashcat-crack
description: "Hash cracking with hashcat: hash mode selection, rule engines, mask attacks, and optimizing for the target hash type. Use this skill when password hashes must be recovered."
---

# Hashcat

## Overview

hashcat cracks offline. Success depends on mode selection, wordlist quality, and rules.

## Identify the hash

```bash
hashid 'aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0'
hashcat --example-hashes | grep -A3 "NTLM"
```

| Mode | Hash |
|---|---|
| 0 | MD5 |
| 100 | SHA1 |
| 1000 | NTLM |
| 1800 | sha512crypt |
| 3200 | bcrypt |
| 13100 | Kerberoast RC4 |
| 18200 | AS-REP |
| 22000 | WPA-PBKDF2-PMKID+EAPOL |
| 16500 | JWT |

## Basic

```bash
hashcat -m 1000 hashes.txt /usr/share/wordlists/rockyou.txt
hashcat -m 1000 hashes.txt rockyou.txt -r /usr/share/hashcat/rules/best64.rule
```

## Attack modes

```bash
-a 0   # straight (wordlist)
-a 1   # combination
-a 3   # brute force mask
-a 6   # hybrid wordlist + mask
-a 7   # hybrid mask + wordlist
```

```bash
hashcat -m 1000 h.txt -a 3 ?u?l?l?l?l?d?d?s
hashcat -m 1000 h.txt -a 6 rockyou.txt ?d?d?d?d
```

## Masks

```
?l lowercase  ?u uppercase  ?d digits  ?s symbols  ?a all  ?b bytes
```

## Rules

```bash
hashcat -m 1000 h.txt rockyou.txt -r rules/dive.rule
# custom: append a year
echo '$2$0$2$6' > y.rule
hashcat -m 1000 h.txt rockyou.txt -r y.rule
```

## Performance

```bash
hashcat -m 1000 h.txt -b            # benchmark
hashcat -m 1000 h.txt --workload-profile 4
hashcat -m 1000 h.txt -d 1,2        # specific devices
```

bcrypt (3200) is intentionally slow — expect thousands/sec at best.

## Show cracked

```bash
hashcat -m 1000 h.txt --show
```

## Potfile

`~/.hashcat/hashcat.potfile` accumulates results across runs.

## Pitfalls

- Wrong mode wastes hours. Verify with `--example-hashes`.
- Kerberoast RC4 (`13100`) is fast; AES (`19700`) is very slow.
- Rules can explode the candidate count — estimate with `--stdout | wc -l`.

## Verification

The cracked password must authenticate against the real service or verify against the hash.
