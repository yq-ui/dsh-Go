---
name: re-format-macho
description: "Mach-O format analysis: load commands, segments, sections, symbol table, dyld shared cache, chained fixups, and code signing structures. Use this skill when analyzing macOS or iOS binaries, understanding dyld behavior, or patching signed Mach-O images."
---

# Mach-O Format

## Overview

Mach-O is a header plus a variable list of load commands. `LC_SEGMENT_64` defines mapped memory; `LC_SYMTAB`, `LC_DYLD_INFO`, and `LC_DYLD_CHAINED_FIXUPS` define linking.

## Header

```c
struct mach_header_64 {
  uint32_t magic;       // 0xFEEDFACF (64-bit LE), FAT_MAGIC 0xCAFEBABE
  cpu_type_t cputype;   // CPU_TYPE_ARM64 0x0100000C, X86_64 0x01000007
  cpu_subtype_t cpusubtype;
  uint32_t filetype;    // MH_EXECUTE 2, MH_DYLIB 6, MH_BUNDLE 8, MH_KEXT_BUNDLE 11
  uint32_t ncmds, sizeofcmds, flags, reserved;
};
```

## Load commands that matter

| Command | Purpose |
|---|---|
| `LC_SEGMENT_64` | `__TEXT`, `__DATA`, `__LINKEDIT` mapping |
| `LC_MAIN` | entrypoint as file offset (replaces `LC_UNIXTHREAD`) |
| `LC_LOAD_DYLIB` | linked libraries |
| `LC_SYMTAB` | symbol table + string table |
| `LC_DYLD_INFO_ONLY` | rebase, bind, weak bind, lazy bind, export trie |
| `LC_DYLD_CHAINED_FIXUPS` | modern chained pointer fixups (iOS 13+/macOS 12+) |
| `LC_CODE_SIGNATURE` | embedded signature blob |
| `LC_ENCRYPTION_INFO_64` | App Store FairPlay cryptid/cryptoff |
| `LC_FUNCTION_STARTS` | ULEB128 delta list of function starts |

## Inspect

```bash
otool -hv target          # header
otool -l target           # all load commands
otool -L target           # dylibs
otool -tV target          # disassembly
nm -m target              # symbols with source
dyld_info -fixups target  # chained fixups
codesign -dvvv target     # signature details
```

## Encrypted binaries (iOS)

`LC_ENCRYPTION_INFO_64.cryptid == 1` means the `__TEXT` segment is encrypted on disk. Decrypt at runtime: launch the app, dump the decrypted `__TEXT` from memory with Frida, then rebuild the Mach-O.

```python
# Frida sketch
import frida
s = frida.attach("App")
s.on("message", print)
s.exports_sync.__dict__
```

Dump approach: read the header at the module base, all segments, write them back at their `fileoff`, set `cryptid` to 0, then fix the signature (`ldid -S` or `codesign -s -`).

## Chained fixups

Modern binaries store pointer fixups as in-segment chains with bitfields (bind, next, addend). `dyld_info -fixups` decodes them; parsing by hand requires reading `dyld_chained_fixups_header` → `starts_in_image` → per-segment `dyld_chained_starts_in_segment.page_start[]`.

## Fat binaries

```bash
lipo -info target
lipo target -thin arm64 -output target.arm64
```

Parse: `fat_header` (`magic`, `nfat_arch`), then `fat_arch_64[]` with `cputype`, `offset`, `size`, `align`.

## Pitfalls

- `vmaddr` vs `fileoff`: addresses in disassembly are `vmaddr` based; file reads need `fileoff = vmaddr - vmaddr_seg + fileoff_seg`.
- Modifying a signed binary invalidates `LC_CODE_SIGNATURE`; re-sign or the kernel refuses to map it (macOS) / the app crashes (iOS).
- The dyld shared cache holds system libraries — no on-disk Mach-O to disassemble; extract with `dyld_shared_cache_util`.

## Verification

`otool -l` segment `fileoff+filesize` must be contiguous and end at `__LINKEDIT`; `codesign -v` passes after a re-sign.
