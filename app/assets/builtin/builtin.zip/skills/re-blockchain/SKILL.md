---
name: re-blockchain
description: "Blockchain and smart contract reversing: EVM bytecode, decompilation, storage layout, and transaction analysis. Use this skill when analyzing a smart contract or an on-chain transaction."
---

# Blockchain Reversing

## Overview

EVM bytecode is stack-based and fully public. Reversal: disassemble, recover the function selectors, map storage, then read the logic.

## Get the bytecode

```bash
cast code 0xCONTRACT --rpc-url $RPC
# or etherscan API
curl "https://api.etherscan.io/api?module=proxy&action=eth_getCode&address=0x..&apikey=.."
```

## Disassemble

```bash
pip install evmdasm
python3 -c "from evmdasm import EvmBytecode;print(EvmBytecode('0x6080...').disassemble())"
```

Better tools:

- **panoramix** (decompiler, online)
- **heimdall** (`heimdall decompile 0x...`)
- **ethervm.io** decompiler
- **Ghidra EVM plugin**

```bash
heimdall decompile 0xCONTRACT -r $RPC
heimdall disassemble 0xCONTRACT -r $RPC
```

## Function selectors

First 4 bytes of `keccak256("name(argTypes)")`.

```python
from eth_hash.auto import keccak
print(keccak(b"transfer(address,uint256)")[:4].hex())   # a9059cbb
```

The dispatcher compares `CALLDATALOAD(0)` against each selector — read the PUSH4 values in the dispatcher to enumerate functions.

```bash
# find PUSH4 constants
cast disassemble $(cast code 0x... --rpc-url $RPC) | grep PUSH4
```

## Storage layout

```bash
cast storage 0xCONTRACT 0 --rpc-url $RPC
cast storage 0xCONTRACT 1 --rpc-url $RPC
```

Solidity packs:
- Value types pack into 32-byte slots when they fit.
- Mappings: `keccak256(key . slot)`.
- Dynamic arrays: length at `slot`, data at `keccak256(slot)`.

```python
from eth_abi import encode
from eth_hash.auto import keccak
slot = 3
key = "0x000000000000000000000000" + addr[2:]
print(keccak(bytes.fromhex(key[2:]) + slot.to_bytes(32,"big")).hex())
```

## Common targets

| Target | Method |
|---|---|
| Access control | read the `owner` slot, check modifiers |
| Reentrancy | trace external calls before state updates |
| Proxy | read the implementation slot (`0x360894...` EIP-1967) |
| Delegatecall | follow the target contract |

## Transaction analysis

```bash
cast tx 0xHASH --rpc-url $RPC
cast receipt 0xHASH --rpc-url $RPC
cast 4byte-decode 0xCALLDATA
```

```bash
# trace a transaction
cast run 0xHASH --rpc-url $RPC
```

## Pitfalls

- Bytecode on chain may be a minimal proxy — resolve the implementation first.
- `selfdestruct` and `delegatecall` change control flow in ways decompilers miss.
- Constructor code is not in the deployed bytecode; get it from the creation transaction.

## Verification

A reconstructed function must produce the same state change as a real transaction calling it.
