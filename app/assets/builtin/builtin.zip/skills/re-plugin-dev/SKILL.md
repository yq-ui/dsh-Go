---
name: re-plugin-dev
description: "Writing reverse engineering plugins: IDA/Ghidra/Binary Ninja plugin architecture, UI integration, and packaging for reuse. Use this skill when an analysis task must be automated inside a reversing tool."
---

# RE Plugin Development

## Overview

A plugin extends an RE tool with an automated analysis. Choose the host by your workflow: IDA for depth, Ghidra for free/batch, Binary Ninja for API cleanliness.

## IDA plugin

```python
# myplugin.py -> %APPDATA%\Hex-Rays\IDA Pro\plugins\
import idaapi, idc, idautils

class MyPlugin(idaapi.plugin_t):
    flags = idaapi.PLUGIN_KEEP
    comment = "dump all string xrefs"
    help = ""
    wanted_name = "MyPlugin"
    wanted_hotkey = "Ctrl-Shift-D"

    def init(self):
        return idaapi.PLUGIN_KEEP

    def run(self, arg):
        for s in idautils.Strings():
            for x in idautils.XrefsTo(s.ea):
                print(hex(x.frm), s.str)

    def term(self):
        pass

def PLUGIN_ENTRY():
    return MyPlugin()
```

UI action with a form:

```python
import ida_kernwin
class Form(ida_kernwin.Form):
    def __init__(self):
        ida_kernwin.Form.__init__(self, r"STARTITEM 0
My Form
<Pattern:{s}>", {'s': ida_kernwin.Form.StringInput()})
```

## Ghidra script/plugin

Script (fast path):

```python
# scripts/DumpStrings.py
from ghidra.program.model.data import StringDataType
for s in currentProgram.getListing().getDefinedData(True):
    if s.getValue() is not None and isinstance(s.getValue(), str):
        print("{:#x} {}".format(s.getAddress().getOffset(), s.getValue()))
```

Plugin (Java, persistent):

```java
public class DumpPlugin extends ProgramPlugin {
    public DumpPlugin(PluginTool t) { super(t); }
    @Override protected void programActivated(Program p) { /* ... */ }
}
```

## Binary Ninja plugin

```python
from binaryninja import PluginCommand
def run(bv):
    for f in bv.functions:
        print(hex(f.start), f.symbol.short_name)
PluginCommand.register("Dump functions", "list", run)
```

## Packaging

- IDA: single `.py` or a package with `__init__.py`; ship dependencies in the same folder.
- Ghidra: a `.zip` with `extension.properties` for an extension, or a script dropped in the user scripts dir.
- Binary Ninja: a folder with `plugin.json` and the entry module.

## Testing

```python
# headless verification
idat -A -S"myplugin.py" target.idb       # IDA batch
analyzeHeadless /tmp/proj P -import t -postScript DumpStrings.py
```

## Pitfalls

- Blocking the UI thread in a plugin freezes the tool — run long work with `ida_kernwin.execute_sync(..., MFF_WRITE)`.
- Ghidra's Jython is Python 2.
- Binary Ninja's API changes between versions; pin the target version.

## Verification

The plugin runs twice with identical output (idempotent) and does not corrupt the database.
