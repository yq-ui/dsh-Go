---
name: re-swift
description: "Reversing Swift binaries: v5 name mangling, metadata sections, protocol witness tables, and Swift calling conventions in disassembly. Use this skill when the target is a Swift binary on Apple platforms or Linux and demangling or type recovery is required."
---

# Swift Binary Reversing

## Overview

Swift binaries carry rich metadata: type descriptors, method descriptors, protocol conformances, witness tables. Names are mangled with a documented scheme.

## Identify

```bash
otool -l app | grep -A2 swift5
nm app | grep -c '^\$s'
strings app | grep -m3 "Swift runtime"
```

Sections: `__swift5_types`, `__swift5_proto`, `__swift5_protos`, `__swift5_fieldmd`, `__swift5_reflstr`, `__swift5_assocty`, `__swift5_builtin`.

## Demangle

```bash
nm app | swift-demangle | head -20
swift-demangle '$s6Target6Crypto7decryptSSSgSSF'
```

Mangling grammar (`$s` prefix, `$s` = Swift 5):

```
$s <module-len><module> <name-len><name> ... <type-encoding> F
F = function, S = Swift.String, i = Int, s = Swift
```

`$s6Target6Crypto7decryptSSSgSSF` → `Target.Crypto.decrypt(Swift.String) -> Swift.String?`.

## Metadata

`__swift5_types` is a list of relative pointers to type descriptors. Each descriptor starts:

```c
struct ContextDescriptor {
  uint32_t flags;          // kind in low bits: 0=Class, 1=Struct, 2=Enum
  int32_t parent;
  int32_t name;            // relative pointer to mangled name
  int32_t accessFunction;
  int32_t fields;          // field descriptor
};
```

Walk it to enumerate every type and its fields. Tools: `SwiftMetadataExtractor`, `swift-reflection-dump`, Hopper's Swift support, IDA's Swift plugins.

## Witness tables

Protocol dispatch goes through `__swift5_proto` conformances. A call site looks like:

```asm
ldr x8, [x0]           ; type metadata
ldr x8, [x8, #0x50]    ; witness table pointer
ldr x9, [x8, #0x18]    ; method slot
blr x9
```

The slot index maps to the protocol's requirement order (declaration order, not alphabetical).

## Calling convention

Swift on ARM64 passes `self` in `x20` (not `x0`) for methods, and error returns use `swift_error` register (`x21` for `@convention(swift)`). For `throws` functions, the error is written to `x21` and the function returns normally.

```asm
str  x0, [x21]         ; store thrown error
```

## Pitfalls

- `swift-demangle` version must match the compiler; older tools fail on newer mangling.
- Generic specialization produces `$s...Tj...` style functions — one per concrete type.
- Objective-C interop classes appear as both ObjC and Swift metadata; do not double-count.

## Verification

A demangled symbol must match a descriptor found in `__swift5_types`, and the field offsets must match the `fieldmd` records.
