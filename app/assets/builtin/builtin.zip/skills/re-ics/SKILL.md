---
name: re-ics
description: "Industrial control systems reversing: Modbus, S7, DNP3, EtherNet/IP protocols and PLC logic analysis. Use this skill when analyzing industrial protocols, PLC programs, or OT network traffic."
---

# ICS / OT Reversing

## Overview

OT protocols are old, often unauthenticated, and function-code oriented. Analysis: identify the protocol, enumerate the device's data model, and understand the control logic.

## Protocols

| Protocol | Port | Notes |
|---|---|---|
| Modbus/TCP | 502 | function codes, register model |
| S7comm | 102 | Siemens, ISO-TSAP wrapper |
| DNP3 | 20000 | outstation/master, events |
| EtherNet/IP + CIP | 44818 | Rockwell |
| IEC 60870-5-104 | 2404 | telecontrol |
| OPC UA | 4840 | XML/binary, has security modes |
| BACnet | 47808 | building automation |

## Modbus

```
[transaction:2][protocol:2][length:2][unit:1][func:1][data...]
```

| FC | Meaning |
|---|---|
| 1/2 | read coils / discrete inputs |
| 3/4 | read holding / input registers |
| 5/6 | write single coil / register |
| 15/16 | write multiple coils / registers |
| 43 | read device identification |

```python
from pymodbus.client import ModbusTcpClient
c = ModbusTcpClient("192.168.1.10", port=502)
print(c.read_holding_registers(0, 10, unit=1))
print(c.read_coils(0, 16, unit=1))
c.write_register(100, 1234, unit=1)
```

```bash
# raw
python3 -c "import socket;s=socket.create_connection(('192.168.1.10',502));s.send(bytes.fromhex('00010000000601030000000a'));print(s.recv(256).hex())"
```

## S7comm

Wrapped in TPKT (RFC1006) + COTP. Common jobs: `0x04` read var, `0x05` write var, `0x1A` request download, `0x1D` PLC stop.

```bash
# snap7
pip install python-snap7
python3 -c "
import snap7
c = snap7.client.Client(); c.connect('192.168.1.10', 0, 1)
print(c.get_cpu_info())
print(c.db_read(1, 0, 16))
"
```

```bash
nmap -p 102 --script s7-info 192.168.1.0/24
```

## DNP3

Outstation data points via object groups. `dnp3` python lib:

```python
from pydnp3 import opendnp3, asiodnp3
# master with a integrity poll, then read the point database
```

`nmap --script dnp3-info`.

## PLC logic analysis

- **Ladder logic** in a project file (`.ap16`, `.L5X`) is readable XML or a proprietary DB.
- On a device, upload the program via the vendor tool; then read it as structured text.
- Cycles: scan time, I/O mapping, and register addresses tie logic to physical I/O.

## Network position

OT networks are typically flat and air-gapped; research must be on a lab replica (OpenPLC, PLCSIM, Conpot). Reversing a live plant is out of scope for any analysis.

## Pitfalls

- Writing to a live PLC can move machinery. Always lab-first.
- Modbus has no auth: any host that can reach port 502 can write.
- Unit ID vs slave address confusion (TCP often ignores unit ID).

## Verification

A read must return values consistent with the device's displayed state, and any write must be to a lab device.
