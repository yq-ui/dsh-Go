---
name: android-phone-fast-control
description: 在 DSH Go 手机 App 内做快速、低 token 的 Android 手机操控：优先无障碍节点而不是截图，批量执行确定性操作，只在关键状态变化后验证。Fast, low-token Android UI control on-device — accessibility nodes first, screenshots last, verify only at checkpoints.
whenToUse: 用户要求读屏、点击、输入、滑动、跨应用操作或连续多步手机任务时先加载。Also when a phone-control tool call fails with a connection / bridge error.
---

# Android 手机快速操控

本机引擎里有两套手机操控通道，先看哪套已加载，再选一套用，绝不混着来回读屏。

| 通道 | 工具名前缀 | 特点 |
| --- | --- | --- |
| DSH Go 原生（默认已装） | `mcp__phone__*` | 无障碍语义屏 + 元素编号，最省 token；打开 DSH 自己界面时拒绝读取 |
| ARC MCP（可选，装了才有） | `android_*` | 59 个工具，含节点搜索、截图、文件、应用管理 |

## 1. 先确认通道活着

- 原生：调用 `mcp__phone__screen`。返回「屏幕 sN · …」即正常。
- 报 `phone bridge unreachable` / `connect failed` 时，不是模型问题：App 侧的 bridge 没起来。检查 `$DSH_HOME/dsh-app/diagnostics.md` 里的「连接」和引擎日志；bridge 名在 `/var/lib/dsh-app/phone/bridge.json`（`abstract` 字段）。App 每次重启引擎会重写该文件，旧的 relay 指向旧 socket 即失败，重启引擎即可。
- ARC：`POST http://127.0.0.1:8080/mcp` 必须连得上；连不上说明 App 没装、没开服务，或端口被改。

## 2. 读屏规则

1. `mcp__phone__screen` 只读一次就够，编号（`[12]`）本屏有效。
2. 需要坐标才加 `detail:true`；只有看图像才能判断时才 `image:true`。
3. 读长列表用 `mcp__phone__collect`（自动翻页去重），不要循环 `scroll` + `screen`。
4. 不要为了「确认一下」重复读同一屏：工具返回的新屏幕已经是确认。

## 3. 操作规则

- 能用元素编号点，就不用坐标点。`tap_xy` 每次要用户确认，且会因布局变化失效。
- 输入框：`type` 直接替换内容，一次到位，不要逐字模拟。
- 返回/主页/最近任务：`key`，比找按钮快且稳。
- 打开应用或链接：`open`；查包名用 `apps`（可带 query 过滤），不要猜包名。
- 系统级一次性动作（闹钟、倒计时、日程、拨号、导航、设置页）走 `intent`，最后一步由用户在系统界面确认，比自己点五层菜单稳。
- 连续多步、每一步都低风险且确定性高（翻页、点下一题、批量勾选）时，一次性连做，中途不插读屏。
- 只有在这些节点之后才验证：应用切换、页面跳转、弹窗出现、提交表单、支付/确认类动作。

## 4. 敏感与不越界

- 密码、验证码、支付框：工具默认拒绝。被拒绝就 `handoff` 把手机交给用户，不要绕。
- 首次操作某个 App、或碰到敏感按钮，工具会先请用户确认；那是设计，不是故障。
- 不伪造结果：没读到的屏幕不下结论；操作失败就报告失败，不写「已完成」。
- 截图有成本，能把结论用文字说清就别截图。

## 5. 停止 / 暂停 / 恢复

- 每一步前检查用户是否要求停；用户说停就停，不再发起新操作。
- 暂停后恢复：重新读一次当前屏幕确认状态，再从断点继续，不重放已完成的步骤。

## 6. 性能记法

真实耗时只能实测：记录每次调用前后的墙钟时间（`date +%s%3N`），不要引用项目页面上的宣传数字。把「模型推理耗时」和「设备执行耗时」分开记：设备侧看工具调用往返，推理侧看两次工具调用之间的间隔。

## 7. ARC MCP（`mcp__androidrc__*`，装了才用）

本机已装 ARC 1.12.0：`com.danielealbano.androidremotecontrolmcp`，`streamable-http://127.0.0.1:8080/mcp`，Bearer token 在 `$DSH_HOME/profiles/<profile>/cordis.patch.yml` 的 `android-rc-mcp` 条目里。工具名全带前缀 `android_`，44 个，别凭记忆写。

**读屏**
- `android_get_screen_state`：返回节点表（text/desc 截断 100 字符）+ 层级 + 分页（每页 200 节点，带 cursor）。**只拉第 1 页就够**，不要为了"完整"翻页。
- `include_screenshot=true` 只在节点表说不清布局时用；截图是低分辨率，且要花一段时间。
- 节点 id 是 `node_xxxxxxxx`，只对当前这一份快照有效，屏幕一变就作废。别缓存 node_id 跨操作复用。
- 截断的文本用 `android_get_node_details` 取全文，别截着看就下判断。
- 屏幕外（`off` 标记）的节点先 `android_scroll_to_node` 再点。

**找和点**
- `android_find_nodes`（by: text/desc/res_id/class，默认 contains 忽略大小写）比全屏读省 token；知道文字就直接找。
- `android_click_node` 走 ACTION_CLICK，快，但要求节点 `clk`；不可点时用 `android_tap_node`（手势点，落在节点内随机点）。
- 坐标点击 `android_tap` 是最后手段：换布局就失效。
- `android_wait_for_node` / `android_wait_for_idle` 只在真的要等一个特定状态时用；动作类工具返回时手势已完成，别每次补一个 wait。

**打字（最大的坑）**
- `android_type_append_text` 默认 `typing_speed: 250`，即 **250ms/字**，20 个字符就是 5 秒。凡是输入超过几个字，明确给 `typing_speed: 10~30`、`typing_speed_variance: 0~10`。
- 改已有内容用 `android_type_replace_text`，清空用 `android_type_clear_text`，别 select-all + 一堆 DEL。
- 打完 `android_dismiss_keyboard` 再点被键盘盖住的元素。

**其它常用**
`android_press_back/home/recents`、`android_open_app`、`android_list_apps`、`android_scroll`、`android_swipe`、`android_send_intent`、文件那组（`android_list_storage_locations` → `android_list_files/read_file/write_file`）。

**系统权限页**：安装确认、无障碍开关、允许受限设置这类页面，ARC 也不该代点（同一套安全边界）。直接 `handoff` 交给用户，别绕。

**两套通道怎么选**：日常快读快点用 `mcp__phone__*`（一次读屏 158ms，返回带编号，最省）；需要节点搜索、等待、文件、应用管理、多指手势时用 `mcp__androidrc__*`（读屏 248ms，44 个工具）。同一屏不要两边各读一遍。

## 8. root 通道（Termux 桥，已通）

引擎跑在 proot 里：真实 uid 10455、`CapEff=0`，而 KernelSU 从不往这个 namespace 挂 su（实测 174 个挂载里 0 个 su）——`exec /system/bin/su` 永远 ENOENT。**别再重启引擎试**，那条路不通。

走 Termux 起的文件队列桥：

```
Termux:  nohup su -c 'sh /sdcard/.dshroot/bridge.sh' >/dev/null 2>&1 &
桥(uid0): 每 0.15s 扫 /sdcard/.dshroot/in/*.sh → 执行 → 结果写 out/<name>.out + .rc
```

两个客户端：

- `dshroot <cmd>`：真 root，跑文件、`screencap`、`dumpsys`、`logcat`、`getprop`。往返约 170–270 ms。
- `dshsvc <cmd>`：跑 `input` / `settings` / `pm` / `am` 用。ksu 域直接调这三个会 `Failed transaction (2147483646)`，所以它先 `setenforce 0`、`timeout` 执行、再强制 `setenforce 1`。**永远用 dshsvc，别自己关 SELinux。**

桥断了（重启手机 / Termux 被后台清理）的症状：`dshroot: no answer in 120s`。重跑 Termux 那一行即可。

`su 2000 -c` 不能让 `input`/`settings` 通过（domain 没变，实测仍拒）；`runcon u:r:shell:s0` 也只救得了 `pm`。所以别绕，用 dshsvc。

### 8.1 保活与重启（重要）

桥由 `watchdog.sh` 每 20 秒检查一次，死了就 `setsid` 拉起；两者都用 pidfile 保证单实例。实测杀掉桥后 20 秒内自动复活，客户端无感（只是那一次调用会超时）。

开机自启**不可能**：这台机没解 BL，ReSukiSU 是越狱模式（LKM + exploit），root 本身重启即失效，所以 `service.d`、LSPosed、Termux:Boot 都跑不起来。官方 Termux:Boot 还装不上（自签 Termux 与共享用户签名冲突）。

能做到的最省事方案（已部署）：`~/.bashrc` 末尾有一段 autostart，**Termux 一打开就检查 watchdog，没跑就 `su -c` 起一个**。所以重启后的流程是：

```
ReSukiSU 点「越狱」 → 打开 Termux（自动起桥）→ 完事
```

`/sdcard/.dshroot/bridge.log` 是桥与 watchdog 的启动/重启日志；`/sdcard/.dshroot/beat` 是心跳时间戳，排查是否活着先看这两个。
