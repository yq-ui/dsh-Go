---
name: re-ios
description: "iOS app reversing: IPA structure, Mach-O binaries, Objective-C and Swift metadata, class-dump, and static analysis of App Store binaries. Use this skill when analyzing iOS applications statically, recovering class interfaces, or preparing for dynamic work."
---

# iOS Reversing

## Overview

An IPA is a ZIP of `Payload/App.app/`. The main binary is Mach-O, usually encrypted (`cryptid=1`) if from the App Store. Objective-C retains extensive metadata; Swift retains mangled symbols.

## Unpack

```bash
unzip -o app.ipa -d app
ls app/Payload/*.app | head -20
file app/Payload/App.app/App
otool -l app/Payload/App.app/App | grep -A4 LC_ENCRYPTION_INFO
```

If `cryptid 1`, the binary is FairPlay-encrypted — static analysis of `__TEXT` is useless until decrypted (see `re-ios-jb`).

## Objective-C metadata

```bash
# class-dump for headers
class-dump -H App -o headers/
# modern alternative: dsdump
dsdump --objc App > all.txt
```

```bash
otool -ov App | head -100        # objc2 metadata
nm -m App | grep -i "\[.* .*\]"  # method symbols
```

Objective-C method names survive stripping because the runtime needs them. `strings` alone recovers most of the API surface.

## Swift

```bash
# demangle
nm App | xcrun swift-demangle | grep -i target
```

Swift metadata lives in `__swift5_*` sections:

```bash
otool -l App | grep -A2 swift5
```

`SwiftDemangle`/`swift-reflection-dump` recover type names. Swift symbols are mangled as `$s<module><name>...`.

## Key strings and entitlements

```bash
plutil -p app/Payload/App.app/Info.plist
codesign -d --entitlements :- app/Payload/App.app
strings -a App | grep -E "https?://|api[_-]?key|Bearer" | head -20
```

Entitlements tell you capabilities: `get-task-allow` (debuggable), `keychain-access-groups`, app groups.

## Frameworks

```bash
ls app/Payload/App.app/Frameworks/
# each is its own Mach-O; analyze independently
```

## Patching (jailbroken)

```bash
# install the app, then decrypt from memory
frida -U -f com.target.app --no-pause
# use frida-ios-dump or bagbak
python3 dump.py com.target.app
```

After dumping, `cryptid` is 0 and `__TEXT` is plaintext. Re-sign with `ldid -S` for a jailbroken device.

## Static tools

| Tool | Use |
|---|---|
| IDA / Ghidra | ARM64 disassembly, ObjC type recovery |
| Hopper | fast ObjC pseudocode |
| class-dump / dsdump | headers |
| jtool2 | Mach-O inspection, patches |
| otool / nm | quick structural checks |

## Pitfalls

- App Store binaries are encrypted — no strings, no code. Always check `cryptid` first.
- Swift name mangling changes across compiler versions; use a matching demangler.
- Bitcode is gone (Xcode 14+) but some frameworks still ship prebuilt slices.

## Verification

`class-dump` headers must list methods whose selectors appear in `strings`; jtool2 must report `cryptid 0` after dumping.
