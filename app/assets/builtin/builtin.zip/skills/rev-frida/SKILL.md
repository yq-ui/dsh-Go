---
name: rev-frida
description: "Advanced Frida instrumentation patterns: Stalker tracing, inline hooks with trampolines, CModule on-the-fly native code, and supervising child processes. Use this skill when basic Interceptor hooks are insufficient and you need instruction-level tracing or generated native code."
---

# Advanced Frida

## Overview

Beyond `Interceptor.attach`: `Stalker` traces execution, `CModule` compiles C at runtime for trampolines and fast callbacks, and `frida-gadget` embeds instrumentation without a server.

## Stalker

```javascript
const t = Stalker.follow(Process.getCurrentThreadId(), {
  events: { call: true, ret: true, exec: true, block: true },
  onReceive(events) {
    const parsed = Stalker.parse(events, { annotate: true, stringify: true });
    console.log(parsed.slice(0, 5));
  }
});
// later
Stalker.unfollow();
Stalker.flush();
```

Filtering to a module keeps the volume manageable:

```javascript
const m = Process.getModuleByName("libfoo.so");
const [lo, hi] = [m.base, m.base.add(m.size)];
Stalker.follow(Process.getCurrentThreadId(), {
  transform(iterator) {
    let ins;
    while ((ins = iterator.next()) !== null) {
      const a = ins.address;
      if (a.compare(lo) >= 0 && a.compare(hi) < 0) {
        iterator.putCallout(function (ctx) { console.log(ctx.pc); });
      }
      iterator.keep();
    }
  }
});
```

## CModule

```javascript
const cm = new CModule(`
#include <gum/guminterceptor.h>
#include <stdio.h>
void on_enter(GumInvocationContext* ctx) {
  int a = gum_invocation_context_get_nth_argument(ctx, 0);
  printf("arg0=%d\\n", a);
}
`);
const listener = Interceptor.attach(addr, { onEnter() {} });
Interceptor.attach(addr, {
  onEnter(args) { /* or use cm.on_enter via a NativeCallback wrapper */ }
});
```

CModule is the way to run heavy per-instruction logic without JS overhead. Exported symbols become `cm.symbol_name`.

## Inline hooking manually

```javascript
function hookInline(addr, replacement) {
  const orig = Memory.alloc(64);
  Memory.copy(orig, addr, 12);                    // save prologue
  const tramp = new Arm64Writer(orig.add(12), { pc: orig.add(12) });
  // ... or use Interceptor if the target is a function entry
}
Arm64Writer / X86Writer / ArmWriter let you emit a jump back.
```

Prefer `Interceptor.attach`; hand-written trampolines are for mid-function hooks.

## Hooking mid-function

`Interceptor.attach` accepts any address. To hook after the prologue, add the offset and account for the instruction being executed:

```javascript
const mid = base.add(0x1A40);   // must be an instruction boundary
Interceptor.attach(mid, { onEnter() { console.log(this.context.rax); } });
```

`this.context` in `onEnter` gives register state at that instruction.

## Child process supervision

```javascript
// frida CLI
// frida -U -f com.app --enable-spawn-gating
```

```python
dev.enable_spawn_gating()
dev.on("spawn-added", lambda s: dev.attach(s.pid).create_script(js).load())
```

## Gadget embedding

```bash
# patch an APK / IPA to auto-load a script
objection patchapk -s app.apk
# or: place libfrida-gadget.so + config in lib/ and System.loadLibrary it
```

```json
{ "interaction": { "type": "script", "path": "/data/local/tmp/hook.js" } }
```

## Performance

- `Stalker` slows execution 10–100×; scope it to a thread and a module.
- Batch `send()` calls; each crosses the JS/native boundary.
- Use `Memory.scanSync` once at startup, cache the result.

## Verification

The Stalker trace's block sequence must match a debugger single-step for the same input, and CModule hooks must log the same values as the pure-JS equivalent.
