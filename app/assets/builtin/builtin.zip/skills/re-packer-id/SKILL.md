---
name: re-packer-id
description: "Identifying executable packers, protectors, and crypters: entropy analysis, section signatures, stub recognition, and mapping a sample to its protection family. Use this skill when a binary looks packed or protected and you must decide the unpacking strategy before analysis."
---

# Packer Identification

## Overview

A packer compresses or encrypts the original binary and prepends a stub that reconstructs it in memory. Identification determines whether you can use a generic dumper or need per-protection work.

## Signals

| Signal | Meaning |
|---|---|
| Entry point in last section, section high entropy | classic packer (UPX, ASPack, MPRESS) |
| Only `LoadLibrary`/`GetProcAddress` imported | runtime-resolved imports (packer) |
| Sections named `UPX0`, `UPX1`, `.aspack`, `.MPRESS1` | named packer |
| `.vmp0`, `.vmp1`, `VMP` strings | VMProtect |
| `.themida`, `.winlice` | Themida / WinLicense |
| Section with `IMAGE_SCN_MEM_WRITE|EXECUTE` | unpacking stub's output buffer |
| Original entrypoint still in `.text` after unpack | thin wrapper |
| `PUSHAD` at entry (x86) | classic UPX/ASPack stub |
| Enigma, Obsidium markers in resources | commercial protector |

## Commands

```bash
diec target.exe            # Detect It Easy: packer, compiler, protector
upx -l target.exe          # is it UPX?
python3 - <<'EOF'
import pefile
pe = pefile.PE("target.exe")
print("EP:", hex(pe.OPTIONAL_HEADER.AddressOfEntryPoint), "imagebase:", hex(pe.OPTIONAL_HEADER.ImageBase))
for s in pe.sections:
    print(f"{s.Name.rstrip(chr(0).encode()).decode(errors='replace'):10} vs={s.Misc_VirtualSize:8x} raw={s.SizeOfRawData:8x} ent={s.get_entropy():.2f} {hex(s.Characteristics)}")
EOF
```

## Entropy interpretation

- `~0.0–5.0` — normal code/data
- `5.0–6.5` — compressed resources or x86 code with data
- `> 7.2` — compressed or encrypted blob
- `~8.0` everywhere except a small stub — fully packed

## Family decision

**UPX** → `upx -d target.exe -o unpacked.exe`. If the header was tampered, rebuild the UPX section table or use the in-memory dump path.

**ASPack / MPRESS / PECompact** → run to OEP, dump with Scylla, rebuild IAT.

**VMProtect / Themida / Enigma** → no generic dump. Work against the VM: locate the dispatcher, identify handlers, lift the bytecode. Expect anti-debug, anti-VM, integrity checks, and per-build mutation.

**.NET Reactor / ConfuserEx / SmartAssembly** → `de4dot` first, then dnSpy.

**Android packers** (Bangcle, 360, Tencent Legu) → dump DEX from memory with FART/BlackDex or Frida.

## Stub recognition

The stub typically:

1. resolves APIs by hash (`call [ebp+X]` after a `ror/add` hash loop),
2. allocates with `VirtualAlloc(RWX)`,
3. decompresses (LZMA/aPLib markers: `0x5D 0x00 0x00` for LZMA alone),
4. writes sections and fixes relocations,
5. jumps to OEP.

Break on `VirtualAlloc`, `VirtualProtect`, and `NtProtectVirtualMemory` to catch step 2.

## Pitfalls

- `diec` misreports on hand-modified headers; verify by entropy and imports.
- UPX with a modified magic fails `upx -d` loudly — do not assume the file is not UPX.
- A protector can be applied to an already-packed binary (double packing).

## Verification

After unpacking, `diec` should report the original compiler and the import table should look like a normal application.
