---
name: bloodhound-enum
description: "BloodHound collection and analysis: SharpHound/BloodHound.py collection, graph queries, and shortest-path analysis to Domain Admin. Use this skill when you need attack-path analysis rather than raw enumeration."
---

# BloodHound

## Overview

BloodHound models AD as a graph. Collection gathers edges; the value is in shortest-path queries.

## Collection

```bash
# Linux
bloodhound-python -u user -p pass -d domain.local -ns DC -c All --zip -o out/

# Windows (SharpHound)
SharpHound.exe -c All --zipfilename loot.zip
```

Collection methods: `Default` (fast), `Stealth` (slow, less noisy), `All`.

## Import

Start BloodHound (Neo4j backend), upload the zip, then:

```cypher
// shortest path to Domain Admins
MATCH p=shortestPath((u:User {owned:true})-[*1..]->(g:Group {name:"DOMAIN ADMINS@DOMAIN.LOCAL"}))
RETURN p
```

## Key queries

```cypher
// kerberoastable users with DA rights
MATCH (u:User {hasspn:true})-[:MemberOf*1..]->(g:Group)
WHERE g.name CONTAINS "DOMAIN ADMINS" RETURN u.name

// unconstrained delegation computers
MATCH (c:Computer {unconstraineddelegation:true}) RETURN c.name

// users with DCSync rights
MATCH p=(u:User)-[:DCSync|:GenericAll|:WriteDacl]->(d:Domain)
RETURN p

// sessions on high-value targets
MATCH (u:User)-[:HasSession]->(c:Computer)
WHERE c.name CONTAINS "DC" RETURN u.name, c.name

// ACL edges from owned principals
MATCH p=(u:User {owned:true})-[r:GenericAll|:GenericWrite|:WriteDacl|:ForceChangePassword|:AddMember*1..]->(t)
RETURN p
```

## Marking owned

Right-click a principal → Mark as Owned. All queries then use it as a start node.

## Edge meanings

| Edge | Abuse |
|---|---|
| `GenericAll` | full control over the object |
| `GenericWrite` | write attributes (SPN, scriptPath) |
| `WriteDacl` | grant yourself rights |
| `ForceChangePassword` | reset without knowing the old password |
| `AddMember` | add to a group |
| `HasSession` | credential material on that host |
| `CanRDP` / `CanPSRemote` | remote access |
| `ExecuteDCOM` | lateral movement |
| `AllowedToDelegate` | constrained delegation |
| `DCSync` | replicate credentials |

## Pitfalls

- Sessions are transient; collect shortly before acting.
- Large domains need a bigger Neo4j heap.
- BloodHound CE and legacy BloodHound have different schemas.

## Verification

An edge must be exploitable: perform the abuse and confirm the new access.
