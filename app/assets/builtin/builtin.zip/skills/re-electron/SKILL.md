---
name: re-electron
description: "Reversing Electron applications: asar archives, main/renderer processes, preload bridges, and the Node context. Use this skill when the target is an Electron desktop app and its logic is JavaScript running with Node privileges."
---

# Electron Reversing

## Overview

An Electron app is Chromium + Node. `app.asar` holds the app's JS, HTML, and assets in plaintext. The main process has full Node access; the renderer is sandboxed unless `nodeIntegration` is enabled.

## Unpack

```bash
npm i -g asar
asar list app.asar | head -30
asar extract app.asar app_out/
```

Locations:

| OS | Path |
|---|---|
| Windows | `resources/app.asar` |
| macOS | `Contents/Resources/app.asar` |
| Linux | `resources/app.asar` |

If `app.asar` is missing, the app is unpacked — the directory holds the source directly.

## Structure

```
app_out/
  package.json         # "main" points to the entry
  main.js              # main process
  preload.js           # bridge with contextIsolation
  renderer/            # the web UI
```

## Main process

Full Node: `require("fs")`, `child_process`, `net`. Reversing it is reading Node source.

```javascript
// hook at runtime via --inspect
// run: app.exe --inspect=9229
// then chrome://inspect to attach
```

## Renderer / preload

`contextBridge.exposeInMainWorld` defines the API surface. Everything else is browser-like. Reversing is standard web JS work plus the exposed bridge.

```javascript
contextBridge.exposeInMainWorld("api", {
  save: (data) => ipcRenderer.invoke("save", data),
});
```

## Runtime instrumentation

```bash
# enable remote debugging
app.exe --remote-debugging-port=9222
# then chrome://inspect or a CDP client
```

```python
# attach with CDP
import websocket, json
ws = websocket.create_connection("ws://127.0.0.1:9222/devtools/page/<id>")
ws.send(json.dumps({"id":1,"method":"Runtime.evaluate","params":{"expression":"process.env"}}))
```

If `nodeIntegration` is on, `process` is available in the renderer and you can read the filesystem directly through the console.

## Patching

Since it is plaintext JS, patch and repack:

```bash
asar pack app_out app.asar
```

Electron verifies ASAR integrity only if `fuses`/`EnableEmbeddedAsarIntegrityValidation` is set (Electron 20+). Otherwise the repacked archive loads.

```bash
# check fuses
npx @electron/fuses read --app app.exe
```

## Common protections

- Minified/bundled main process (webpack) — beautify.
- `asar` integrity check — patch the `package.json` or disable the fuse.
- Native modules (`.node`) — reverse as native code.

## Pitfalls

- `app.asar.unpacked/` holds native modules loaded from disk; both must be updated together.
- Electron version determines fuse support; older builds have no integrity check.
- Auto-update signatures may reject a patched build.

## Verification

The patched app launches and the modified behavior is visible in the UI, with no integrity error in the console.
