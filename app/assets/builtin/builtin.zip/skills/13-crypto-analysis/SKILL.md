---
name: 13-crypto-analysis
description: "Broad cryptographic analysis workflow: identifying, evaluating, and breaking weak crypto in an application, from protocol design to implementation flaws. Use this skill when auditing a system's cryptography rather than a single algorithm."
---

# Crypto Analysis

## Overview

Break crypto at the weakest layer: protocol design, key management, implementation, or the primitive itself — in that order of likelihood.

## Audit order

1. **Design.** Is the same key used for encryption and authentication? Is there a nonce? Is the IV static?
2. **Key management.** Hardcoded? Derived from a guessable value? Stored next to the ciphertext?
3. **Implementation.** Custom padding, truncated MAC, comparison with `==`, ECB mode.
4. **Primitive.** Only after 1–3 are clean, check for a weak algorithm (MD5, SHA-1, DES, RC4).

## Design flaws

- **Static IV** — identical plaintexts produce identical ciphertexts; leaks equality.
- **No authentication (CBC without MAC)** — padding oracle, bit-flipping.
- **MAC-then-encrypt** — padding oracle on the MAC.
- **Key reuse across purposes** — one key for both encryption and HMAC.
- **Truncated MAC** — 1-4 byte MACs are brute-forceable.

## Implementation flaws

```python
# constant-time comparison missing
if computed_mac == provided_mac:   # timing leak
    ...
```

```python
# ECB mode
from Crypto.Cipher import AES
c = AES.new(key, AES.MODE_ECB)
```

Detect ECB in a capture: identical 16-byte blocks.

## Bit-flipping on CBC

```python
# flip a bit in block i-1 to change block i
ct = bytearray(ciphertext)
ct[(i-1)*16 + j] ^= delta
```

Works when there is no MAC.

## Padding oracle

```python
def oracle(ct):        # returns True if padding is valid
    ...

def decrypt_block(prev, block):
    out = bytearray(16)
    for pad in range(1, 17):
        for guess in range(256):
            crafted = bytearray(prev)
            for k in range(1, pad):
                crafted[-k] ^= pad ^ out[-k]
            crafted[-pad] ^= pad ^ guess
            if oracle(bytes(crafted) + block):
                out[-pad] = guess
                break
    return bytes(out)
```

## Hash weaknesses

- Length extension on `MD5(secret || msg)` — forge with `hashpump`.
- Collisions: MD5 (`fastcoll`), SHA-1 (`shattered` PDFs).
- Unsalted password hashes — rainbow tables.

```bash
hashpump -s <sig> -d <data> -a <append> -k <keylen>
```

## JWT

```bash
# alg=none
python3 -c "import base64,json;h=base64.urlsafe_b64encode(b'{\"alg\":\"none\",\"typ\":\"JWT\"}').rstrip(b'=');print(h)"
# HS256 with a weak secret
hashcat -m 16500 jwt.txt rockyou.txt
```

## Randomness

- `rand()`, `Math.random()`, `java.util.Random` — predictable.
- Time-seeded PRNG — brute-force the seed window.
- `/dev/urandom` — fine.

## Reporting

For each finding: the layer (design/impl/primitive), the concrete attack, the required access (ciphertext only, chosen plaintext, timing), and the impact.

## Verification

Every claimed break must be demonstrated: a forged token accepted, a decrypted block matching known plaintext, or a recovered key that decrypts real data.
