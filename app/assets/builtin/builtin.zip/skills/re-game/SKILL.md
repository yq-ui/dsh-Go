---
name: re-game
description: "Game binary reversing: engine layout discovery, player/entity structure mapping, network protocol reversal, and anti-cheat interactions in shipped game clients. Use this skill when reversing game executables, mapping entity structs, or analyzing game network traffic."
---

# Game Reversing

## Overview

Game RE is usually about three things: the **world model** (entity list, local player, view matrix), the **protocol** (what the client sends and trusts), and the **protection** (what watches memory).

## Finding the world model

1. Locate the string surface: `"player"`, `"entity"`, `"localplayer"`, `"m_vecOrigin"`.
2. Follow to the class, then to the registry (entity list pointer).
3. For engines with a global instance: find the pointer by scanning `.data` for a vtable reference and following it.

```c
// typical shape in Source-family engines
CGlobalVars*     g_pGlobalVars;     // tickcount, curtime, interval_per_tick
IEntityList*     g_pEntityList;     // index -> CBaseEntity*
```

Radius/pointer scanning for the local player:

```python
# Frida: find a pointer chain from a module base that resolves to a value you can change
base = Module.findBaseAddress("game.exe")
cand = base.add(0x1A2B3C).readPointer()   # g_pEntityList
n = cand.add(0x10).readU32()              # max entities
print("entities:", n)
```

## Struct mapping

Read the entity, then each field by checking which one changes as you move:

| Field | Discovery |
|---|---|
| position | three consecutive floats that change smoothly as you move |
| health | int decreasing when damaged |
| team | small int constant per team |
| view angles | two floats bounded to [-89,89] and [-180,180] |
| bone matrix | large float array around 0x1000+ bytes |

## Network protocol

```bash
# capture
tcpdump -i any -w game.pcap port 27015
# or mitm on a custom port with a transparent proxy
socat -v TCP-LISTEN:27015,fork,reuseaddr TCP:real.server:27015
```

Then reverse the packet struct: find the size field, the opcode, and the layout. Most protocols are `[size][opcode][payload]` with bit-packed fields.

Bit packing: `(value >> shift) & mask` — record the shift and mask for each semantic field, then write a decoder.

## Anti-cheat interaction

- Do not patch code in protected games; kernel AC hashes `.text`.
- Reads are cheaper than writes; a read-only overlay using external process memory access is detectable via handle rights and access patterns.
- Kernel ACs enumerate handles (`ObRegisterCallbacks`) — an external `OpenProcess` with `PROCESS_VM_READ` gets flagged.

## Tools

```bash
# ReClass.NET / ReClassEx: pointer-chain and struct mapping
# Cheat Engine: memory scanning, pointer maps, structure dissect
# IDA/Ghidra on the client binary
# Wireshark + custom dissector for protocol
```

## Pitfalls

- Offsets change per game build; always resolve via pattern scan or a stable module offset, never hardcode.
- Encrypted pointers: some engines XOR pointers with a rolling key.
- The client is not authoritative — trusting a client-side value tells you nothing about server validation.

## Verification

The mapped struct must predict a value you did not read to build it (e.g., predict health after damage from the entity pointer alone).
