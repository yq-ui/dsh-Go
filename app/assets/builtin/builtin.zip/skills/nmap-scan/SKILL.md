---
name: nmap-scan
description: "Nmap scanning: host discovery, port scanning techniques, service and version detection, NSE scripting, and output formats. Use this skill when detailed service enumeration is needed."
---

# nmap

## Overview

nmap is the reference scanner: discovery, port state, service fingerprint, script engine, and structured output.

## Basic

```bash
nmap target
nmap -sV -sC target
nmap -p- target
nmap -p 22,80,443 -sV target
nmap -iL hosts.txt -oA scan
```

## Timing

```bash
-T0..-T5             # paranoid to insane
--min-rate 1000      # packets per second floor
--max-retries 2
```

## Scan types

```bash
-sS   # SYN (root, stealthy)
-sT   # connect (no root)
-sU   # UDP
-sA   # ACK (firewall mapping)
-sN   # null / -sF fin / -sX xmas
```

## Service and OS

```bash
-sV --version-intensity 9
-O --osscan-guess
--script=banner
```

## NSE scripts

```bash
nmap --script vuln -p 445 target
nmap --script http-title,http-headers -p 80,443 target
nmap --script smb-enum-shares,smb-os-discovery -p 445 target
nmap --script "ssl-*" -p 443 target
ls /usr/share/nmap/scripts/ | grep http
```

## Output

```bash
-oA name        # all three formats
-oX out.xml
-oG out.gnmap
-oN out.txt
```

```bash
# parse xml
python3 -c "
import xml.etree.ElementTree as ET
t = ET.parse('scan.xml')
for h in t.findall('.//host'):
    for p in h.findall('.//port'):
        print(h.find('address').get('addr'), p.get('portid'), p.find('state').get('state'))
"
```

## Firewall evasion

```bash
-f            # fragment
--data-length 50
--source-port 53
--decoy 1.2.3.4,5.6.7.8
--spoof-mac 0
```

## Pitfalls

- `-p-` on many hosts takes hours; use `--min-rate`.
- `-sV` aggressiveness can crash fragile services.
- UDP scans are slow and unreliable; target specific ports.

## Verification

Open ports must be reproducible with a second scan type (`-sT` vs `-sS`).
