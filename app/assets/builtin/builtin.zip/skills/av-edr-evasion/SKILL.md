---
name: av-edr-evasion
description: "AV and EDR evasion at the file and behavior level: packing, obfuscation, signature evasion, and living-off-the-land execution. Use this skill when a payload must survive static and behavioral analysis."
---

# AV/EDR Evasion

## Overview

Static AV matches bytes and signatures. EDR matches behavior. Defeat static first, then behavioral.

## Static evasion

| Technique | Effect |
|---|---|
| Encryption at rest | no plaintext signature |
| Custom crypter | new binary each build |
| Packing (UPX/other) | hides the original code |
| Obfuscation (control flow, junk) | breaks byte signatures |
| String encryption | hides IOCs |
| API hashing | hides import names |
| Resource embedding | payload not in `.text` |

```bash
# check detection before deploying
# local: Defender
powershell -c "Get-MpThreatDetection"
# online: VirusTotal (leaks the sample — decide first)
```

## Behavioral evasion

- **LOLBins** — use signed system binaries: `certutil`, `mshta`, `rundll32`, `regsvr32`, `wmic`, `bitsadmin`.
- **Parent process spoofing** — make the parent look legitimate.
- **Signed binary proxy execution** — `rundll32 shell32.dll,Control_RunDLL`.
- **Process hollowing / herpaderping** — replace a legitimate process's image.
- **Timing** — avoid rapid successive sensitive calls.

## AMSI/ETW

See `evasion-technique-integrate`.

## Signature development loop

1. Build.
2. Test against the target AV (a VM with the same product).
3. If detected, identify the signature via `DefenderCheck` or by bisecting the binary.
4. Modify the flagged region.
5. Repeat.

## Obfuscation checklist

- No plaintext C2 strings.
- No plaintext API names in the import table (use dynamic resolution).
- No known shellcode prologue.
- Section names not default.
- No PDB path leaking the project.

## Pitfalls

- A sample that passes VirusTotal may still be blocked by the target's EDR.
- Over-obfuscation (VMProtect on a small tool) is itself suspicious.
- Behavioral detection ignores static changes entirely.

## Verification

The payload must execute on a host with the target's AV/EDR without an alert, and the session must be functional.
