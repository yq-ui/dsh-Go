---
name: re-firmware
description: "Firmware analysis end to end: acquisition, identification, extraction, filesystem recovery, and emulation of embedded device firmware. Use this skill when given a firmware blob, an update package, or a device to analyze."
---

# Firmware Analysis

## Overview

Firmware is usually a flash image: bootloader + kernel + rootfs + vendor apps. The work is extraction, then either static analysis of the binaries or emulation of the whole system.

## Acquisition

- Vendor update file (`.bin`, `.img`, `.pkg`, `.tar.gz`)
- Flash chip read (SPI: `flashrom -p ch341a_spi -r dump.bin`)
- UART/JTAG console dump
- `dd` from a running device with root

## Identification

```bash
file firmware.bin
binwalk firmware.bin            # signatures
binwalk -E firmware.bin         # entropy plot
xxd firmware.bin | head -20
strings -a -n 12 firmware.bin | head -40
```

## Extraction

```bash
binwalk -e --run-as=root firmware.bin
# or manually
unsquashfs -d rootfs _firmware.bin.extracted/squashfs-root
# other filesystems
jefferson squashfs.img      # JFFS2
ubireader_extract_images ubi.img
mount -o loop,ro rootfs.img mnt
```

Common containers: header + LZMA, TRX, UBI, cramfs, squashfs, ubifs, JFFS2.

TRX: 28-byte header with offsets and lengths:

```python
import struct
d = open("fw.bin","rb").read()
magic, len_, crc, flag, ver, off1, off2, off3 = struct.unpack("<IIIIIII I", d[:32])
print(hex(magic), len_, hex(off1), hex(off2), hex(off3))
```

## Filesystem analysis

```bash
ls rootfs/
cat rootfs/etc/init.d/rcS
find rootfs -name "*.cgi" -o -name "httpd" -o -name "*.sh" | head
grep -rn "telnetd\|password\|admin" rootfs/etc/ | head -20
```

Vendor web interfaces: `rootfs/www/` + a CGI binary. The CGI binary is where the vulnerabilities live.

## Emulation

```bash
# user-mode for one binary
qemu-mipsel -L rootfs ./rootfs/usr/sbin/httpd
# full system
qemu-system-mipsel -M malta -kernel vmlinux -hda rootfs.img -append "root=/dev/sda" -nographic
# firmadyne / FAT automates this
./fat.py firmware.bin
```

Common blockers: NVRAM dependencies (`nvram_get`), custom kernel modules, missing `/dev`, and init scripts that expect specific hardware.

## Bootloader

```bash
strings -a -n 8 fw.bin | grep -iE "u-boot|bootargs|tftp|console=" | head
```

U-Boot environment variables at a known offset reveal boot args and update paths. `fw_printenv` on a live device, or carve the env block.

## Pitfalls

- binwalk misses custom headers; entropy analysis finds the boundary instead.
- squashfs endianness mismatch (`unsquashfs -be` for big-endian).
- Emulated binaries often fail on missing `libc` — use the extracted rootfs with `-L`.

## Verification

The extracted rootfs must contain a working `busybox`; running it under QEMU proves the extraction and architecture are right.
