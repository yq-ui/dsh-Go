---
name: re-hypervisor
description: "Hypervisor and virtualization-layer analysis: VMX/SVM operation, hypervisor detection and hiding, EPT/NPT manipulation, and hypervisor-based monitoring or cheating. Use this skill when analyzing a hypervisor, detecting virtualization, or evaluating hypervisor-level protection."
---

# Hypervisor Reversing

## Overview

A hypervisor runs below the OS. In a security context it either **monitors** (EPT hooks, syscall interception) or **hides** (blue pill, anti-detection). Analysis means finding CPUID behavior, timing anomalies, and memory translation differences.

## VT-x essentials

```c
VMXON region  -> VMCS (Virtual Machine Control Structure)
VMCS fields: guest state, host state, controls, exit info
VM exits: CPUID, MSR, EPT violation, I/O, CR access
```

Basic flow:

```
VMXON
VMPTRLD vmcs
VMLAUNCH / VMRESUME
; in exit handler:
VMREAD exit_reason
... handle ...
VMRESUME
```

## SVM (AMD)

```
VMRUN with VMCB (control + state save area)
exit code in VMCB, handled in host
```

## Detection

| Signal | Meaning |
|---|---|
| CPUID leaf 1, ECX bit 31 | hypervisor present bit |
| CPUID 0x40000000 | vendor string (`KVMKVMKVM`, `VMwareVMware`, `Microsoft Hv`) |
| `rdtsc` deltas inconsistent | exit overhead |
| MSR `IA32_FEATURE_CONTROL` locked, VMX on | nested virtualization |
| EPT/NPT: page table walks differ from guest CR3 | shadow paging |
| Timing of `cpuid` (measured in cycles) | trap-and-emulate |

```c
// CPUID with hypervisor bit
int regs[4];
__cpuid(regs, 1);
bool hv = (regs[2] >> 31) & 1;
```

## Hidden hypervisor (blue pill class)

Old technique: set `CR4.VMXE`, run VMXON inside a VMCS configured to pass everything through. Detection now relies on:
- `rdtsc` exit latency
- `invept` behavior
- SMM interaction
- firmware tables (ACPI) mismatch

## EPT hooking

The hypervisor marks a guest page non-executable or read-only; an access triggers an EPT violation exit; the handler redirects execution to a patched copy, then resumes.

Detection: the guest's own page tables show one content; a self-read after execution may show another. Cross-check with a `mov` from the same address and with `MmIsAddressValid`-style probes.

## Analysis approach

1. Determine whether a hypervisor is present (CPUID + timing).
2. If present, find its exit handler: it lives outside the guest, so it is not in guest memory — you need a physical memory image.
3. In a memory image, look for VMCS regions (4 KB aligned, containing recognizable control fields) and the `VMXON` region revision ID.
4. Identify hooked pages by comparing guest page tables against EPT entries (not visible from the guest).

## Tools

```bash
# guest-side detection
pip install hv-detect  # or use cpuid directly
# memory image analysis
vol -f mem.raw windows.vmdetect
```

## Pitfalls

- CPUID hypervisor bit is trivially hidden by intercepting CPUID and clearing the bit — absence proves nothing.
- Timing measurements under a virtualized test environment are unreliable.
- Nested virtualization gives false positives on physical machines with Hyper-V enabled.

## Verification

Two independent signals (a CPUID anomaly plus a measurable exit latency) must agree before concluding a hypervisor is present.
