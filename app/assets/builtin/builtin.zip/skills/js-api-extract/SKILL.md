---
name: js-api-extract
description: "Extracting API endpoints and secrets from JavaScript: static parsing, source map recovery, and runtime interception. Use this skill when a web app's API surface is defined in its JS bundles."
---

# JS API Extraction

## Overview

Modern apps define their API in JS. Extract endpoints, parameters, and sometimes keys — statically from bundles, or at runtime.

## Collect JS

```bash
katana -u https://target -jc -silent | grep "\.js" | sort -u > js.txt
curl -s https://target | grep -oE 'src="[^"]+\.js"' | sed 's/src="//;s/"//' >> js.txt
```

## Static extraction

```bash
pip install linkfinder
python3 linkfinder.py -i https://target/app.js -o cli
```

```bash
# regex sweep across all bundles
cat js.txt | while read u; do
  curl -s "$u" | grep -oE "['\"]/(api|v[0-9])/[a-zA-Z0-9_/{}.-]+['\"]"
done | sort -u
```

jsluice:

```bash
go install github.com/BishopFox/jsluice/cmd/jsluice@latest
cat app.js | jsluice urls
cat app.js | jsluice secrets
```

## Source maps

```bash
curl -s https://target/app.js | tail -2
# if sourceMappingURL exists:
curl -s https://target/app.js.map -o app.map
npx source-map-cli extract app.map src/
```

Recovered sources reveal route names and API clients.

## Runtime interception

```javascript
// list every fetch/XHR before the page loads
const _fetch = window.fetch;
window.fetch = function (u, o) { console.log("FETCH", u, o && o.body); return _fetch.apply(this, arguments); };
const _open = XMLHttpRequest.prototype.open;
XMLHttpRequest.prototype.open = function (m, u) { console.log("XHR", m, u); return _open.apply(this, arguments); };
```

Or read the network tab in DevTools, filtered to XHR/Fetch.

## Secrets in bundles

```bash
grep -aoE "(api[_-]?key|token|secret)[\"']?\s*[:=]\s*[\"'][^\"']{8,}" app.js
grep -aoE "AIza[0-9A-Za-z_-]{35}" app.js        # google api key
grep -aoE "sk-[A-Za-z0-9]{20,}" app.js          # stripe-like
```

## Pitfalls

- Minified code splits strings; search for partial paths (`/api/v1/`) not full URLs.
- Webpack chunks are separate files — enumerate all of them from the manifest.
- Keys in frontend code are public by definition; check what they authorize.

## Verification

Each extracted endpoint must respond to a direct request with a plausible API response.
