---
name: re-ransomware
description: "Ransomware analysis: encryption routine reversal, key management, and recovery of decryptable data. Use this skill when analyzing ransomware to determine whether decryption is possible and how."
---

# Ransomware Analysis

## Overview

Ransomware questions: which algorithm, where the key comes from, whether the key is recoverable, and what the file format is. The answer decides whether recovery is possible.

## Triage

```bash
file sample
strings -a sample | grep -iE "bitcoin|ransom|decrypt|\.locked|readme" | head
binwalk -e sample
```

Look for: the ransom note template (embedded), the file extension appended, the marker format.

## Crypto identification

| Pattern | Meaning |
|---|---|
| `CryptGenRandom` / `BCryptGenRandom` for a key | random key per file or per host |
| AES key encrypted with RSA public key | asymmetric wrapping — unrecoverable without the private key |
| Same key for all files | one key to recover |
| `CryptAcquireContext` + `CryptEncrypt` | Windows CryptoAPI |
| AES-NI instructions | fast bulk encryption |
| ChaCha20 constants (`expand 32-byte k`) | stream cipher |

## Key management classes

1. **Embedded static key** — decryptable; extract from the binary.
2. **Per-file random key, stored in the file header** — decryptable if the key is plaintext or weakly obfuscated.
3. **Per-file key encrypted with an embedded public key** — requires the private key (server-side); generally unrecoverable.
4. **Per-host key derived from a passphrase** — recoverable if the passphrase is predictable.
5. **Flawed implementation** — key reuse, predictable PRNG seed, partial overwrite.

## File format

Most ransomware appends a footer or prepends a header:

```
[encrypted][key_blob][size][marker]
```

or

```
[marker][nonce][encrypted]
```

Compare an encrypted file with its pre-encryption length; `size mod 16` reveals block cipher padding.

## Recovering partial data

- **Intermittent encryption** (encrypts only the first N KB) — the tail is intact.
- **Sparse file encryption** — large files partially encrypted.
- **Key in memory** — if the process is still running, dump it and search for key schedules.
- **Shadow copies / VSS** — check `vssadmin list shadows`.

## Analysis approach

```bash
# find the encryption loop
r2 -A sample
> axt @ sym.imp.CryptEncrypt
> pdf @ <caller>
```

The loop shows: buffer size, key handle source, file iteration. The key handle's origin is the crux.

## Pitfalls

- A "recoverable" claim requires a working decryptor on a real sample pair.
- Many families delete shadow copies first.
- Some encrypt with a per-boot key stored in the registry — check `HKLM\SOFTWARE\<vendor>`.

## Verification

A decryptor is only proven when it restores a real encrypted file to a byte-identical original.
