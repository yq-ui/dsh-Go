---
name: re-mips
description: "MIPS reversing: instruction formats, delay slots, register conventions, PIC/GOT patterns in MIPS binaries, and router/IoT firmware analysis. Use this skill when analyzing MIPS firmware or embedded binaries."
---

# MIPS Reversing

## Overview

MIPS is big- or little-endian, uses **delay slots** (the instruction after a branch executes), and has $at/`$gp`-based PIC addressing. Common in routers, cameras, and older embedded devices.

## Endianness and mode

```bash
readelf -h fw | grep -E "Data|Machine"
# Machine: MIPS R3000, Data: 2's complement, little endian
file fw.bin    # "MIPS, MIPS32 rel2 version 1 (SYSV)"
```

`mipsel` = little-endian. `mips` = big-endian. MIPS16/microMIPS are compressed modes — check the ELF flags.

## Registers

| Reg | Name | Role |
|---|---|---|
| `$0` | zero | constant 0 |
| `$1` | at | assembler temporary |
| `$2-$3` | v0-v1 | return values |
| `$4-$7` | a0-a3 | arguments |
| `$8-$15` | t0-t7 | temporaries |
| `$16-$23` | s0-s7 | callee-saved |
| `$28` | gp | global pointer (PIC base) |
| `$29` | sp | stack |
| `$31` | ra | return address |

## Delay slots

```asm
jal  check          ; call
move a0, s0         ; DELAY SLOT — executes before the call takes effect
```

Decompilers that ignore delay slots produce wrong code. IDA and Ghidra handle them; hand-reading requires care.

## PIC / GOT

```asm
lui   gp, %hi(_gp_dll)
addiu gp, gp, %lo(_gp_dll)
lw    v0, %got(func)(gp)
lw    t9, 0(v0)
jalr  t9
nop
```

`$gp` is set in the function prologue; every global access is `offset($gp)`.

## Common patterns

| Pattern | Meaning |
|---|---|
| `lui` + `ori` / `addiu` | 32-bit constant construction |
| `slt` / `sltu` + `beq` | comparison + branch |
| `sw`/`lw` with `$sp` offset | stack variable |
| `move $v0, $0` before `jr $ra` | return 0 |

## Firmware

```bash
binwalk -e firmware.bin
# MIPS ELF inside
file _firmware.bin.extracted/*
# emulate
qemu-mipsel -L ./rootfs ./bin/busybox
```

For router firmware: extract the squashfs, find `/etc/init.d` scripts, locate `httpd`/`cgi` binaries, then reverse the request handler.

## Emulation pitfalls

MIPS binaries expect a big-endian or little-endian ABI and specific syscall numbers — `qemu-user` with the matching `-L` rootfs is required. Missing `ld.so` produces "no such file or directory" for a binary that clearly exists.

## Verification

A function must end with `jr $ra` and have its delay slot filled; a stack frame must be `addiu $sp, -N` at entry and `addiu $sp, N` before return.
