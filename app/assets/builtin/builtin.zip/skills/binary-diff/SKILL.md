---
name: binary-diff
description: "Binary diffing: comparing two versions of a binary to find changed functions, security patches, and new logic. Use this skill when analyzing an update, a patched vulnerability, or the difference between two builds."
---

# Binary Diffing

## Overview

Diff at three levels: bytes (cheap), structure (functions/basic blocks), and semantics (decompiled code). Structural diffing survives recompilation; byte diffing does not.

## Tools

| Tool | Level |
|---|---|
| `bindiff` (IDA) | function + CFG matching |
| `diaphora` (IDA) | function matching with multiple heuristics |
| Ghidra `Version Tracking` | cross-version matching |
| `radiff2` (r2) | byte and function diff |
| `bsdiff` / `xdelta3` | byte-level patch |

```bash
radiff2 -C v1.bin v2.bin         # function-level
radiff2 -s v1.bin v2.bin         # similarity
radiff2 -g func v1 v2 | xdot -    # graph diff
```

## Workflow

1. **Byte diff** — see how much changed.
2. **Function match** — match by name, then by hash, then by CFG shape.
3. **Isolate changed functions** — sort by dissimilarity.
4. **Read the change** — decompile both, diff the pseudocode.

```bash
# quick function-level summary with r2
r2 -q -c 'aaa; aflj' v1.bin > f1.json
r2 -q -c 'aaa; aflj' v2.bin > f2.json
python3 - <<'EOF'
import json
a = {f["name"]: f["size"] for f in json.load(open("f1.json"))}
b = {f["name"]: f["size"] for f in json.load(open("f2.json"))}
for n in sorted(set(a) & set(b)):
    if a[n] != b[n]: print(f"{n}: {a[n]} -> {b[n]}")
EOF
```

## Security patch analysis

Given vendor patch `v1` and vulnerable `v2` (or vice versa):
- Changed functions cluster around the fix.
- The fix often adds a bounds check, a length validation, or a new branch.
- Comparing the decompiled code shows exactly what condition was added.

```c
// v1 (vulnerable)
memcpy(dst, src, len);
// v2 (patched)
if (len > sizeof(dst)) return -1;
memcpy(dst, src, len);
```

## Pitfalls

- Compiler version changes make every function differ textually — match structurally.
- Inlining moves code between functions; a function that "disappeared" was inlined.
- Stripped binaries lose names; match by call graph and constants.

## Verification

The identified changed function must be the one that alters behavior — demonstrate by testing the vulnerable input against both builds.
