---
name: httpx-probe
description: "HTTP probing with httpx: status codes, titles, tech detection, screenshots, and filtering live hosts from a large candidate list. Use this skill when validating which hosts actually serve HTTP."
---

# httpx

## Overview

httpx takes a host list and reports what each one serves: status, title, server, technologies, TLS. It is the filter between raw DNS and real targets.

## Basic

```bash
httpx -l hosts.txt -silent
httpx -l hosts.txt -status-code -title -tech-detect -silent
```

## Detailed

```bash
httpx -l hosts.txt \
  -status-code -title -tech-detect -web-server -content-length \
  -follow-redirects -threads 100 -silent -o live.txt
```

## Screenshots

```bash
httpx -l hosts.txt -screenshot -srd shots/ -silent
```

## TLS / certs

```bash
httpx -l hosts.txt -tls-grab -json -silent | jq '.tls.subject_cn'
```

## Path probing

```bash
httpx -l hosts.txt -path /api,/admin,/.git/config -status-code -silent
```

## Filtering

```bash
httpx -l hosts.txt -mc 200,301,302,403 -silent
httpx -l hosts.txt -fc 404 -silent
httpx -l hosts.txt -filter-regex "cloudflare|suspended" -silent
```

## From other tools

```bash
subfinder -d t.com -silent | dnsx -a -resp-only -silent | httpx -silent -status-code
cat urls.txt | httpx -silent
```

## JSON output

```bash
httpx -l hosts.txt -json -o out.jsonl -silent
jq -r 'select(.status_code==200) | .url' out.jsonl
```

## Pitfalls

- Default follows no redirects — a 301-only host still counts as live.
- CDN catch-all responses make every subdomain look alive; filter by content hash.
- Screenshot mode needs a browser and is slow.

## Verification

A live host's title and server header must be consistent with a direct `curl -I`.
