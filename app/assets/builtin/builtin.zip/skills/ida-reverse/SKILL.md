---
name: ida-reverse
description: "IDA Pro reversing workflow: loading, auto-analysis, navigation, xrefs, decompiler use, type reconstruction, structs, names, and producing a readable map of a binary. Use this skill when working in IDA Pro on static analysis, signature recovery, or preparing a patch target."
---

# IDA Pro Reversing

## Overview

IDA builds a database from a binary and lets you shape it: names, types, structs, functions. The work is adding meaning until the graph reads like source.

## Workflow

1. **Load.** Choose the right processor and loader options. For PE, leave "manual load" off unless sections are hostile. For firmware, set the base address explicitly.
2. **Auto-analyze.** Wait for it. Then check `Options > General > Analysis` for the "final analysis pass" completion.
3. **Fix the entry.** `Alt+F7` for segments, jump to entrypoint, follow calls, name the CRT startup chain up to `main`.
4. **Recover imports.** If imports are unresolved (packed/forwarded), rebuild the IAT after dumping: `Edit > Segments > Rebase`, then re-run analysis.
5. **Decompile.** `F5`. Read the pseudocode as a hint, cross-check with graph view (`Space`).
6. **Name aggressively.** Every function you understand gets a name. Every magic constant gets an enum.
7. **Document.** Add repeatable comments (`;`) at decision points.

## Navigation

| Action | Key |
|---|---|
| xrefs to | `X` |
| follow | `Enter` |
| back | `Esc` |
| rename | `N` |
| set type | `Y` |
| struct | `Shift+F9` / Local Types |
| patch bytes | `Edit > Patch program > Change byte` |
| apply patch to input | `Edit > Patch program > Apply patches to input file` |
| graph/text toggle | `Space` |
| function list | `Shift+F3` |
| strings | `Shift+F12` |

## Useful patterns

```c
// classic check shape to look for in decompiler output
if ( strlen(input) == 16 && crc32(input, 16) == 0xDEADBEEF ) ok();
```

- **Switch tables.** `jmp [eax*4+0x40A000]` — define the table as an array of code pointers to fix the graph.
- **Virtual calls.** In C++ builds, `call [ecx+0x1C]` — build a vtable struct.
- **Crypto loops.** 64 iterations with rotates 7/12/17 and adds of 32-bit constants is SHA-256; 16 rounds of S-box lookups is AES.

## Struct reconstruction

1. Find the allocation size (`malloc(0x48)`), set that as the struct size.
2. Set field types as they are used; `Y` on the pointer parameter.
3. Let IDA propagate; fix the leftovers (they reveal padding or unions).

## Pitfalls

- Editing types without `Y` on the call site leaves the decompiler wrong.
- Auto-analysis on heavily obfuscated code creates a flat, wrong graph — clear and re-analyze per region.
- Renaming without comments loses intent after a week.

## Verification

Re-run analysis (`Options > Compiler`) after bulk edits; a stable graph plus decompiled match against a dumped runtime function proves the map.
