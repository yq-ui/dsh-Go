---
name: re-fp-runtime
description: "Analyzing and defeating runtime fingerprinting: hardware IDs, environment checks, and device attestation used to bind software to a machine. Use this skill when a program fingerprints its runtime environment and that binding must be understood."
---

# Runtime Fingerprinting

## Overview

Software binds to a machine via identifiers that are hard to change: disk serial, motherboard UUID, CPU ID, MAC, TPM, or attestation. Analysis: enumerate what is read, then decide what can be spoofed.

## Windows sources

| Source | API |
|---|---|
| Volume serial | `GetVolumeInformationW` |
| Disk serial | `DeviceIoControl(IOCTL_STORAGE_QUERY_PROPERTY)` |
| Motherboard UUID | `GetSystemFirmwareTable('RSMB')` |
| CPU ID | `__cpuid` |
| MAC | `GetAdaptersInfo` |
| Computer name | `GetComputerNameExW` |
| Machine GUID | `HKLM\SOFTWARE\Microsoft\Cryptography\MachineGuid` |
| TPM EK | TBS API |

## Linux sources

```bash
cat /etc/machine-id
cat /sys/class/dmi/id/product_uuid
lsblk -o NAME,SERIAL
cat /sys/class/net/*/address
```

## Fingerprint composition

The program hashes several values together:

```c
char fp[65];
snprintf(buf, "%s|%08X|%s", machine_guid, vol_serial, mac);
sha256(buf, fp);
```

Breakpoint the hash input to capture the exact composition string — that reveals every contributing source.

## Defeating it

| Approach | When |
|---|---|
| Patch the comparison | the fingerprint is compared locally |
| Spoof the source API | fingerprint is sent to a server |
| Hook at the composition point | cleanest, single intercept |

```javascript
// Frida: intercept the composition string
const f = Module.findExportByName("kernel32.dll", "GetVolumeInformationW");
Interceptor.attach(f, { onEnter(a) { this.out = a[1]; },
  onLeave(r) { console.log("serial", this.out.readUtf16String()); } });
```

For server-side binding, hook the HTTP body before it is signed:

```javascript
Java.use("okhttp3.Request$Builder").build.implementation = function () {
  const r = this.build();
  console.log(r.toString());
  return r;
};
```

## Attestation

- **Play Integrity / DeviceCheck** — server validates a signed token; client-side patching does not help.
- **TPM quote** — bound to PCR values; cannot be forged without the TPM.
- **Windows Hello / VBS** — hardware-backed.

In these cases the only path is understanding what the server accepts, not spoofing the client.

## Pitfalls

- A fingerprint may be checked at multiple times (install, launch, periodic) — patch all.
- Some identifiers change on driver updates (disk serial) — the vendor may already tolerate drift.
- Virtual machines produce obviously fake values; some software refuses outright.

## Verification

The spoofed environment must produce the same fingerprint as the authorized machine, verified against the server's acceptance.
