---
name: re-fw-extract
description: "Extracting filesystems and payloads from firmware images: compression detection, custom container headers, and carving methods. Use this skill when binwalk fails or the firmware uses a vendor-specific container format."
---

# Firmware Extraction

## Overview

When `binwalk -e` produces nothing, the container is custom. Method: find the compression signature, determine the offsets, decompress manually.

## Signatures to start with

| Magic | Format |
|---|---|
| `\x5d\x00\x00` | LZMA alone |
| `\xfd7zXZ` | XZ |
| `\x1f\x8b\x08` | gzip |
| `BZh` | bzip2 |
| `\x28\xb5\x2f\xfd` | zstd |
| `hsqs` | squashfs little-endian |
| `sqsh` | squashfs big-endian |
| `\x85\x19` | JFFS2 (LE) |
| `UBI#` | UBI |
| `\x27\x05\x19\x56` | uImage |
| `\x7fELF` | ELF (kernel or rootfs binary) |

```bash
grep -abo $'\x5d\x00\x00' firmware.bin | head
python3 - <<'EOF'
d = open("firmware.bin","rb").read()
for sig, name in [(b"\x5d\x00\x00","lzma"), (b"hsqs","squashfs"), (b"\x1f\x8b\x08","gzip"), (b"\xfd7zXZ","xz")]:
    i = d.find(sig)
    print(name, hex(i) if i >= 0 else "not found")
EOF
```

## Manual squashfs

```bash
dd if=firmware.bin of=root.sqsh bs=1 skip=$((0x1A0000)) 2>/dev/null
unsquashfs -d rootfs root.sqsh
# big-endian
unsquashfs -be -d rootfs root.sqsh
```

## Manual LZMA

```python
import lzma, struct
d = open("firmware.bin","rb").read()
off = d.find(b"\x5d\x00\x00")
props = d[off:off+5]
dict_size = struct.unpack("<I", d[off+1:off+5])[0]
size = struct.unpack("<Q", d[off+5:off+13])[0]     # uncompressed size
dec = lzma.LZMADecompressor(format=lzma.FORMAT_ALONE)
out = dec.decompress(d[off:])
open("stage2.bin","wb").write(out)
print("dict", dict_size, "size", size, "got", len(out))
```

## Custom container header

Pattern: a magic, a version, then a table of `(offset, length)` entries.

```python
import struct
d = open("fw.bin","rb").read()
magic = d[:4]
n = struct.unpack("<I", d[8:12])[0]
for i in range(n):
    off, ln = struct.unpack("<II", d[12+i*8:20+i*8])
    print(i, hex(off), ln, d[off:off+4])
```

Validate by checking each entry starts with a recognizable magic.

## UBI

```bash
ubireader_extract_images -o out ubi.img
ubireader_extract_files -o out ubi.img
```

## JFFS2

```bash
jefferson -d out jffs2.img
```

## uImage / FIT

```bash
dumpimage -l uImage
dumpimage -T flat_dt -p 0 -o kernel.fit itb.bin
dtc -I dtb -O dts -o devicetree.dts kernel.dtb
```

## Pitfalls

- Offsets found by signature search can be inside compressed data (false positives). Validate by decompressing.
- Squashfs may be split across erase blocks with padding — carve to the end of the partition, not the end of the file.
- Some vendors XOR the whole image with a constant byte; entropy ~8.0 with no signatures means try single-byte XOR keys.

```python
d = open("fw.bin","rb").read()[:16]
for k in range(256):
    x = bytes(b ^ k for b in d)
    if x[:4] in (b"hsqs", b"\x7fELF", b"UBI#"):
        print("key", hex(k))
```

## Verification

Extracted filesystem must mount or list; extracted ELF must have a valid machine type and architecture.
