---
name: radio-sdr
description: "SDR and radio security testing: signal capture, demodulation, and analysis of wireless protocols (sub-GHz, LoRa, BLE, RFID). Use this skill when a device uses a radio protocol."
---

# Radio / SDR

## Overview

Radio testing: capture the signal, demodulate, decode the protocol, then replay or forge.

## Hardware

| Device | Range |
|---|---|
| RTL-SDR | 24 MHz – 1.7 GHz, receive only |
| HackRF | 1 MHz – 6 GHz, TX/RX |
| LimeSDR | 100 kHz – 3.8 GHz, full duplex |
| Proxmark3 | 125 kHz / 13.56 MHz RFID |
| Yard Stick One | sub-GHz (315/433/868/915) |
| Flipper Zero | sub-GHz, RFID, NFC, IR |

## Capture (sub-GHz)

```bash
# find the frequency first
rtl_power -f 300M:928M:100k -i 1 -e 60 sweep.csv
# then capture
rtl_sdr -f 433920000 -s 2048000 capture.iq
```

## Analyze with URH

```bash
pip install urh
urh
```

Universal Radio Hacker: view the waveform, detect modulation (ASK/OOK/FSK), decode bits, infer the protocol structure.

## Common protocols

| Device class | Modulation | Notes |
|---|---|---|
| Garage/gate remotes | OOK ASK | fixed or rolling code |
| Weather stations | OOK | 433 MHz, repeating |
| TPMS | FSK | 315/433 MHz |
| Key fobs | FSK | rolling code (KeeLoq) |
| LoRa | CSS | chirp spread spectrum |

## Replay

```bash
# HackRF
hackrf_transfer -t capture.raw -f 433920000 -s 2000000 -a 1 -x 40
```

Rolling codes (KeeLoq) defeat naive replay — need to capture and block, or attack the counter.

## RFID / NFC

```bash
# Proxmark3
pm3 --> hf search
pm3 --> lf search
pm3 --> hf mf autopwn      # MIFARE Classic (needs a key)
pm3 --> hf mf dump
pm3 --> hf mf restore
```

MIFARE Classic Crypto1 is broken — keys recoverable with `mfoc`/`mfcuk`.

## BLE

```bash
btmon
gatttool -b MAC --interactive
# or better: bettercap
sudo bettercap -iface hci0
> ble.recon on
```

## Pitfalls

- Transmitting requires authorization — spectrum regulation applies.
- Capture quality depends on the antenna; a bad capture cannot be decoded.
- Rolling codes and encryption defeat replay.

## Verification

A replayed or forged frame must produce the device's action.
