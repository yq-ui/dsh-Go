---
name: ffuf-fuzz
description: "Web fuzzing with ffuf: directory discovery, parameter fuzzing, vhost discovery, and filter tuning. Use this skill when brute-forcing paths, parameters, or virtual hosts."
---

# ffuf

## Overview

ffuf replaces the `FUZZ` keyword with wordlist entries and filters responses by size, status, words, or lines.

## Directory discovery

```bash
ffuf -u https://target/FUZZ -w /usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt -mc 200,204,301,302,307,401,403 -t 50
```

## Extension discovery

```bash
ffuf -u https://target/FUZZ -w list.txt -e .php,.bak,.txt,.zip,.old -mc all -fc 404
```

## Parameter fuzzing

```bash
ffuf -u "https://target/api?FUZZ=1" -w params.txt -fs 0
ffuf -u "https://target/api?id=FUZZ" -w ids.txt -mc 200 -fs 1234
```

## POST body fuzzing

```bash
ffuf -u https://target/login -X POST -d "user=admin&pass=FUZZ" -w pass.txt -fc 401
```

## Vhost discovery

```bash
ffuf -u https://target -H "Host: FUZZ.target.com" -w subs.txt -fs 4242
```

## Filters

| Flag | Meaning |
|---|---|
| `-mc` | match status |
| `-fc` | filter status |
| `-fs` | filter size |
| `-fw` | filter words |
| `-fl` | filter lines |
| `-fr` | filter regex |

Calibrate with `-ac` (auto-calibration) to filter the catch-all response automatically:

```bash
ffuf -u https://target/FUZZ -w list.txt -ac
```

## Output

```bash
ffuf -u https://t/FUZZ -w list.txt -o out.json -of json
ffuf -u https://t/FUZZ -w list.txt -c -v
```

## Recursion

```bash
ffuf -u https://t/FUZZ -w list.txt -recursion -recursion-depth 2
```

## Pitfalls

- Without size filtering, a wildcard 200 makes every entry "found".
- Too many threads get you blocked (`-rate` to limit).
- Wordlist quality dominates results; use technology-specific lists.

## Verification

A discovered path must return distinct content when fetched directly.
