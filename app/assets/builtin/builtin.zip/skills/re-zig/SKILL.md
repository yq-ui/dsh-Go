---
name: re-zig
description: "Reversing Zig binaries: name mangling, comptime expansion, error union layout, and allocator patterns. Use this skill when the target is compiled with Zig."
---

# Zig Binary Reversing

## Overview

Zig is a C-like language with `comptime` — code is generated at compile time, so binaries contain more functions than source suggests. Symbols are mangled but readable by default.

## Identify

```bash
strings app | grep -m3 -E "zig|\.zig:"
strings app | grep -m3 "reached unreachable code"
```

Zig panic messages include the source path and line: `path/to/file.zig:123: message`.

## Symbols

Zig uses `<module>.<function>` style names in the symbol table (no Itanium mangling for non-generic functions):

```bash
nm app | grep "main\." | head
```

Generics are instantiated with a hash suffix. `zig` keeps full function names unless `-fstrip`.

## Error unions

```zig
fn f() !u32
```

Layout: an error union is `{ payload, error: u16 }` packed into an integer type sized for both. On x86-64 a `!u32` returns in `rax` with the error in the upper 16 bits and payload in the lower 32, or as a struct in `rax:rdx` for larger payloads.

Check the return convention per function by looking at how the caller tests it:

```asm
test rax, rax
js   .error_path      ; negative = error (error values are small negatives offset)
```

## Allocator pattern

Every allocation takes an `Allocator` (a vtable + ptr pair):

```zig
allocator.alloc(u8, n)
// compiles to: call [allocator.vtable + offsetof(alloc, alloc)]
```

The vtable is 12 function pointers (alloc, resize, remap, free, and their aligned variants). Locate it in `.data.rel.ro`.

## Comptime expansion

```bash
nm app | awk -F'__' '{print $1}' | sort | uniq -c | sort -rn | head
```

Hundreds of near-identical functions with a numeric suffix = generic instantiations. Analyze one, apply to all.

## Unsafe / panic paths

`@panic`, `unreachable`, and bounds checks call `std.debug.panic` / `panicExtra`, which format a message with the source location. These strings are the fastest route to the source structure.

## Pitfalls

- Zig's `ReleaseFast` removes safety checks — no panic strings, harder mapping.
- The error union convention differs between small and large payloads; check the return register size.
- `comptime` can inline entire data tables into `.rodata`.

## Verification

The error handling path must be reachable and behave as the error union layout predicts for a failing input.
