---
name: re-hybrid-app
description: "Reversing hybrid mobile apps: React Native, Cordova/Ionic, Capacitor, and WebView-based apps, including Hermes bytecode, JS bundle extraction, and bridge hooking. Use this skill when an app's logic is JavaScript running in a WebView or Hermes runtime."
---

# Hybrid App Reversing

## Overview

Hybrid apps keep logic in JS. The bundle is either plaintext (Cordova/Capacitor), minified (React Native), or Hermes bytecode (RN 0.70+). The bridge to native is the interception point.

## Identify

```bash
unzip -l app.apk | grep -E "index.android.bundle|assets/www|public/|libhermes|libjsc"
```

| Evidence | Runtime |
|---|---|
| `assets/index.android.bundle` + `libhermes.so` | React Native + Hermes |
| `assets/index.android.bundle` + `libjsc.so` | React Native + JSC |
| `assets/www/` | Cordova |
| `assets/public/` | Capacitor |
| `res/raw/` HTML | WebView wrapper |

## React Native

**Plaintext JSC bundle:**

```bash
unzip -o app.apk assets/index.android.bundle
npx js-beautify assets/index.android.bundle -o bundle.js
grep -n "api\|token\|https://" bundle.js | head
```

**Hermes bytecode:**

```bash
pip install hbctool
hbctool disasm index.android.bundle out.hasm
# edit, then
hbctool asm out.hasm index.android.bundle.patched
```

`hermes-dec` produces better pseudocode:

```bash
hermes-dec --input index.android.bundle --output out.js
```

## Bridge hooking

React Native calls into native through `NativeModules`:

```javascript
Java.perform(() => {
  const m = Java.use("com.facebook.react.bridge.ReactContext");
  const NMB = Java.use("com.facebook.react.bridge.NativeModule");
  // simplest: hook the bridge's invocation
  const BaseJavaModule = Java.use("com.facebook.react.bridge.BaseJavaModule");
  BaseJavaModule.invoke.overload("java.lang.String","com.facebook.react.bridge.ReadableNativeArray")
    .implementation = function (name, args) {
      console.log("[RN]", name, args);
      return this.invoke(name, args);
    };
});
```

For JS-side hooking, patch the bundle to wrap `fetch`/`XMLHttpRequest` and log.

## Cordova / Capacitor

`assets/www/` is readable source. Look for:

```bash
grep -rn "exec\|cordova.exec\|Capacitor" assets/www/js/ | head
grep -rn "https://" assets/www/js/ | head -20
```

Patch the JS directly, rebuild the APK.

## WebView debugging

```javascript
// enable remote debugging and inject
Java.perform(() => {
  const WV = Java.use("android.webkit.WebView");
  WV.setWebContentsDebuggingEnabled(true);
});
```

Then `chrome://inspect` on the host shows the live page — full DevTools, network tab included. This is the highest-leverage move for any WebView app.

## iOS hybrid

```bash
# bundle location
Payload/App.app/main.jsbundle
Payload/App.app/public/
```

Hermes on iOS: same `hbctool`. WKWebView debugging via Safari's Develop menu on a device with Web Inspector enabled.

## Pitfalls

- Minified RN bundles rename everything; grep for strings and network endpoints, not identifiers.
- Hermes bytecode version must match `hbctool`'s supported range.
- Patching the bundle invalidates the app signature — re-sign.

## Verification

The patched bundle runs (no syntax error at load), and a logged network call from the app matches a request you can reproduce with `curl`.
