---
name: binary-ninja-reverse
description: "Binary Ninja reversing: IL views (LIFTED, HLIL), types, cross-references, Python API scripting, and batch analysis. Use this skill when reversing with Binary Ninja, writing BN plugins, or needing BN's intermediate languages for analysis."
---

# Binary Ninja

## Overview

Binary Ninja exposes multiple ILs: `LOW_LEVEL_IL`, `LIFTED_IL` (architecture-independent), `MAPPED_IL`, `HIGH_LEVEL_IL` (decompiled). HLIL reads like source; LIFTED is the reliable semantic form when HLIL lies.

## Workflow

1. **Open** with `File > Open`, pick the platform/arch if auto-detection is wrong.
2. **Analyze** (`Analysis > Analyze`). `P` for the binary info panel.
3. **HLIL** in the linear view; toggle `LIFTED` with the dropdown to verify semantics.
4. **Types.** Define structs in the Types view; assign with `Y`. Set prototypes to make arguments real.
5. **Xrefs.** `Ctrl+Shift+X` for cross-references to the cursor.
6. **Script.** `Tools > Developer Tools > Python Console`.

## Python API

```python
from binaryninja import *
bv = load("/tmp/target", options={"analysis.mode": "full"})

for f in bv.functions:
    print(hex(f.start), f.symbol.short_name, f.total_basic_blocks)

# strings + xrefs
for s in bv.strings:
    for ref in bv.get_code_refs(s.start):
        print(hex(ref.address), f"{s.value[:40]!r}")

# decompile
from binaryninja import highlevelil
fn = bv.get_function_at(0x401000)
print(fn.hlil)

# patch
bv.write(0x401000, b"\x90\x90")
```

**Custom analysis with MLIL**

```python
for fn in bv.functions:
    mlil = fn.mlil
    if mlil is None:
        continue
    for ins in mlil.instructions:
        if isinstance(ins, mediumlevelil.MediumLevelILCall):
            print(fn.symbol.short_name, hex(ins.address))
```

**Register a plugin command**

```python
from binaryninja import PluginCommand
def dump_calls(bv):
    for f in bv.functions:
        for ref in f.call_sites:
            print(hex(ref.address), "->", f.symbol.short_name)
PluginCommand.register("Dump all call sites", "list callers", dump_calls)
```

## Batch mode

```bash
python3 -c "
from binaryninja import load
bv = load('/tmp/a.exe')
open('/tmp/a.txt','w').write(str(bv.get_function_at(0x401000).hlil))
"
```

Use the headless (commercial) or the Python API inside a script driven by `binaryninja.headless`.

## Notes

- `LIFTED_IL` is normal form: `x = x + 1` appears as two ops. Comparisons there are trustworthy.
- `MAPPED_IL` resolves variables into `var_8` style slots, which is what the decompiler consumes.
- Type propagation requires an explicit prototype; BN does not guess `__thiscall` for MSVC rigorously.

## Pitfalls

- Loading a large firmware as raw and letting auto-analysis run for hours — set the arch and entry manually.
- Assuming HLIL preserves evaluation order of side effects across pointer aliasing.

## Verification

Cross-check one HLIL function against its LIFTED IL; a mismatch means a type or control-flow assumption is wrong.
