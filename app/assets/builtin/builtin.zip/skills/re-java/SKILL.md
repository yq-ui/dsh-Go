---
name: re-java
description: "Java application reversing: JAR/WAR analysis, bytecode decompilation, obfuscated class recovery, and runtime analysis of JVM applications. Use this skill when the target is a Java application, servlet, or JVM-based service."
---

# Java Reversing

## Overview

JAR/WAR/EAR are ZIPs of `.class` files with metadata plus resources. Decompilation is near-perfect — the challenge is obfuscation, frameworks, and dynamic behavior.

## Inspect

```bash
unzip -l app.jar | head -30
unzip -p app.jar META-INF/MANIFEST.MF
# framework detection
unzip -l app.jar | grep -E "spring|hibernate|struts|tomcat" | head
```

## Decompile

```bash
cfr app.jar --outputdir out
procyon app.jar -o out
# vendored libs
find out -name "*.class" | wc -l
```

For a single class: `javap -p -c -constants Foo.class`.

## Obfuscated jars

ProGuard/R8/Allatori/Zelix produce `a.a.a` names, string arrays, and control-flow noise.

```bash
# string decryption pass
python3 - <<'EOF'
import subprocess, re
# dump all ldc constants
out = subprocess.run(["javap","-c","-p","-constants","A.class"],capture_output=True,text=True).stdout
for m in re.findall(r'String\s+(.+)', out): print(m)
EOF
```

For Allatori, the string decryptor is a static method taking an int and a string array; run it in a small harness:

```java
public class Unpack {
  public static void main(String[] a) throws Exception {
    for (int i = 0; i < 500; i++) {
      try { System.out.println(i + " -> " + a.a(i)); } catch (Throwable t) {}
    }
  }
}
```

## Spring / servlet apps

```bash
unzip -l app.war WEB-INF/web.xml WEB-INF/classes
cat WEB-INF/web.xml | head -60
```

Endpoints and filters are declarative; controllers are `@RequestMapping` annotated. Grep for them directly.

## Runtime

```bash
java -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=5005 -jar app.jar
jdb -attach localhost:5005
# or use a Java agent for tracing
```

Instrumentation approach (Arthas is the easiest):

```bash
java -jar arthas-boot.jar
[arthas]$ watch com.app.Service check '{params, returnObj}' -x 3
```

## Hardcoded secrets

```bash
grep -rn "password\|secret\|apiKey\|jdbc:" out/ | head -20
```

## Pitfalls

- `cfr` fails on heavily obfuscated control flow; fall back to `javap` and read bytecode.
- Multi-release JARs (`META-INF/versions/`) contain duplicate classes for different JVMs — analyze the version that runs.
- Annotation-based frameworks hide logic in proxies — the real method may be a generated class at runtime.

## Verification

A decompiled method's bytecode (`javap -c`) must match the source-level reconstruction instruction for instruction.
