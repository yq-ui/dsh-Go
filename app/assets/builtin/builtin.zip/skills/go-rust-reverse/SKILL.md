---
name: go-rust-reverse
description: "Comparative reversing of Go and Rust binaries: shared problems (static linking, large binaries, name recovery) and how their runtimes differ in memory layout and calling conventions. Use this skill when the target's language is one of Go or Rust and you need to choose the right runtime assumptions quickly."
---

# Go vs Rust Reversing

## Overview

Both compile statically, produce large binaries, and keep recoverable names. The runtime layouts and ABIs differ enough that a wrong guess wastes hours.

## Quick discrimination

| Signal | Go | Rust |
|---|---|---|
| `go1.` / `runtime.` strings | yes | no |
| `panicked at ...rs:` | no | yes |
| `NimMain` | no | no |
| Symbol prefix | `main.main`, `runtime.` | `_ZN` legacy or `_RNv` v0 |
| Binary size floor | ~1.5 MB | ~300 KB |
| Goroutine/monitor strings | `runtime.gopanic` | `std::panicking` |
| TLS/`g` register | `R14` holds `g` | normal TLS |

```bash
strings app | grep -m1 -E "go1\.|panicked at"
nm app 2>/dev/null | head -3
```

## ABI differences (amd64)

| Aspect | Go | Rust |
|---|---|---|
| Argument passing | registers RAX,RBX,RCX,RDI,RSI,R8-R11 (1.17+) | SysV: RDI,RSI,RDX,RCX,R8,R9 |
| Return | registers | RAX:RDX |
| Stack growth | `CMPQ SP, 0x10(R14)` prologue | none (fixed stacks) |
| String | `{ptr,len}` 2 words | `{ptr,len}` 2 words (same!) |
| Slice/Vec | `{ptr,len,cap}` | `{ptr,cap,len}` — **order differs** |
| Error handling | `panic` → `gopanic` + defer chain | `Result` return value |

The Vec/Slice field-order difference is the most common cause of a "corrupted" struct in cross-language analysis.

## Runtime structures

```go
// Go
type slice struct { Array unsafe.Pointer; Len, Cap int }
type string struct { Data unsafe.Pointer; Len int }
type iface struct { Tab *itab; Data unsafe.Pointer }
```

```rust
// Rust
struct Vec<T> { ptr: *mut T, cap: usize, len: usize }
struct String { vec: Vec<u8> }        // owns a Vec
struct &str { ptr: *const u8, len: usize }
```

## Symbol recovery comparison

```bash
# Go
go tool nm app | grep main.
GoReSym -t -d app

# Rust
nm app | rustfilt | head
rustfilt --no-legacy app
```

## Decompiler behavior

- Go: IDA 8.3+ has a Go ABI; Ghidra's `golang` analyzer loads `pclntab`.
- Rust: standard SysV confuses nothing, but monomorphization floods the function list.

## Pitfalls

- Go 1.16 and earlier used stack-based arguments — verify the version first.
- Rust `#[repr(Rust)]` allows field reordering; never assume declaration order.
- Both strip DWARF with `-s -w` while keeping runtime name tables.

## Verification

The struct layout you infer must be consistent across at least three call sites, and the language identification must be confirmed by two independent strings.
