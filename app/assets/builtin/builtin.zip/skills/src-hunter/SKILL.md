---
name: src-hunter
description: "SRC vulnerability hunting (Chinese crowdsourced security): program selection, asset discovery, and the vulnerability classes most rewarded on SRC platforms. Use this skill when hunting on Chinese SRC / crowdsourced platforms."
---

# SRC 挖掘

## 概述

SRC 平台（补天、漏洞盒子、CNVD、厂商自建）看重"真实影响"。选厂商、挖资产、报高危。

## 选目标

| 信号 | 含义 |
|---|---|
| 资产范围大（`*.corp.com`） | 面广 |
| 新上线业务 | 漏洞多 |
| 刚收录 | 竞争少 |
| 有众测 | 审核快、给钱快 |

避开：只收 CNVD 编号不给钱的、范围只有官网首页的。

## 资产收集

```bash
subfinder -d corp.com -silent | httpx -silent -status-code -title
# 小程序 / APP 也是资产
# 天眼查 / ICP 备案 找关联公司域名
```

```bash
# 备案查询拿主域名
# 公众号 / 小程序 反查接口
```

## 高产出漏洞类型

| 类型 | 说明 |
|---|---|
| 未授权访问 | 后台/接口无鉴权，最容易出货 |
| SQL 注入 | 老系统常见 |
| 任意文件上传/读取 | 中高危 |
| 越权（水平/垂直） | 逻辑类，扫描器挖不到 |
| SSRF | 云环境打 metadata |
| 逻辑漏洞 | 支付、优惠券、积分 |
| 信息泄露 | swagger、actuator、.git |

## 未授权快速排查

```bash
for p in /actuator/env /swagger-ui.html /api-docs /druid/index.html /.git/config /console; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "https://target$p")
  echo "$code $p"
done
```

## 报告要点

- 标题写清"哪个系统 + 什么漏洞 + 什么影响"
- 复现步骤截图完整
- 危害说明要具体（能拿到多少数据、能做什么操作）
- 一个漏洞一份报告

## 常见坑

- 重复提交：先搜平台历史
- 超出范围：看清楚排除项
- 只给扫描器截图：审核直接忽略
- 在众测期间打生产核心业务：可能被判定违规

## 验证

报告里的复现步骤必须能让审核人员一次跑通。
