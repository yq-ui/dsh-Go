---
name: re-cpp-abi
description: "C++ ABI reversing: name mangling, vtables, virtual inheritance, RTTI, exception unwinding, and standard library layouts in MSVC and Itanium ABIs. Use this skill when reversing C++ binaries and object layouts or virtual dispatch must be reconstructed correctly."
---

# C++ ABI Reversing

## Overview

Two dominant ABIs: **Itanium** (GCC/Clang, used on Linux/macOS/Android) and **MSVC**. They differ in mangling, vtable layout, RTTI, and exception handling.

## Mangling

```bash
# Itanium
c++filt _ZN3Foo3barEi
# _ZN 3Foo 3bar E i  -> Foo::bar(int)

# MSVC
dumpbin /symbols x.obj | grep "?bar@Foo"
# ?bar@Foo@@QEAAHH@Z -> public: int __cdecl Foo::bar(int)
```

Tools: `undname` (Windows), `llvm-undname`, `c++filt` (Itanium only).

## Vtable layout

**Itanium:**

```
vtable[-2] = offset to top
vtable[-1] = typeinfo pointer
vtable[0]  = first virtual function
```

Object begins with a pointer to `vtable+2`.

**MSVC:**

```
vptr -> [ first virtual function, ... ]   (vtable[0] is the first slot directly)
[-1] = RTTI Complete Object Locator
```

Multiple inheritance: the object has multiple vptrs, each for a base subobject, with thunks that adjust `this`.

## Virtual dispatch

```asm
mov rax, [rcx]        ; vptr
call qword ptr [rax+0x18]   ; slot 3
```

Slot index = declaration order (Itanium) or declaration order with overloads (MSVC). Map by finding the vtable in `.rdata`/`.data.rel.ro` and reading each entry to a named function.

## RTTI

**Itanium:** `typeinfo` objects in `.data.rel.ro`, referenced from the vtable. `type_info::name()` returns the mangled name.

**MSVC:** `RTTICompleteObjectLocator` → `TypeDescriptor` with a decorated name (`.?AVFoo@@`). `strings binary | grep '^\.?AV'` enumerates classes.

## Exception handling

**Itanium:** `.eh_frame` / `.gcc_except_table` — LSDA describes try ranges and landing pads. `__cxa_throw`, `__cxa_begin_catch`.

**MSVC:** `__CxxFrameHandler3/4`, `.pdata`/`.xdata` with `FuncInfo` structures. SEH chain in `TEB`.

## Standard library layouts

```cpp
// Itanium, libstdc++
std::string:  { char* ptr; size_t size; union { char buf[16]; size_t cap; } }
std::vector:  { T* begin; T* end; T* cap_end; }
std::map:     red-black tree, header node with parent/left/right/color
std::shared_ptr: { T* ptr; control_block* ctrl }   // 2 words
```

```cpp
// MSVC
std::string:  { union { char buf[16]; char* ptr; } ; size_t size; size_t res; }
std::vector:  { T* begin; T* end; T* cap_end; }
```

Detecting `std::string` SSO: a 16-byte inline buffer plus size — short strings are the buffer itself.

## Pitfalls

- Lambdas become functor structs with `operator()`; they appear as unnamed classes.
- `std::function` is a type-erased wrapper with a vtable-like manager pair — do not confuse it with a vtable.
- Inlined virtual calls remove the dispatch entirely; the callee is direct.

## Verification

Reading the object in a debugger, each vptr must point into a table whose entries are all valid function addresses, and RTTI must name a class consistent with the call sites.
