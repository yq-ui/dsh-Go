---
name: naabu-portscan
description: "Fast port scanning with naabu: SYN/CONNECT scanning, top-port lists, and integration with nmap for service detection. Use this skill when scanning many hosts quickly before deep service enumeration."
---

# naabu

## Overview

naabu is a fast port scanner (SYN by default when root, CONNECT otherwise). Use it to find open ports, then hand the results to nmap.

## Install

```bash
go install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
```

## Basic

```bash
naabu -host target.com -top-ports 1000
naabu -list hosts.txt -top-ports 100 -silent -o ports.txt
naabu -host target.com -p 80,443,8000-8100
naabu -host target.com -p - -exclude-ports 21,23
```

## Tuning

```bash
naabu -list hosts.txt -top-ports 1000 -rate 5000 -c 50 -timeout 2000
```

## Pass to nmap

```bash
naabu -list hosts.txt -top-ports 1000 -silent -o ports.txt
nmap -sV -sC -p $(cut -d: -f2 ports.txt | paste -sd,) -iL hosts.txt
```

Better with nmap-xml handoff:

```bash
naabu -list hosts.txt -top-ports 1000 -nmap-cli 'nmap -sV -sC'
```

## JSON

```bash
naabu -list hosts.txt -json -o out.jsonl
jq -r 'select(.port==443) | .host' out.jsonl
```

## CDN filtering

```bash
naabu -list hosts.txt -top-ports 1000 -exclude-cdn
```

`-exclude-cdn` skips hosts behind Cloudflare/Akamai, focusing on origin assets.

## Pitfalls

- SYN mode requires root; without it, CONNECT is slower but works.
- High rates trip IDS and can take down fragile devices.
- UDP is not covered — use `nmap -sU` for DNS/SNMP/NTP.

## Verification

Every open port must be confirmable with a TCP connect from a second tool.
