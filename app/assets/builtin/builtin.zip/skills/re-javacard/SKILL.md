---
name: re-javacard
description: "Java Card applet analysis: CAP file format, bytecode, and smart card applet reversing. Use this skill when analyzing Java Card applets or CAP files from secure elements and SIM cards."
---

# Java Card

## Overview

A Java Card applet ships as a CAP (Converted Applet) file: a ZIP of components containing a Java Card bytecode subset. Used in SIM, banking, and identity cards.

## CAP structure

```
Header.cap        // magic 0xDECAFFED, version
Directory.cap     // component offsets
Applet.cap        // AID, install method offsets
Class.cap         // class hierarchy
Method.cap        // method bytecode
StaticField.cap
Export.cap / Import.cap
ConstantPool.cap
RefLocation.cap
Descriptor.cap
Debug.cap         // optional, has line numbers and local names
```

```bash
unzip -l applet.cap
python3 -c "d=open('applet.cap','rb').read(); print(d[:4].hex())"   # decaffed
```

## Tools

- **jcardsim** — run the applet in a simulator
- **CAP file disassembler**: `capdump`, `jcasm`, or the `jcterm` toolchain
- **Ghidra/IDA** do not understand Java Card bytecode; use a CAP-aware disassembler

```bash
# convert CAP back to a class-file-like structure
capdump applet.cap -o out/
```

## Bytecode

Java Card bytecode is a subset with its own opcodes:

| Op | Meaning |
|---|---|
| `0x03` | `sload` (short local) |
| `0x10` | `bspush` (byte push) |
| `0x11` | `sspush` (short push) |
| `0x2A` | `invokestatic` |
| `0x6B` | `invokevirtual` |
| `0x70` | `return` |
| `0x8B` | `if_scmpne` |

Operands are often single bytes with implicit indexes.

## Applet entry points

```java
public static void install(byte[] b, short off, byte len) { ... }
public void process(APDU apdu) { ... }
```

`process` is the main loop: read the APDU, dispatch on `INS`, respond. Reversing the INS dispatch gives the command set.

```java
switch (buf[ISO7816.OFFSET_INS]) {
  case 0x10: getKey(apdu); break;
  case 0x20: sign(apdu); break;
}
```

Look for the constant pool references to `APDU.getBuffer`, `APDU.setOutgoing`.

## Extracting from a card

- **GlobalPlatform** with the right keys: `gp -list`, `gp --install`.
- SIM: `pySim`, `osmocom` tools; SIM applets are in the card's filesystem.
- eSE: vendor-specific; often requires a secure boot bypass.

## Crypto in applets

`Signature.ALG_*`, `Cipher.ALG_*` — the key is inside the card and never leaves. Analyze the *protocol*, not the key.

## Pitfalls

- CAP files are version-specific; a 3.0.5 CAP will not load on a 2.2.2 card.
- Many applets are obfuscated by renaming and by splitting methods; the CAP `Debug.cap` often survives and restores names.
- The install method can be where the real logic hides.

## Verification

Running the CAP in jcardsim and sending the recovered APDU sequence must reproduce the card's response bytes.
