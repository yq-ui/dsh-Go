---
name: dirsearch-fuzz
description: "Directory brute forcing with dirsearch: recursive discovery, extension handling, and report generation. Use this skill when enumerating web paths with a mature wordlist-driven tool."
---

# dirsearch

## Overview

dirsearch is a Python directory scanner with good defaults, recursion, and per-response reporting.

## Install

```bash
git clone https://github.com/maurosoria/dirsearch.git
cd dirsearch && pip install -r requirements.txt
```

## Basic

```bash
python3 dirsearch.py -u https://target -e php,html,js
python3 dirsearch.py -u https://target -w /usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt
```

## Recursion and extensions

```bash
python3 dirsearch.py -u https://target -e php,asp,aspx,jsp -r -R 2
```

## Threading and delay

```bash
python3 dirsearch.py -u https://target -t 50 --delay 0.1
```

## Exclusions

```bash
python3 dirsearch.py -u https://target --exclude-status 403,404 --exclude-extensions html
```

## Auth and headers

```bash
python3 dirsearch.py -u https://target -H "Authorization: Bearer TOKEN"
python3 dirsearch.py -u https://target --cookie "session=abc"
python3 dirsearch.py -u https://target --http-user u --http-pass p
```

## Output

```bash
python3 dirsearch.py -u https://target -o report.txt --format plain
python3 dirsearch.py -u https://target --format json -o out.json
```

## Proxying

```bash
python3 dirsearch.py -u https://target --proxy http://127.0.0.1:8080
```

## Pitfalls

- Default wordlist is small; always supply a larger one.
- Redirects (`-f`/`--follow-redirects`) change result semantics.
- Recursion on a wildcard host explodes into thousands of false positives.

## Verification

A found path must return a body that differs from the wildcard response.
