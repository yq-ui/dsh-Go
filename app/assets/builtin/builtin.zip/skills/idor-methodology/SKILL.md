---
name: idor-methodology
description: "Insecure direct object reference: identifying object identifiers, testing horizontal and vertical access, and enumerating ID patterns. Use this skill when an API exposes object IDs."
---

# IDOR

## Overview

The server authorizes the request but not the object. Test by changing an identifier to one belonging to another user.

## Identify candidate endpoints

```
GET /api/user/1001
GET /api/invoice/INV-2024-001
POST /api/document/delete {"id": 55}
GET /files?path=report_1001.pdf
```

Also: GraphQL node IDs, S3 keys, UUIDs in URLs, numeric IDs in bodies.

## Test

1. Create two accounts (A and B).
2. As A, request A's object → capture the identifier.
3. As A, request B's identifier.
4. If data returns, IDOR confirmed.

```bash
curl -s https://api.target/user/1002 -H "Authorization: Bearer A_TOKEN"
```

## Vertical (role) IDOR

```
GET /api/admin/users        with a normal user token
```

## ID patterns

| Pattern | Approach |
|---|---|
| Sequential int | increment/decrement |
| UUIDv1 | timestamp + MAC → predictable |
| Hash of int | try `md5(1)`, `sha1(1)` |
| Base64 of int | decode, change, re-encode |
| Composite key | change one part |

## Blind IDOR

State-changing endpoints with no read:

```
POST /api/like {"post_id": 9999}
POST /api/delete {"id": 1234}
```

Confirm via the effect on the other account.

## Bypass authorization frameworks

- Adding a second ID: `?id=1&id=2` (parameter pollution).
- JSON type confusion: `{"id": "1"}` vs `{"id": 1}`.
- Path normalization: `/api/user/1001/../1002`.
- HTTP method swap: `POST` allowed where `GET` is checked.
- Version downgrade: `/v1/` vs `/v2/` with different checks.

## Pitfalls

- 403 is a good sign — the object exists but is denied; try a different identifier.
- Testing only reads misses destructive IDORs.
- Rate limits may block enumeration; use slow scanning.

## Verification

Data belonging to a different user must be returned or modified, proven with two accounts.
