---
name: aflpp
description: "Fuzzing with AFL++: instrumentation, corpus preparation, dictionary use, and triage of crashes. Use this skill when fuzzing a target discovered through reverse engineering."
---

# AFL++

## Overview

AFL++ is a coverage-guided fuzzer. You give it an instrumented target and a seed corpus; it finds inputs reaching new code paths.

## Build the target

```bash
# source available
CC=afl-clang-fast CXX=afl-clang-fast++ ./configure --disable-shared
make -j$(nproc)

# binary only
afl-qemu-trace ./target
# or with Frida mode
afl-fuzz -O -i in -o out -- ./target @@
```

## Persistent mode

Much faster — instrument a loop that reads input repeatedly:

```c
#include "afl-fuzz.h"  // or use __AFL_LOOP
int main() {
    while (__AFL_LOOP(1000)) {
        // read stdin into buf, call target
    }
}
```

## Run

```bash
mkdir -p in out
echo "seed" > in/seed1
afl-fuzz -i in -o out -m none -t 1000 -- ./target @@
```

| Flag | Meaning |
|---|---|
| `-m none` | no memory limit |
| `-t` | timeout ms |
| `-x dict` | dictionary |
| `-d` | deterministic off (faster) |
| `-M`/`-S` | master/slave for parallel |

## Dictionary

```
kw1="MAGIC"
kw2="%s"
kw3="\x00\x01"
```

Dictionary tokens dramatically improve format-aware parsing coverage.

## Parallel fuzzing

```bash
afl-fuzz -M main -i in -o out -- ./target @@
afl-fuzz -S secondary -i in -o out -- ./target @@
```

## Crashes

```bash
ls out/default/crashes/
afl-tmin -i crash -o min -- ./target @@
```

`afl-tmin` minimizes while preserving the crash. Then triage in gdb.

## Coverage

```bash
afl-showmap -o map -- ./target < seed
afl-cov -d out/default --coverage-cmd "lcov" --code-dir ./
```

## Pitfalls

- No seed → no coverage. Provide at least one valid input.
- A target that forks per input is slow; use persistent mode or `AFL_FORKSRV_INIT_TMOUT`.
- ASAN slows fuzzing but makes bugs findable — run a second instance with ASAN.

## Verification

A crash must reproduce outside the fuzzer and be minimized to a small input.
