---
name: re-patching
description: "Binary patching: producing correct patches that preserve program integrity, handling instruction-length changes, relocations, and patch persistence. Use this skill when a binary must be modified on disk rather than in memory."
---

# Binary Patching

## Overview

A patch changes bytes. Correctness requires: same instruction length (or a trampoline), no broken relative offsets, and no invalidated checksums.

## Rules

1. **Prefer same-length substitutions.** `jz` → `jnz` (1 byte), `nop` fills.
2. **When growing a function**, find a code cave (padding) or add a section.
3. **Relative jumps** are relative to the next instruction — moving code breaks them.
4. **Checksums** — update PE checksum, or patch the checker.

## Common patches

```asm
; force a true return (x86)
B0 01 C3                 ; mov al,1; ret
33 C0 40 C3              ; xor eax,eax; inc eax; ret

; NOP a call (5 bytes)
90 90 90 90 90

; skip a check: jz -> jmp short
74 xx  ->  EB xx
```

## Trampoline / code cave

```
; original: call check (5 bytes E8 rel32)
; patch to: jmp cave (5 bytes E9 rel32)
; cave:     <your code>
;           jmp back (5 bytes)
```

```python
import struct
def rel32(from_addr, to_addr, insn_len=5):
    return struct.pack("<i", to_addr - (from_addr + insn_len))
```

## Section addition

```python
import pefile
pe = pefile.PE("app.exe")
# find the last section, append, set characteristics RWX
```

Or use `lief`:

```python
import lief
b = lief.parse("app.exe")
sec = lief.PE.Section(".patch")
sec.content = list(payload)
sec.characteristics = lief.PE.Section.CHARACTERISTICS.MEM_READ | lief.PE.Section.CHARACTERISTICS.MEM_EXECUTE | lief.PE.Section.CHARACTERISTICS.CNT_CODE
b.add_section(sec)
b.write("patched.exe")
```

## ELF patching

```python
import lief
b = lief.parse("bin")
seg = b.get_section(".text")
seg.content[0x100:0x105] = [0x90]*5
b.write("patched")
```

## Integrity checksums

| Format | Fix |
|---|---|
| PE `CheckSum` | recompute (`pefile.generate_checksum()`) |
| ELF | none by default |
| Mach-O code signature | re-sign (`codesign -s -`) |
| App-specific | patch the checker |

## Verification

```bash
# confirm bytes
xxd -s 0x1234 -l 16 patched.exe
# disassemble
objdump -d --start-address=0x401000 --stop-address=0x401020 patched.exe
# run
./patched.exe
```

## Pitfalls

- Overwriting a relative jump's target without fixing the displacement produces a jump to a random address.
- Antivirus and code signing both notice modified binaries.
- Patching a DLL loaded from System32 requires admin and may be reverted by WFP.

## Verification

The disassembly at the patch site must show the intended instruction, and execution must behave as designed across multiple runs.
