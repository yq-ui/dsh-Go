---
name: business-logic-attack
description: "Business logic flaws: abusing workflow order, quantity and price manipulation, race conditions, and trial/reward abuse. Use this skill when the vulnerability is in the application's rules rather than its code."
---

# Business Logic

## Overview

Logic bugs are valid behavior used in an invalid order or quantity. No scanner finds them; you must model the business rules.

## Model the workflow

For each feature, write the intended sequence and its invariants:

```
cart -> checkout -> payment -> order
invariants: price fixed at checkout; quantity > 0; coupon used once
```

Then break each invariant.

## Common classes

| Class | Example |
|---|---|
| Negative quantity | `quantity=-1` refunds money |
| Price tampering | `price=0.01` in the request |
| Currency confusion | pay in a weaker currency |
| Coupon reuse | apply the same code repeatedly |
| Coupon stacking | combine two codes |
| Workflow skip | call `/order/confirm` before payment |
| Replay | resend a successful payment callback |
| Race | redeem a gift card twice concurrently |
| Trial reset | delete the account and re-register with the same email |
| Rounding | fractional amounts accumulate |
| Refund abuse | refund more than paid |

## Race conditions

```python
import requests, concurrent.futures
def redeem(i):
    return requests.post(URL, json={"code": CODE}, headers=H).status_code
with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
    print(list(ex.map(redeem, range(20))))
```

If more than one succeeds, the check-then-act is not atomic.

Single-packet attack (HTTP/2) for tighter races: `Burp Repeater > Send group in parallel`.

## Price manipulation

```http
POST /checkout
{"items":[{"id":"A","price":100,"qty":1}],"total":100}
```

Change `price` to 1 — if the server trusts it, you pay 1.

## Privilege workflow

```
POST /api/register {"role":"user"}
POST /api/register {"role":"admin"}
```

Mass assignment of role fields is a logic bug.

## Test method

1. Map every state transition.
2. For each, ask: what does the server validate vs. trust?
3. Send values that are valid types but invalid business-wise.
4. Confirm with a real effect (money, access, data).

## Pitfalls

- Automated scanning never finds these.
- Testing in production can create real orders — use a test account and cancel.
- Rate limits mask race conditions; use parallel single-packet techniques.

## Verification

The abuse must produce a concrete gain (free item, elevated role, extra credit) reproducible from a clean account.
