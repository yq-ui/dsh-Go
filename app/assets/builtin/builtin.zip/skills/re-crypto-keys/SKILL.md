---
name: re-crypto-keys
description: "Extracting cryptographic keys from binaries and processes: key derivation, key storage, obfuscated keys, and runtime key capture. Use this skill when the algorithm is known but the key must be recovered."
---

# Crypto Key Extraction

## Overview

Keys live in: `.rodata` as constants, a key derivation from a password, an obfuscated blob decrypted at startup, or a remote server. Match the technique to the storage.

## Static search

```bash
# high-entropy 16/24/32-byte runs in .rodata
python3 - <<'EOF'
import math, collections
d = open("bin","rb").read()
for i in range(0, len(d)-32, 16):
    w = d[i:i+32]
    c = collections.Counter(w)
    ent = -sum(v/len(w)*math.log2(v/len(w)) for v in c.values())
    if ent > 4.5 and len(set(w)) > 20:
        print(hex(i), w.hex(), round(ent,2))
EOF
```

```bash
strings -a bin | grep -E "^[A-Za-z0-9+/]{32,}={0,2}$" | head    # base64 blobs
```

## Derivation

Look for `PKCS5_PBKDF2_HMAC`, `EVP_BytesToKey`, `scrypt`, `argon2`. The salt and iteration count are usually adjacent constants.

```python
from hashlib import pbkdf2_hmac
key = pbkdf2_hmac("sha256", b"password", b"salt", 10000, 32)
```

`EVP_BytesToKey` (OpenSSL legacy): MD5 chained — reproduce exactly:

```python
import hashlib
def evp_bytes_to_key(pw, salt, n=32):
    out, prev = b"", b""
    while len(out) < n:
        prev = hashlib.md5(prev + pw + salt).digest()
        out += prev
    return out[:n]
```

## Obfuscated keys

Common encodings: XOR with a constant, byte rotation, split across two locations combined at runtime, or a key-wrapping scheme (AES-KW).

Technique: breakpoint the cipher init (`EVP_CipherInit_ex`, `BCryptGenerateSymmetricKey`, `CCCryptorCreate`) and read the key argument.

```javascript
// Frida: dump key material at cipher init
const f = Module.findExportByName(null, "EVP_CipherInit_ex");
Interceptor.attach(f, {
  onEnter(a) { console.log("key:", hexdump(a[3], { length: 32 })); }
});
```

```python
# GDB
# break EVP_CipherInit_ex
# x/32xb $rcx
```

## Runtime scan

If the key is in memory:

```javascript
// scan for a known plaintext, then dump surrounding memory
Memory.scan(base, size, "41 42 43 44", { onMatch(m) { console.log(hexdump(m.add(-64), {length:128})); }, onComplete(){} });
```

## Protected keystores

- Android `KeyStore` — keys never leave the TEE; hook the crypto operation's input/output instead of extracting the key.
- iOS `SecKey` — same; hook `SecKeyCreateDecryptedData`.
- Windows CNG/DPAPI — decrypt in the user's context via `CryptUnprotectData`.

## Asymmetric keys

Private keys appear as DER/PEM blobs or as `RSA` CRT parameters (two primes, exponents). Search for the ASN.1 header `30 82` in `.rodata`, or for the presence of `n`, `e`, `d` in a struct.

```bash
openssl asn1parse -inform DER -in blob.der
```

## Pitfalls

- A key that appears random may be a hash of something predictable — check `sha256(known)`.
- Keys derived per-install are in device-specific storage, not the binary.
- Hardware-backed keys cannot be extracted; intercept the operation.

## Verification

The extracted key must decrypt a real captured ciphertext into plausible plaintext.
