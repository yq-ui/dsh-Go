---
name: novel-skills-catalog
description: 网文/小说/短剧 Skill 总表（211 条，来源 UnderleveledBuilder/awesome-novel-skills）。写书或选型前查这张表：按阶段（选题/扫榜/拆文/设定/大纲/正文/长篇记忆/去AI味/审稿/封面/发布/翻译）找可装的 skill，再决定是否现装。触发：选 skill、找工具、扫榜/拆文/设定/大纲/去AI味 缺工具、「该用哪个 skill 写小说」。
---

# 网文 Skill 总表

这是选型目录，不是写作方法本身。写作方法用已装好的 `story-*` 系列。

## 一、已装好、直接用（不要重复装）

| 场景 | 技能 |
|---|---|
| 长篇规划＋写作（开书/设定/卷纲/章纲/续写/回炉） | `story-long-write` |
| 短篇写作 | `story-short-write` |
| 长篇拆文（黄金三章/逐章摘要/节奏/因果） | `story-long-analyze` |
| 短篇拆文 | `story-short-analyze` |
| 扫榜（起点/番茄/晋江/七猫/盐言） | `story-long-scan`、`story-short-scan` |
| 去 AI 味（表达/叙事/因果三层诊断） | `story-deslop` |
| 中文空话与模板化（31 检查点） | `humanizer-zh` |
| 多视角对抗审查 | `story-review` |
| 发布资料（书名/简介/分类/标签） | `story-publish` |
| 封面提示词 | `story-cover` |
| 导入已有小说、反向解析成项目结构 | `story-import` |
| 环境与项目结构部署 | `story-setup`、`story` |
| 浏览器操控（番茄后台/扫码/发布） | `browser-cdp` |

## 二、写小说/写文章的固定流程（He 的硬要求）

1. 动笔前：`story-long-write`（或短篇对应技能）读一遍，按它的结构走；不要凭手感直接写。
2. 写完：`story-deslop` 过一遍 AI 味，再 `humanizer-zh` 收空话。
3. 交稿前：`story-review` 三视角审（结构/人物/语言）。
4. 发布：`story-publish` 出资料 → `browser-cdp` 上番茄后台 → 草稿 → He 按发布。

## 三、需要新能力时怎么查

全量 211 条在 `references/catalog.md`，按 10 组分类：
pipeline（全流程）｜tools（单项）｜short（短篇）｜script（短剧）｜companion（陪伴）｜craft（写作技法）｜beyond（衍生）｜translate（出海）｜sources（书源下载）｜apps（完整应用）

查法：先看「阶段」列（market/structure/drafting/memory/revision/packaging），再看层级（featured 是实测靠前的）。

## 四、精选 10 条（第二轮实测靠前或独特）

1. `Narcooo/inkos` — 故事创作 Agent 系统，长短篇＋拆文＋剧本
2. `zenstory-ai/oh-story-claudecode` — 中文网文全流程（已装）
3. `PenglongHuang/chinese-novelist-skill` — 从零生成 10–50 章，三层问答＋创作记忆
4. `danjdewhurst/story-skills` — 端到端故事工程＋连续性检查＋读者评审团
5. `jiaw-Zh/long-novel-writer` — 百万字长篇：六层摘要冻结、正典账本、POV 知识边界
6. `xiaofeng-928/chinese-longnovel-skill` — 扫榜开书＋文风蒸馏＋事实锁
7. `lingfengQAQ/webnovel-writer` — 分阶段初始化设定与总纲
8. `op7418/Humanizer-zh` — 去 AI 味（已装）
9. `larashero3-dotcom/lieflat-less-ai-tone` — 用 283 万字对照语料筛出的 11 项 AI 味特征
10. `MrGeDiao/shuorenhua` — 中文优先去套话改写，保数字/条件/承诺/口气

## 五、安装方式（要现装时）

```bash
npx -y skills add <owner>/<repo> --agent claude-code
# 或直接把 repo 里的 SKILL.md 复制到 ~/.dsh/skills/<name>/
```

装完检查：`ls ~/.dsh/skills/<name>/SKILL.md`，frontmatter 必须有 `name` 与 `description`。
