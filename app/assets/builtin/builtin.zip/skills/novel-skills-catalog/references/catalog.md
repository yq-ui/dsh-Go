# 网文 Skill 总表（211 条，来源 UnderleveledBuilder/awesome-novel-skills）

> 全量目录。写书前按 need 查这张表 → 决定要不要现装某个 skill。

## 全流程：开书 → 连载（53）

| 仓库 | 说明 | 阶段 | 层级 |
|---|---|---|---|
| `Narcooo/inkos` | 故事创作 Agent 系统：长短篇写作、续写、同人、仿写、拆文、市场调研、剧本、互动影游 | market,structure,drafting,memory,revision,adaptation | featured |
| `PenglongHuang/chinese-novelist-skill` | 从零生成 10–50 章中文小说：三层问答、创作记忆、每章悬念钩子、自动校验 | structure,drafting,memory,revision | featured |
| `danjdewhurst/story-skills` | 端到端故事工程：故事圣经、角色、情节、章节、修订、连续性检查、读者评审团、投稿 | world,character,structure,drafting,memory,revision | featured |
| `jiaw-Zh/long-novel-writer` | 百万字长篇写作 skill：六层摘要冻结、实体档案、正典账本与 POV 知识边界，写后双 agent 校验，防止设定漂移 | world,character,structure,drafting,memory | featured |
| `lingfengQAQ/webnovel-writer` | Claude Code 长篇网文插件：分阶段初始化设定与总纲、拆卷纲章纲，写章后多维审查并把事实提交进状态库与 RAG，可查伏笔角色，附只读面板 | market,world,character,structure,drafting,memory,revision | featured |
| `xiaofeng-928/chinese-longnovel-skill` | 中文长篇网文工作流：扫榜开书、范文拆解与文风蒸馏、每 50 章分阶段细纲、事实锁与状态仓库、伏笔追踪、双审查自动修复 | market,world,structure,drafting,memory,revision | featured |
| `zenstory-ai/oh-story-claudecode` | 中文网文全流程：扫榜（起点/番茄/晋江/知乎盐言）、拆文、长短篇写作、去 AI 味 | market,structure,drafting,revision,packaging | featured |
| `304769384-png/fanqie-novel-skill` | 番茄长篇写作 skill：写前读状态文件，写后去 AI 味并跑 8 项最小审计（字数、因果链、战斗、对话占比、话疗、循环等） | structure,drafting,memory,revision |  |
| `ExplosiveCoderflome/ani-book-skill` | 长篇中文小说生产：可恢复的 Markdown 工作流，贯通灵感、规划、章节写作、审校与连续性管理 | structure,drafting,memory,revision |  |
| `Fly143/ultimate-novel-creation-skill` | 长篇小说全流程 skill：书名立项、世界观人设、黄金开篇、单章写作、记忆圣经与强约束、读者审稿、写后流水线 | packaging,world,character,structure,drafting,memory,revision |  |
| `LAY-lgtm/novel-writing-framework` | 五份网文写作方法论：通用长篇流程、番茄快节奏、起点慢热、智斗权谋专项、完稿改良诊断，含三章一轮自检和 AI 指纹量化指标 | structure,drafting,revision |  |
| `MJbae/awesome-novel-studio` | 网文创作 Claude Code 插件：设定、角色、情节钩子、润色、重写 | world,character,structure,drafting,revision |  |
| `Thatgfsj-easyRep/wangwenwrite-skill` | 男频系统流网文单文件 skill：黄金三章、爽点节奏公式、系统设定法则、反 AI 味清单、书名公式与平台差异化 | market,world,structure,drafting,revision,packaging |  |
| `Tomsawyerhu/Chinese-WebNovel-Skill` | 网文写作 skill：主路由分派到开头、转场、对白、章末、剧情逻辑、人物一致性、卷纲、去 AI 味等 10 个模块，写前检索本地语料范例 | market,character,structure,drafting,memory,revision |  |
| `TulanCN/vibe-noveling` | Claude Code 网文插件：苏格拉底式设定讨论、救猫咪全书规划、雪花法事件卡、写后 AI 味检测、标记返修、知识图谱 | world,character,structure,drafting,memory,revision |  |
| `Wooooooooood/ai-fiction-writer` | 长篇网文十个 skill：扫榜拆文、大纲、角色、知识库、世界与地图、逻辑矩阵、进度、正文、去 AI 味质检、多视角审稿 | market,world,character,structure,drafting,memory,revision |  |
| `XINGANLIU/web-novel-writing-skill` | 网文 10 阶段流水线：灵感、世界观、人物、总纲、卷纲、章纲、黄金三章、正文、质检、状态同步，含人物漂移和反派降智检查 | world,character,structure,drafting,memory,revision |  |
| `ZhangDongyang800/novel-flow-one-by-one` | 6 个协作 skill：脑暴→大纲→逐场景写作→六维审稿→设定同步，总控按状态路由，内置冷白描/系统爽文/怪诞悬疑三种文风 | world,character,structure,drafting,memory,revision |  |
| `bbroot/novel-master` | OpenClaw 长篇小说 skill：策划书、分卷大纲与细纲、三层伏笔追踪、角色状态机与节点压缩图谱、每章四维审计 | world,character,structure,drafting,memory,revision |  |
| `chanceline-max/novelist-skill` | Codex 中文小说 skill：从灵感到卷纲章纲、正文续写与改稿，维护人物、世界观、伏笔、时间线和章节总结文件 | world,character,structure,drafting,memory,revision |  |
| `chaserr/novel-craft` | Claude Code 长篇写作与审稿插件：5 个 skill + 12 个 agent，用 RTK.md 定题材风格，管大纲、前情、伏笔、人物档案和逐章审稿 | character,structure,drafting,memory,revision |  |
| `cnskycn/novel-writing-skill` | 长篇连载单文件提示词：大纲 6 步、章节 7 步、人物三锚点、伏笔 P1-P3 分级、六维质检，附追踪与记忆文件模板 | structure,drafting,memory,revision |  |
| `dama-cyber/Distilled-Novel-Toolbox` | 网文写作知识库 13 个 skill：题材、人设、世界观、节奏、爽点、情绪、文风、商业化、合规、润色去 AI 味与 AIGC 检测应对 | market,world,character,structure,drafting,revision |  |
| `dongyanyuxuana/novel-craft` | 通用小说 skill：主控加 7 个子代理，访谈立项、资料拆分、逐章写作、逐段 17 维审查、修订发布，附 34 位作家技法库 | market,world,character,structure,drafting,memory,revision |  |
| `duiniwukenaihe/novel-assistant-skill` | 单入口网文助手：短篇/长篇写作、审阅、拆文、扫榜、导入、去AI味，带任务断点续写、按步召回记忆、改纲影响链和章节扩容迁移 | market,world,character,structure,drafting,memory,revision |  |
| `huahuakandaima/human-novel-writer` | 长篇网文全流程：项目骨架与三总控文件、黄金三章合同、角色入场门禁、每章 8 步循环、拆文选题审稿封面，去AI味双门禁脚本 | market,world,character,structure,drafting,memory,revision,packaging |  |
| `jialanhu0915/silver-novel-skills` | 男频/女频双系统网文写作：世界观/人物/情节三个框架 agent，按题材加载模板，12 项通用加男女频专项审稿 agent | world,character,structure,drafting,revision |  |
| `jiangying3222880/novel-engine` | 网文写作引擎：拆对标书建素材池，细纲、正文、检验打回、落库四段流水线，管长篇状态，另有短故事模式和 BM25 检索 | market,world,character,structure,drafting,memory,revision |  |
| `kongxcer555/open-novel-fanqie` | 番茄网文长篇流水线 12 个 skill：拆对标书出套路 JSON、换壳选切入点、书名简介与事件、大纲人物设定、细纲、正文、审稿、滚动摘要 | market,world,character,structure,drafting,memory,revision,packaging |  |
| `kshanxs/book-writer-skill` | 英文长篇写作：Story Forge 开书问答，Book Memory Bank 自动维护人物/世界/进度，含节奏蓝图、专项修订与简介/query letter | world,character,structure,drafting,memory,revision,packaging |  |
| `liuxiao20051106-prog/novel-writer-skill` | 中英双语小说写作 skill：构思、人设、章纲、逐章写作与章节衔接检查、去 AI 味，附草稿量化体检脚本和 11 套追踪模板 | market,character,structure,drafting,memory,revision |  |
| `lornshrimp/Lorn.NovelWriteSkills` | 长篇网文写作资产库：题材定位、人物、大纲、章节创作闭环、审阅润色、去 AI 味、13 个平台改写与分发，附字数/相似度门禁脚本 | market,world,character,structure,drafting,revision,packaging,publish |  |
| `lujih/webnovel-writer-opencode` | webnovel-writer 的 OpenCode 移植增强版：在初始化、规划、写章、审查之外加了批量写、重写、修复、导出和番茄/七猫发布 | world,character,structure,drafting,memory,revision,publish |  |
| `lvyu-cmd/chinese-novelist-skill` | 中文长篇小说 skill：五项输入自动生成设定，逐章或子 Agent 并行写作，三层记忆、七维自动校验、章节评分和三级修订 | world,character,structure,drafting,memory,revision |  |
| `manhai934/novel-harness` | 网文陪写 harness：开书规划，把章节拆成作者自己填的写作块，审稿去 AI 味，维护角色状态、伏笔和章节摘要 | world,character,structure,drafting,memory,revision |  |
| `modoojunko/awesome-novel-agent` | 小说创作搭档：世界观 → 角色 → 章节规划 → 正文，分步陪写整部小说 | world,character,structure,drafting |  |
| `qin1473692580-ux/oh-story-claudecode` | oh-story 派生网文 skill 包：扫榜拆文、长短篇写作、去 AI 味、封面，另加后台数据诊断、资料考证、发布物料和番茄自动发布 | market,structure,drafting,memory,revision,packaging,publish |  |
| `qingyabailu-git/webfiction-write` | Codex 网文工具集 15 个 skill：构思、扫榜、拆文、卷纲细纲、写作与改稿、审查、去AI味、设定查询、导入导出，附项目状态脚本 | market,world,character,structure,drafting,memory,revision |  |
| `qiyan233/novelops-skill` | 长篇小说状态化流水线：truth files 记设定与角色认知，生成下一章工作包，LLM 起草，审计修订，状态回写，快照 diff | structure,drafting,memory,revision |  |
| `ricky-theseus/DaisyWriter` | 网文与中短篇写作 skill 合集：扫榜、拆书、开书、大纲、批量写作、审查、去 AI 味、封面生成、番茄自动发布 | market,world,character,structure,drafting,memory,revision,packaging,publish |  |
| `skyfiredao/dreampowers` | OpenCode 中文小说技能包：14 个 skill，覆盖构思、七维文风问卷、设定文件隔离、大纲伏笔、分场景写作、冷读与一致性审查 | world,character,structure,drafting,memory,revision |  |
| `soultt/fanqie-xiaoshuo-skill` | 番茄风网文 11 个 skill：设定、总纲与章纲的设计和审查、正文写作和审查、签约潜力评估、日更工作流 | world,character,structure,drafting,revision |  |
| `tance-mang/chinese-webnovel-skills` | 网文工坊 Claude Code 插件：选题、起名、大纲、金手指、人设、扩写、爽点、追读诊断、连贯检查、去 AI 味、投稿等 30+ 技能 | market,world,character,structure,drafting,memory,revision,packaging |  |
| `tianshiemo7/long-novelist-skill` | 百万字长篇中文小说：13 步配置问答、副本弧线三级大纲、角色状态档案、JSON 伏笔清单、跨会话恢复，附 11 个网文素材库 | world,character,structure,drafting,memory |  |
| `tinylion1024/web-novel-master` | 网文创作工作流：快速、专业、工业、一次生成四种模式，含 11 个赛道的作者文风卡、套路库、平台定位包和项目初始化与校验脚本 | market,world,character,structure,drafting,memory,revision,packaging |  |
| `waylean/plotrail` | 长篇工作流两件套：plotrail 建 canon、章节合同、写后连续性审稿和作者改稿偏好；plotrail-intake 诊断精修已有旧稿再交接续写 | world,character,structure,drafting,memory,revision |  |
| `xiaotiewinner/xt-webnovel-writing` | OpenClaw 网文 skill：参考文本拆解、立书（书名/人设/简介）、剧情设计、爽点与文笔、25 项反 AI 味体检、磁盘记忆 | market,character,structure,drafting,memory,revision,packaging |  |
| `xiaoyuCR7/general-novel-skill` | 长篇网文 skill：每章正文与摘要、角色状态、伏笔、时间线按事务一起提交，7 道去 AI 味闸口，34 题材与多平台规则按需加载 | market,world,character,structure,drafting,memory,revision,packaging |  |
| `xindoo/sumeru` | 网文全流程 7 个 skill：选题（含榜单分析）→世界观大纲→章节批量撰写→时间线/OOC 审查→润色→多平台导出，可断点续写 | market,world,character,structure,drafting,memory,revision |  |
| `xwcai999/opencreator-novel` | 中文小说 Codex 插件：读者契约与章节控制卡、待兑现承诺账本、确定性校验脚本、整书文学审稿与跨章结构相似度检查、封面 | structure,drafting,memory,revision,packaging |  |
| `zenstory-ai/oh-story-dsh` | 把 Oh Story 小说技能装进 DeepSeek Harness：加了文件树、编辑器、Chat 三栏的小说工作台，另带短剧、小说改游戏、视频解说工作台 | market,world,character,structure,drafting,revision,packaging,adaptation |  |
| `zlbigger/novel-webfiction` | OpenClaw 网文连载 skill：开书问 4 个问题建档，每章先读设定、大纲和最近 3 章再写，正文按章存进 Obsidian | world,structure,drafting,memory |  |
| `zy-zmc/tianming-skill` | 长篇协同创作指令系统：用五份知识库约束世界观与人物，按「天命：大纲/目录/正文/体检/存档」逐步推进 | world,character,structure,drafting,memory |  |

## 单项工具：拆书 · 设定 · 大纲 · 人物（12）

| 仓库 | 说明 | 阶段 | 层级 |
|---|---|---|---|
| `Elowwwen/Fanfic-background-assistant` | 同人文背景研究：梳理时代、地点、职业、制度等资料并附来源，检查草稿里的事实错误，维护背景手册，不碰剧情 | world |  |
| `Kirby980/auto-fanqie` | 番茄作家后台自动发章：先校验字数，再用 Playwright 打开本机 Chrome，按书名和分卷新建章节、填正文并处理发布弹窗 | publish |  |
| `WindXRan/fanqie-radar` | 番茄榜单扫榜选书：内置榜单快照和采集器，算题材热度、多日趋势差分和六维仿写适合度评分，附 MCP 服务与看板 | market |  |
| `XTmingyue/wenfeng-skill` | 给一部小说文本，提炼叙事模型、语言指纹、母题、人物与情节技法，生成可直接调用的仿写 SKILL.md | market,drafting |  |
| `amm10090/fanqie-publisher-skill` | 番茄小说作者后台章节发布：解析本地 Markdown 章节，用 Playwright 自动填写，立即或定时发布，带仅填写模式和发布后状态核验 | publish |  |
| `ciel-oliver/analyze-hit-novel` | 爆款小说拆文：六维拆书、双时间线、三维节奏、人物关系图 PNG，提炼爆款机制并附章节证据 | market |  |
| `oscar-wang-xin/xin-skills` | 122 个文风锁定 skill：从番茄热门书和金庸、古龙等指定小说萃取十维风格规范，只仿文笔不抄剧情 | drafting |  |
| `rs-skills-lab/fictional-erotica` | 中英双语成人情色场景写作与修订：可调明确度、语域、对白密度和场景重心，保持人物声口和身体动作连续，支持原创与同人 | drafting,revision |  |
| `shigehaomingzi1/character-card-fiction-workflow-skill` | 从草稿、聊天记录或小说提炼角色设定和原文证据，生成酒馆 AI（SillyTavern）角色卡，也能扩写、续写小说 | character,drafting |  |
| `wgwtest/novel-project-strategy` | Codex 长篇项目管理 skill：定义加载顺序、章节状态与同步规则，新会话不读全文也能恢复项目，防止大纲、设定、正文互相漂移 | memory |  |
| `xWebt/chinese-erotic-fiction-writing` | 中文成人向（H）小说写作 skill：动笔前勘察偏好，按写作规范写作、扩写、重写，可学习本地书库文风，会话记忆逐步收敛口味 | structure,drafting,revision |  |
| `xbraindance/Creative-writing-skill` | 用 Verbalized Sampling 一次给出多版点子、开头、大纲和人物，草稿自动归档进项目 wiki，带卡文诊断和批评命令 | world,character,structure,drafting,revision |  |

## 短篇 · 故事（6）

| 仓库 | 说明 | 阶段 | 层级 |
|---|---|---|---|
| `AAAAAAAJ/sun-yuchen-writing` | 冷峻账单式第一人称短篇：先建数字、物件、劳动、空缺四本素材账和叙述者盲点表，按新题材重造双层故事，排六到八个场景、结尾回收物件；附十维审稿量表 | structure,drafting,revision |  |
| `EnderRomantice/horror-weird-fiction-skill` | 怪异恐怖短篇写作 skill：从日常场景放入单一异常，按同一方向升级 2 到 4 次，不解释来源收尾，避开鬼怪、血腥和惊吓桥段 | drafting |  |
| `LanyXiaosheng/bookflow-skill` | 番茄短篇项目化生产：选题、对标、人物、大纲、beat、正文、QA、复盘 | market,character,structure,drafting,revision |  |
| `aby-aby111/fanqie-short-story.skill` | 番茄短故事创作：8 条赛道逐级选题、标题生成打分、5 段式结构与章末三层钩子、字数校验与手机排版 | market,structure,drafting,packaging |  |
| `asass-11/lengdu` | 中文短篇创作与冷读：先写完正文，再由独立校准 Agent 和全新读者 Agent 首读，检验看懂、流畅、好看 | drafting,revision |  |
| `leonluo2008-ops/jiamama-bedtime-story-skill` | 中文儿童睡前故事，从 2101 篇语料蒸馏出的叙事人格 | drafting |  |

## 剧本 · 短剧：用写网文的功夫写剧情（51）

| 仓库 | 说明 | 阶段 | 层级 |
|---|---|---|---|
| `A-cat-with-carrots/OnlyShot` | 神仙鱼短剧流水线：一句话 → 剧本、分镜、分镜图、视频、剪辑五步，沉淀 17 种失败模式 | drafting |  |
| `AharaOoO/acheng-director-skill` | Acheng 导演引擎：剧本、分镜、文戏五轨表演、打戏因果链、特效与资产，编译成 MiniMax H3 / Seedance 提示词 | character,drafting,revision |  |
| `Hao0321/ai-short-drama` | 把「重生、逆袭、隐藏大佬」等题材编译成有爽点和追更钩子的连载：题材调研、故事架构、镜头时间线、连续性校验 | market,structure,drafting,revision |  |
| `JohnKeating1997/spark-video` | 一句梗概 → 剧本、分镜、角色/场景/道具一致性、渲染、逐镜 AI 质检到成片 mp4，每阶段设确认关卡 | character,drafting,revision |  |
| `LuoJiangYong/muse-video-skill` | 虚拟剧组：导演/编剧/摄影/美术/特效/声音六角色协作，创意 → 剧本、分镜、美术、提示词，38 个案例技法库 | drafting,revision |  |
| `MIKA6941/Comfy-H3-Director` | MiniMax H3 漫剧导演：网文改分镜、核心/龙套资产分级、文戏长镜与武戏快切、动作连续性锁定、尾帧接力，一次出整集提示词 | character,adaptation |  |
| `Shanyin-ai/shanyin-screenwriting-master` | 山音超级编剧大师：概念超短片、叙事短片、长片、多集剧集四种格式的人物、大纲、场景拆解和完整剧本 | character,structure,drafting |  |
| `SoloEnt-AI/5min-drama-contest` | 五分钟短剧剧本：一步一问锁定赛道、立意、结构原型和前 30 秒开场，四幕卡点大纲 → 正式剧本 → 分镜脚本 | character,structure,drafting |  |
| `SwotAtmk/infinite-creation` | 提交小说或剧本，用本地 ComfyUI + MiniMax H3 + Agent 自动连续生产视频，不限时长 | adaptation |  |
| `Tencent/workrally` | 腾讯开源：面向 AI Agent 的 AIGC 漫剧视频创作全流程工具集 | drafting |  |
| `UncleWang2088/short-drama-director` | 短剧导演专家包：剧本创作、平台标准审稿、镜头级分镜与表演指导，输出 Seedance 提示词 | drafting,revision |  |
| `VanGong1999/screen-creative-skills` | 影视策划与评估：小说/IP 评估、情节点拆解、人物小传与关系、大纲、小说改编短剧或长剧 | market,character,structure,adaptation |  |
| `Vi7QY/screenwriter-skill` | 短剧/漫剧剧本审稿：红果 Top100 操盘经验蒸馏的 37 条规则 | revision |  |
| `YvonneMovingon/short-drama-skills` | LuxReal 生产验证的短剧提示词：叙事拆解、情绪刻画、动态描述、剧情拆分、视频提示词润色 | drafting,revision,adaptation |  |
| `adoria111/emma-screenwriting-skills` | 艾玛短剧技能组：结构拆解、改编、选题迭代、期待设计、逐集钩子、集纲扩写、对白诊断、剧本删减 | market,structure,drafting,revision,adaptation |  |
| `catyiqian/qianqianwriting` | 短剧/漫剧编剧：救猫咪方法论 + 31 部爆款短剧分析 | structure,drafting |  |
| `djyy1031/ai-comic-drama-director-skills` | AI 漫剧导演：剧本 + 已有资产 → Seedance 2.0/2.5 分镜组提示词，含人物表演、导演摄影、场景资产、站位图、连续性与声音 | character,revision,adaptation |  |
| `e06084/claude-screenwriting` | 编剧知识引擎：把 Vogler/McKee/救猫咪落成 Obsidian 故事 wiki，15-beat 节奏、三层角色卡、结构诊断 | character,structure,revision |  |
| `egguy886/write-screenplay-skill` | 小说/设定转商业剧本，国内短剧与出海微短剧双模式 | drafting,adaptation |  |
| `eternityspring/shuohao-skills` | 短剧制作 skill 集：拆角色、改编大纲、场景与道具美术设定、剧本、分镜 | character,structure,drafting,adaptation |  |
| `geslie1/kunka-screenwriting-master` | 昆卡编剧大师：中文优先的编剧 skill 组，覆盖构思、改稿、连续性检查与剧集开发 | structure,drafting,revision |  |
| `ilkaydemiralay/vision_art_creator` | 影视部门式 skill 包：编剧、导演、角色、美术、摄影、分镜、镜头表、提示词、声音、剪辑，由总监 skill 调度和质检 | character,drafting,revision |  |
| `jlam00-dev/hardcore-director` | 硬核导演：影视与 AI 视频总控，按阶段路由编剧/短剧、角色场景、分镜、Seedance 2.5/Wan 3.0/H3 提示词、声音与剪辑模块 | character,structure,drafting,revision |  |
| `jtydhr88/screenwriting-skills` | 编剧理论最系统的一套：结构、Truby、场景、对白、剧集圣经、编剧室，含日韩法美与中国戏曲案例 | character,structure,drafting,revision,adaptation |  |
| `jxshow/jingju-skills` | 鲸剧：AI 漫剧全流程，大纲、人设一致性、分集剧本、分镜、图/视频提示词、ComfyUI 批量出图 | character,structure,drafting |  |
| `liangdabiao/Seedance2-Storyboard-Generator` | 把小说或故事改成多集视频剧本和分镜，产出 Seedance 2.0 提示词 | drafting,adaptation |  |
| `liangdabiao/smy-seedance-storyboard` | 故事 → 上美影复古手绘风格的短剧制作文档：剧本、分镜、资产生图提示词，附完整示例项目 | drafting,adaptation |  |
| `liuxiao20051106-prog/ai-manga-drama` | AI 漫剧工坊：一句创意到成片的八步流程，任务卡剧本、角色参考图库、风格锚、分镜、图/视频提示词、配音字幕与合成终检 | character,structure,drafting,revision |  |
| `lixiaoxiao9888-create/manju-laoli-skill` | 漫剧老李：AIGC 漫剧导演全流程，门控剧本、资产锁定、分镜、投喂提示词、规则化质检 | drafting,revision |  |
| `lixiaoxiao9888-create/short-drama-factory` | 抖音/红果短剧工业化编剧：一句创意或一部网文 → 60–100 集带付费卡点的剧本，配钩子、断章、反转公式和机检规则 | structure,drafting,revision,adaptation |  |
| `liyue-aigc/seedance-2-5-video-director` | Seedance 2.5 视频导演：提示词、脚本、诊断、人物锁定、续写、编辑、转场 | drafting,revision |  |
| `machina-exm/film-studio-skills` | 剧本 → 锁定、可直接生成的镜头：7 个 skill 复刻商业 AI 视频制作流程 | drafting |  |
| `mengxiujie/ManjuForge` | 漫剧/短剧连载引擎：一句话 → 剧本、分镜、配音、提示词，7 个记忆文件 + 22 项一致性检查防人设崩坏 | structure,drafting,revision |  |
| `mini-yifan/open-source-video-gen-skill` | Vibe Video：在 AutoDL 上跑开源 MiniMax H3 出片，短剧模板串起 Brief、分集概要、剧本台词、美术和视频，含 H3 提示词写法 | character,structure,drafting |  |
| `mudden2380078550-creator/write-chinese-long-screenplay` | 中文电影与长剧集剧本写作 | structure,drafting |  |
| `muxia0396/novel-to-ai-short-drama-skill` | 从导演视角把小说改编成 AI 短剧：分镜、运镜、表演调度与时长 | adaptation |  |
| `oiuv/ai-short-drama` | 雪风爽剧：一句话补全创作需求，按爽点模型写分集剧本并同步角色/场景/道具档案，再拆镜写 Seedance 2.0 提示词 | character,structure,drafting |  |
| `pipivv/gushi-skill` | 从麦基《故事》蒸馏的短剧编剧方法 | structure,drafting |  |
| `qualsenWeb/fight-video-create-skill` | AI 打戏设计：从打斗构思到剧情、动作、分镜，带招式校验和参考库 | drafting |  |
| `senmanx/novel-to-manju` | 小说转漫剧全流程：爆款改文 → 剧本 → 人物/场景三视图 → 分镜 → 视频提示词 | character,drafting,adaptation |  |
| `suihe1/short-drama-production` | 短剧生产总控：小说大纲/人物/剧本、导演分镜、提示词、声音资产、粗剪与 QC（默认 16:9） | structure,drafting,adaptation |  |
| `wddxh/ShortVideoDirector` | 4 个子代理协作，把故事创意转成视频分镜提示词和资产图像提示词 | character,structure |  |
| `wyuzhi/qisi-video-remix` | 视频创意改编：参考视频 → 剧本 → 分镜 → 分段生成提示词 | drafting,adaptation |  |
| `xixihhhh/ai-short-drama-skill` | Dramake：文字转 AI 短剧，串起剧本、分镜、配音、剪辑与质检，适配抖音/红果和横竖屏，自带 evals | drafting,revision,adaptation |  |
| `zenstory-ai/drama-skills` | 短剧/漫剧全链路：拆小说、开发、剧本、角色资产、分镜、图/视频提示词、审查 | character,drafting,revision,adaptation |  |
| `zhaihao118/Micro-Drama-Skills` | 短剧全流程自动化：剧本、角色设计、分镜、出图出视频与提交 | drafting |  |
| `zhlmi/narrative-to-screen-reader` | 把手上的故事翻译成影视开发语言：快速诊断、编剧改编读本、导演视听读本、演员读本、制片摘要 | market,character,adaptation |  |
| `zhlmi/screenplay-review-checklist` | 对抗式剧本踩雷诊断：拿 37 条判据只给你的故事找问题 | revision |  |
| `zhouwei713/chinese-epic-scene-director` | 中国式宏大场景：把一句设定扩写成仙侠/神话短片故事，建连续性台账，按镜头成对输出图片和视频提示词 | character,drafting |  |
| `zhu5859243-free/hongguo-shortdrama-screenwriting` | 红果/抖音爆款短剧编剧：短剧工厂引擎 + 《短剧编剧第一课》01–10 期方法论 | structure,drafting |  |
| `zhurui0523/XiaoLuo-AI-Drama-Skill` | 小逻系列：剧本分析、原创改编、分镜脚本、角色三视图/服装/表情、场景布局 | character,drafting,adaptation |  |

## 去 AI 味 · 润色（30）

| 仓库 | 说明 | 阶段 | 层级 |
|---|---|---|---|
| `MrGeDiao/shuorenhua` | 中文优先的去套话改写：保留数字、条件、承诺和作者口气，可选自由/句内/原位三档改动范围，附 123 条评测集 | revision | featured |
| `larashero3-dotcom/lieflat-less-ai-tone` | 用 283 万字人机对照语料检验 26 项「AI 味」特征，只按通过检验的 11 项改写，附可复算的检测脚本 | revision | featured |
| `op7418/Humanizer-zh` | blader/humanizer 的中文改编版：按 31 个检查点（含 6 项中文专项）清理空话和模板句，保留事实、确定程度与作者语气 | revision | featured |
| `Hyacehila/humanizer-zh-next` | 中文润色去 AI 味：35 类模式各配中文示例和适用边界，按需加载商务营销、学术写作、基金申请三个专用分支 | revision |  |
| `KKKKhazix/human-writing` | 活人感写作：让 AI 写的中文像具体的人在说话，适用小说、公众号、口播等 | revision |  |
| `LifelongLazyLearner/qu-ai-wei` | 简体中文去 AI 味：清理套话、翻译腔和机械排比，保留事实、正式程度和原文声口，没有问题的真人文字不改 | revision |  |
| `Nanako0129/sepia` | 面向小说的去 AI 味：修复叙事结构，按场合匹配文风规则，方法来自 StoryScope 论文 | revision |  |
| `OUBIGFA/De-AI-Prompt-Enhancer-Writer-Booster-SKILL` | 中文去 AI 味 + 作者文风复现两套 skill，小说文本会先过叙事层十项检查（主题被说破、情绪只靠身体反应等） | revision |  |
| `Raymondhou0917/speak-human-tw` | 繁体中文去 AI 味：抓 35+ 种 AI 写作痕迹，同时把大陆用语和半角标点改成台湾写法，附交稿前自评检核表 | revision |  |
| `YuliangXiu/de-ai-router` | 去 AI 味路由：按文本类型和意图从 10 个去 AI 味 skill 中选首选与备选再执行，中文文本路由到 qu-ai-wei / humanizer-zh | revision |  |
| `aeopress/writing-skills.TW` | 繁体中文（台湾）去 AI 味与节奏打磨：humanizer-tw 清 AI 腔和大陆用语，good-writing-tw 调句子节奏，附英文 humanizer | revision |  |
| `aimerfeng/novel-to-webnovel` | 把日轻译稿、机翻稿的翻译腔改成中文网文口感：分三档程度，格式清理、风格定调、样例确认、分块并行改写、QA 脚本 | revision |  |
| `allenloves/de-ai-tone` | 繁体中文写作与翻译的去 AI 味规范：18 条禁用/限用规则、欧化句式还原、台湾用语对照、生成后逐条自检 | revision |  |
| `baibanbao/qu-ai-wei` | 中文去 AI 味：合并王佩写作系统、humanizer-zh、lieflat 三家规则并裁决七处冲突，分自家稿、白名单两种改稿模式 | revision |  |
| `betterwu7889/human-tone-writing` | 人味写作三层法：先按金字塔原则写对结构，再从立场、细节、节奏上去 AI 味，最后补说服力和个人风格 | revision |  |
| `blader/humanizer` | 按维基百科「Signs of AI writing」清单去除 AI 写作痕迹 | revision |  |
| `cxzxx783/mohen` | 中文自媒体人味写作 skill：写前调研、标题、成稿、12 项去 AI 味硬门槛、AI 味评分和平台适配，附质检脚本与网页版单文件 | revision |  |
| `deedeekong07-alt/fiction-humanizer-zh` | 中文小说去 AI 味：修复梗概感、情绪标签、对白汇报腔、冲突无代价，按铺垫-过程-余波重写，强化前 300 字和章末钩子 | revision |  |
| `evoworkAI/xiaoci-skill` | 中文去 AI 味：23 条带密度门限的可改规则加 19 条禁改清单，按 9 种语体调门限，scan.py 计算 AI 味浓度并记改动台账 | revision |  |
| `fy-agent/humanize-chinese-writing` | 中文去 AI 味与人性化改写：清理黑话、套话、模板腔，可按作者样本匹配风格，并检查 HTML 页面和分析稿的信息密度 | revision |  |
| `hardikpandya/stop-slop` | 识别并删掉 AI 套话、模板句式和节奏问题 | revision |  |
| `ismilewolf-eng/sloptrim-zh` | 中文去 AI 味：85 条模式加本地检测脚本给 0-100 分，按分数分档改写，保留事实和限定词，另有歌词模式 | revision |  |
| `laoguo2025/huoren-write` | 网文与短剧文本的去 AI 味打磨：清理模板腔、假精确、万能安抚腔和强行升华，保留剧情事实与人物声口，附检查脚本 | revision |  |
| `lynote-ai/humanize-text-skill` | 中英双语去 AI 味：规则检测器识别 50 类问题并打分，改写时保护数字、命令和引文，再向口语/专业/技术语气靠拢 | revision |  |
| `mengke-wang/zh-humanizer-literary` | 中文去 AI 味与文采增强：删套话，把抽象判断换成具体的人、场景和动作，在准确前提下补命名、意象和节奏 | revision |  |
| `orange4664/chinese-grammar-proofreader` | 中文病句检查：逐句查语序、搭配、成分残缺、指代不明、两面对一面等，只做最小修改，歧义句给两种改法 | revision |  |
| `qi531416/novel-humanize` | 中文小说/网文去 AI 味：逐句细改打散骨架，对话改「」、清零破折号、调标点节奏，保剧情不 OOC，L1-L4 分层自检 | revision |  |
| `tangwenwen-md/chinese-de-ai-writing` | 按证据分级的中文去 AI 味审稿与改稿：只执行语料验证过的规则，不新增事实、不改断言强度，附扫描脚本和验证结果 | revision |  |
| `wwenj/zu-article-polisher-skill` | 中文长文去 AI 味：识别模板开场、假问题、否定式排比、强行升华、宣传腔等，重写文章骨架，附 Markdown 风格检查脚本 | revision |  |
| `yyx20202020/natural-writing-skill` | 中英文去 AI 味：按修改力度与结构范围两组参数改写，按写作样本校准文风，附脚本核对数字、日期、代码等事实是否丢失 | revision |  |

## 写作基本功（7）

| 仓库 | 说明 | 阶段 | 层级 |
|---|---|---|---|
| `Calliope-Editor/writing-skills` | 13 个只评不写的英文小说 skill：结构/行文/校对/连贯性编辑、角色卡、试读读者团、经纪人首页审读，以及对话、场景、叙述距离练习 | character,revision |  |
| `Fei2411/inkcraft-writing-skills` | 13 种网文体裁的写作方法库，每个体裁分结构、前三章、场景写法、成文规范、自检清单五份，带体裁自动分流 skill | structure,drafting,revision |  |
| `haowjy/creative-writing-skills` | 通用创意写作插件：写作/批评/修改/探索分工，含故事规划、故事记忆、读者模拟 | structure,drafting,memory,revision |  |
| `hyi1233/wangwen-writing-skill-kit` | 网文方法论技能包：一个调度 skill 按需加载开篇、金手指、简介、伏笔、爽感、人物、节奏、去AI化、拆书等 13 个模块 | market,character,structure,drafting,revision,packaging |  |
| `jwynia/agent-skills` | 叙事技能大全：故事教练、合写、大纲、人物弧光、对白、结局、反套路、闪小说，大量世界观构建体系 | world,character,structure,drafting,revision |  |
| `sinfiny/AutoWriter` | 34 个英文写作 skill：Sanderson 方法论套件、网连载谋略与悬念公平性、潜台词、叙述密度、因果世界观，外加自主写作循环 | world,character,structure,drafting,revision |  |
| `wgwtest/novel-writing` | 小说写作基本功 skill：场景/章/卷的因果规划、视角与知情边界、有后果的对话、保留作者声音的修订与审稿 | structure,drafting,revision |  |

## 延伸：互动小说 · 改编（9）

| 仓库 | 说明 | 阶段 | 层级 |
|---|---|---|---|
| `FA-T-T/codex-noval-2-manga` | Codex 小说改漫画 skill 套件：把小说改成漫画页脚本、视觉设计和角色参考图，再写成 GPT Image 2 直出页面的提示词 | adaptation |  |
| `Treasure-hub-agent/interactive-fiction-skill` | 选项驱动的互动小说：你选，它写，装进 AI 助手即可玩 | drafting |  |
| `Xeonice/soul-killer` | 从任意人物的公开数字足迹提取身份、语言风格和行为模式，蒸馏成角色，再和世界观合成可游玩的 Galgame 剧本 skill | character,adaptation |  |
| `aiskyhub/novel_to_comic` | 小说忠实改编漫画的 Codex 插件：剧本先行、多角色子代理审校、整页提示词逐页生成、导出手机竖屏漫画 | adaptation |  |
| `din1919/interactive-novel` | 把小说片段变成可游玩的互动故事：提取世界状态和人物，用户扮演其中角色，系统接管 NPC 与世界反应，带分层记忆和存读档 | adaptation |  |
| `lhfer/codex-novel-to-comic-studio` | EPUB/TXT 小说改编漫画：版权声明关口、故事与视觉圣经、分页剧本和分镜、image2 整页生成、导出 PDF/CBZ | adaptation |  |
| `ruijayfeng/velvet-ascent-skill` | 中文成人向后宫养成文字游戏 GM：角色分 6 阶段推进关系，NSFW 档位 0-4 可调，8 文件记忆世界、人物与伏笔，结束后可导出小说 | character,drafting,memory |  |
| `unknowlei/fanfic-roleplay-design` | 同人角色扮演设计：联网整理原作资料，生成或合并 SillyTavern 世界书，分还原模式与人物模式，可按主线阶段配置 MVU 变量 | world,character,adaptation |  |
| `zenstory-ai/novel-to-game` | 小说改编游戏：带原文出处的设计文档、网页游戏构建与基于证据的 QA，附三个可玩示例 | adaptation,world |  |

## 翻译 · 出海（15）

| 仓库 | 说明 | 阶段 | 层级 |
|---|---|---|---|
| `9029kazuki/codex-visual-novel-translation` | Galgame 日译简中 skill：调研引擎与解包，建术语和人设 Bible，按整场景翻译、独立审校，回封、诊断字体、实机 QA | translate |  |
| `Anarcadia/chuanban-jp-novel-translator` | 日译中长篇小说 skill 组：主调度串行派单章 subagent，维护术语表和章节摘要，断点续翻，审改分离润色，合并后做 EPUB | translate |  |
| `Cheng-cheng9669/web-novel-library` | 连载网文增量翻译资料库：章节 SHA-256 清单，检测缺章和源文变更，标记过期译文，生成翻译计划并记录状态 | translate |  |
| `GalTransl/GalTransl` | Galgame 自动翻译工具：桌面 GUI 加 Agent 模式，GPT 字典、译前译后字典、断点续翻，也能翻 EPUB 和字幕 | translate |  |
| `Katiros/jp-ln-ocr-epub-skill` | 日轻竖排扫图用 PaddleOCR 识别，再用 DeepSeek 日译中、出 Word 审阅稿：术语表、ruby 处理、低置信重试、质量闸门 | translate |  |
| `MarkfuGod/novel-translate` | Cursor skill：抓取 AO3、FanFiction.net、Royal Road、Wattpad 等站章节，经 OpenAI 兼容接口译成中文，可续跑 | translate |  |
| `NEKOparapa/AiNiee` | AI 翻译桌面工具：EPUB/TXT 小说、RPG 与 Ren'Py 游戏文本、字幕、文档，支持术语表、禁翻表、AI 润色 | translate |  |
| `NguyenVi07/novel-convert-agent` | 中文网文批量译成越南语 convert 体的项目模板：每批 10 章，自动维护人物、设定、剧情摘要和断点 | translate |  |
| `duongmkqn005-ai/zh-vi-novel-translation` | 中文小说译越南语 skill：人名用汉越音，按说话方向定称呼，术语表与作品记忆，查证网络梗，校改 convert 稿 | translate |  |
| `loggg4823-create/renpy-translate` | Ren'Py 视觉小说汉化 skill 加脚本：分析项目、提取对白，调 DeepSeek/OpenAI/Claude 翻译，生成 tl 文件，断点续传 | translate |  |
| `oodadoudou/glossary-review-skill` | 韩中/日中小说术语表 xlsx 审查：逐词联网搜索并对照上下文，统一人名和组织译名，确认提案后写回 | translate |  |
| `tinrin-kiri/novel-localization` | 长篇小说本地化 skill 加项目模板：分类术语表、未决专名记录、逐章原文对照草稿，导出 TXT/HTML/EPUB | translate |  |
| `waw1w1/galgame-skill` | Galgame／视觉小说译成中文的 skill：统一术语与称呼，保持多路线连续，分批自审、整线纠错，脚本检查 ID/变量/标签 | translate |  |
| `xuanji86/ainiee-translate-skill` | 让 agent 当翻译引擎的整书翻译插件：锁定术语表、断点续翻、多 agent 并行、对抗式审校，读写 EPUB/TXT/RPY 等格式 | translate |  |
| `yqrsmion/translate-novel` | 整本小说 txt 翻译 skill：边界感知切块、串行逐块翻译、段落 1:1 对齐加 V1–V12 校验、崩溃可续、确定性合并 | translate |  |

## 素材：小说下载 · 书源（22）

| 仓库 | 说明 | 阶段 | 层级 |
|---|---|---|---|
| `404-novel-project/novel-downloader` | 通用小说下载油猴脚本：在目录页一键下载，覆盖起点、晋江、番茄、七猫、SF、ESJ、轻小说文库等百余站，输出 TXT+EPUB | market |  |
| `Messiahhh/wenku8-downloader` | 轻小说文库命令行下载器（Node.js）：搜索、榜单、按 ID 下载，章节与插图断点续传，输出经 EPUBCheck 校验的 EPUB 3 | market |  |
| `Narylr350/book-source-creator-skill` | 输入小说网站地址，分析站点结构生成「阅读/Legado」书源 JSON 或 JS，并验证搜索、详情、目录、正文四条链路 | market |  |
| `RRRRUDDDD/Yamibo_Downloader` | 百合会论坛油猴脚本：按一楼目录或楼主楼层抓取连载帖、标签合集，按章节筛选后导出 EPUB3/TXT，含插图 | market |  |
| `ShqWW/bilinovel-download` | 哔哩轻小说（linovelib）与哔哩漫画下载器：Fluent 风格 GUI 加命令行，按卷打包 EPUB，插图自动排版 | market |  |
| `XIU2/Yuedu` | 「阅读」APP 书源合集：作者自用的 22 个精选小说书源（起点、番茄、69书吧等），提供网络导入和二维码导入 | market |  |
| `aoaostar/legado` | 「阅读」App 书源合集：全量约 3900 条书源，另有订阅源、净化规则、排版和朗读引擎配置，一键导入 | market |  |
| `fateking27/wenku8-downloader` | 轻小说文库命令行下载器（Bun）：按 ID/书名/作者搜索或看榜单，整本或分卷导出 EPUB/TXT，可只下插图、配代理池 | market |  |
| `guohuiyuan/go-novel-dl` | Go 多站小说下载器：CLI、Web UI 和桌面壳，跨站聚合搜索，覆盖 ESJ、SF、刺猬猫、起点、番茄等，导出 TXT/EPUB/HTML | market |  |
| `halei0v0/FXdownloader` | 多源小说下载：八个站点（含番茄）聚合搜索、跨源分工下载与三层重试、番茄字体解密、断点续传，自带排行榜和阅读器 | market |  |
| `ilusrdbb/lightnovel-pydownloader` | 日轻翻译站爬虫：支持 ESJ、轻之国度、真白萌、百合会，按白名单或收藏批量导出 EPUB/TXT，有 CLI 和 GUI | market |  |
| `kanasimi/work_crawler` | Node.js 小说漫画批量下载器：小说部分覆盖起点、笔趣阁系、成为小说家吧、カクヨム等站，输出 EPUB，有 Electron 界面 | market |  |
| `lncrawl/lightnovel-crawler` | 英文网文/轻小说爬虫：361 个站点（含 Royal Road、Webnovel），一条命令生成 EPUB/TXT 等，另有自建 Web 书库与翻译 | market |  |
| `mikoto710/esj-novel-downloader` | ESJZone 油猴脚本：详情页和论坛页全本或按章节范围下载，导出 TXT/EPUB/HTML，含插图、断点续传和密码章节处理 | market |  |
| `nanachi1212/novelDownloader` | 通用小说下载器（Python）：GUI 下载队列加 CLI，适配 69书吧、多个台湾小说站和番茄，过滤广告后导出 TXT/EPUB | market |  |
| `rainyautumn1/FanqieNovelDownloader` | 番茄小说桌面下载器（PySide6）：内置浏览器登录，单本按章节范围或按榜单批量下载，导出 TXT/EPUB/Markdown | market |  |
| `tickmao/Novel` | 书源合集：阅读（Legado）约 1000 个、香色闺阁 1274 个书源，附净化规则、TTS 配置、字体和主题，Actions 每天校验 | market |  |
| `tracywong117/jjwxc-downloader` | 晋江文学城免费章节下载脚本：用 Selenium 抓成 TXT，附 TXT 转 EPUB（带封面和目录） | market |  |
| `ying-ck/fanqienovel-downloader` | 番茄小说 Python 下载器：命令行按 ID/链接下载、搜索、批量和更新已下书目，另有 Web 版队列与在线阅读，导出 TXT/EPUB | market |  |
| `yunmegnze/fanqie-novel-downloader-skill` | 番茄小说下载 skill：给阅读链接，经 Chrome CDP 逐章抓取，解码字体加密，按章存 TXT 并汇总成 JSON | market |  |
| `z1131392774/legado-source-generator` | Chrome/Firefox 扩展：在小说网页上点选元素，生成「阅读」书源的搜索、发现、详情、目录、正文规则并导出 JSON | market |  |
| `zhongbai2333/Tomato-Novel-Downloader` | 番茄小说下载器（Rust）：TUI 与 Web UI 搜索下载，导出 TXT/EPUB/PDF，可附段评、生成 Edge TTS 有声书 | market |  |

## 相关开源应用（完整应用，非 skill）（6）

| 仓库 | 说明 | 阶段 | 层级 |
|---|---|---|---|
| `EthanYoQ/AI-Novel-Writer` | 桌面长篇写作软件：前提、角色、世界观、章节蓝图、草稿、审稿、修稿、定稿逐段推进，可按阶段绑定写作 Skill，支持本地与在线模型 | world,character,structure,drafting,revision |  |
| `ExplosiveCoderflome/AI-Novel-Writing-Assistant` | 长篇小说创作工作台：自动导演从灵感推进到开书、世界观、角色、章节规划、正文与检查，含拆书、写法引擎、反 AI 规则、RAG 知识库和短篇流程 | market,world,character,structure,drafting,memory,revision,adaptation |  |
| `RhythmicWave/NovelForge` | 卡片式长篇创作工具：按 JSON Schema 结构化生成设定、角色、大纲卡片，用 @DSL 注入上下文、知识图谱保一致，可编排代码式工作流（含拆书） | market,world,character,structure,drafting,memory |  |
| `YILING0013/AI_NovelGenerator` | 本地部署的长篇小说生成应用：用雪花法从核心创意逐级展开卷、弧、场景、章纲到正文，管理角色/势力/物品/伏笔状态，AI 流程可在画布上改 | world,character,structure,drafting,memory |  |
| `syrizelink/OpenFic` | 人机协同的小说写作工具：写作编辑器加可自定义的 Prompt/Agent/工作流，维护设定、角色与伏笔，向量检索百万字项目，支持 Docker/pip/桌面版 | world,character,drafting,memory |  |
| `voocel/ainovel-cli` | 全自动长篇小说生成 CLI：确定性引擎调度 Architect/Writer/Editor 三个代理，卷弧滚动规划、七维评审、步骤级断点恢复，可随时插入修改意见 | structure,drafting,memory,revision |  |
