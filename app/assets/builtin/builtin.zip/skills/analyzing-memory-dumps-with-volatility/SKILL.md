---
name: analyzing-memory-dumps-with-volatility
description: "Analyzing memory images with Volatility: profile detection, process enumeration, code injection discovery, and artifact extraction. Use this skill when given a RAM image from Windows or Linux."
---

# Volatility

## Overview

Volatility reads a raw memory image using OS structure definitions. Volatility 3 uses symbol tables (ISF) instead of profiles; Volatility 2 uses profiles.

## Volatility 3 basics

```bash
pip install volatility3
vol -f mem.raw windows.info
vol -f mem.raw windows.pslist
vol -f mem.raw windows.pstree
vol -f mem.raw windows.netscan
vol -f mem.raw windows.cmdline
vol -f mem.raw windows.dlllist --pid 1234
```

## Key plugins

| Plugin | Purpose |
|---|---|
| `windows.info` | OS build, kernel base (verify the image is usable) |
| `windows.pslist` | active processes |
| `windows.psscan` | pool-scan for hidden processes |
| `windows.pstree` | parent/child |
| `windows.malfind` | RWX private regions |
| `windows.netscan` | connections |
| `windows.cmdline` | command lines |
| `windows.hashdump` | SAM hashes |
| `windows.lsadump` | LSA secrets |
| `windows.registry.printkey` | registry hive in memory |
| `windows.dumpfiles` | extract file objects |

## Injection discovery

```bash
vol -f mem.raw windows.malfind --pid 1234 --dump
```

`malfind` reports `MEM_PRIVATE` + `PAGE_EXECUTE_READWRITE` regions. A dumped region with an `MZ` header is a manual-mapped module.

## Hidden processes

```bash
vol -f mem.raw windows.psscan > a
vol -f mem.raw windows.pslist > b
# PIDs in psscan but not pslist = unlinked (DKOM)
```

## Linux

```bash
vol -f mem.raw linux.pslist
vol -f mem.raw linux.bash          # command history from memory
vol -f mem.raw linux.check_modules
vol -f mem.raw linux.check_syscall
vol -f mem.raw linux.malfind
```

## Symbol tables

```bash
# Volatility 3 downloads ISF automatically; offline:
vol -f mem.raw --symbols /path/to/symbols windows.info
```

`windows.info` failing usually means the wrong symbol set for the build.

## Extraction pipeline

```bash
vol -f mem.raw windows.dumpfiles --virtaddr 0x...
vol -f mem.raw windows.memmap --pid 1234 --dump
```

## Pitfalls

- Acquiring memory changes it — record the acquisition method and hash.
- Volatility 2 plugins are not available in 3; some families need v2.
- Kernel symbols from a different build produce plausible but wrong results.

## Verification

`windows.info` must report a kernel base that matches the image, and a known process (e.g., `System` pid 4) must appear in `pslist`.
