---
name: email-security
description: "Email security assessment: SPF, DKIM, DMARC, and spoofing resistance testing for a domain. Use this skill when evaluating whether a domain can be spoofed."
---

# Email Security

## Overview

Three DNS records decide spoofability: SPF (sender IPs), DKIM (message signature), DMARC (policy + alignment).

## Check the records

```bash
dig +short TXT target.com | grep spf
dig +short TXT _dmarc.target.com
dig +short TXT selector._domainkey.target.com
```

```bash
# comprehensive
python3 checkdmarc.py target.com
```

## Evaluate

**SPF:**

```
v=spf1 include:_spf.google.com ~all
```

- `-all` = hard fail (good)
- `~all` = soft fail (spoofable but marked)
- `?all` or missing = no policy
- >10 DNS lookups = broken SPF

**DKIM:** check the selector exists and the key is 2048-bit.

**DMARC:**

```
v=DMARC1; p=reject; rua=mailto:dmarc@target.com; pct=100
```

- `p=none` = monitoring only (spoofable)
- `p=quarantine` = spam folder
- `p=reject` = blocked

## Test spoofing

```bash
# with swaks
swaks --to victim@target.com --from ceo@target.com --server mail.target.com \
  --header "Subject: test" --body "spoof test"
```

Test subdomains — `p=none` at the root does not protect `mail.target.com` unless `sp=` or a wildcard exists.

## Bypass techniques

| Control | Bypass |
|---|---|
| SPF | send from an allowed IP (compromised host) |
| DKIM | replay a legitimately signed message |
| DMARC | lookalike domain, display-name spoofing |
| DMARC p=reject | header From spoofing still works inside some clients |

Display-name spoofing (`"CEO Name" <attacker@gmail.com>`) defeats DMARC entirely.

## Lookalike domains

```
target.com -> target.co, targett.com, targct.com, target-corp.com
```

Check availability and whether the target monitors for them.

## Pitfalls

- `p=reject` on the root does not cover subdomains without `sp=reject`.
- Third-party senders (CRM, marketing) often need SPF includes; missing them breaks legit mail, not attacks.
- A passing DMARC on a lookalike domain is expected — alignment is per-domain.

## Verification

A spoofed message must either be delivered or rejected exactly as the records predict.
