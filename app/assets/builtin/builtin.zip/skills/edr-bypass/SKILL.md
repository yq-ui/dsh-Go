---
name: edr-bypass
description: "EDR bypass methodology: understanding EDR sensor placement, identifying hooks, and choosing techniques that avoid each sensor. Use this skill when a payload is blocked by endpoint detection."
---

# EDR Bypass

## Overview

An EDR has: a kernel driver (callbacks, ETW), a user-mode DLL injected into processes (API hooks), and a cloud analyzer. Bypass means avoiding all three.

## Map the sensors

```c
// which DLLs are loaded into the process?
// user32, kernel32, ntdll hooks -> inline hooks at function prologues
```

Check for hooks by reading the first bytes of `ntdll` exports:

```c
unsigned char* p = (unsigned char*)GetProcAddress(GetModuleHandleA("ntdll.dll"), "NtAllocateVirtualMemory");
// clean: 4C 8B D1 B8 <ssn> 00 00
// hooked: E9 <rel32> (jmp to the EDR DLL)
```

## Sensor → bypass

| Sensor | Bypass |
|---|---|
| Inline hooks (`jmp` at prologue) | unhook, direct syscalls, indirect syscalls |
| Kernel callbacks (`PsSetCreateProcessNotifyRoutineEx`) | avoid `CreateProcess`, use fork/exec primitives less monitored |
| `ObRegisterCallbacks` (handle stripping) | open with minimal rights; use kernel-mode access |
| ETW TI | patch `EtwEventWrite`, avoid providers |
| Memory scanning | encrypt while sleeping, avoid RWX |
| AMSI | memory patch |
| Cloud behavioral | mimic legitimate process behavior |

## Direct syscalls

```asm
mov r10, rcx
mov eax, 0x18        ; NtAllocateVirtualMemory SSN
syscall
ret
```

Avoids the hooked `ntdll` stub entirely.

## Indirect syscalls

Jump to the `syscall` instruction inside `ntdll` after setting registers — the return address points into `ntdll`, defeating stack-based detection.

## Unhooking

```c
// map a fresh ntdll from disk or KnownDlls, copy the .text section over the hooked one
```

## Memory allocation that does not look like shellcode

- Section mapping: `NtCreateSection` + `NtMapViewOfSection` (image-backed, less suspicious).
- Module stomping: overwrite an existing DLL's code.
- Heap execution: rare, high-signal.

## Behavioral considerations

- Parent-child anomalies (Word → PowerShell) are flagged regardless of technique.
- An unsigned binary making network connections is flagged; sign or use a signed host process.
- Command lines are logged; avoid obvious strings.

## Pitfalls

- Each bypass is itself signatured (e.g., known direct-syscall stubs).
- Kernel-level EDR sees the syscall regardless of the user-mode path.
- Testing against a default Defender is not testing against a real EDR.

## Verification

The technique must execute on a host with the target EDR installed and produce a session, with no alert.
