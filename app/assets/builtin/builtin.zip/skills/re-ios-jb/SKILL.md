---
name: re-ios-jb
description: "iOS dynamic analysis on jailbroken devices: debugserver, LLDB attach, Frida on iOS, SSL unpinning, jailbreak detection bypass, and keychain/decrypted data extraction. Use this skill when you need runtime observation of an iOS app rather than static analysis."
---

# iOS Jailbreak Dynamic

## Overview

On a jailbroken device you can attach a debugger, inject Frida, and dump decrypted memory. The main frictions are code signing, jailbreak detection, and SSL pinning.

## Prerequisites

- Jailbroken device (palera1n, Dopamine, unc0ver depending on iOS version)
- `OpenSSH` from Cydia/Sileo, change the default `alpine` password
- `debugserver` (from `lldb` on device or `ipainstaller` toolchain)
- Frida via `frida` repo (`frida-server` on device)

```bash
ssh root@DEVICE_IP
# install frida
apt-get install frida
frida-ps -H DEVICE_IP
```

## LLDB attach

```bash
# on device
/usr/bin/debugserver *:1234 -a $(pidof App)
# on host
lldb
(lldb) platform select remote-ios
(lldb) process connect connect://DEVICE_IP:1234
(lldb) image list -o -f | grep App
```

For an unencrypted binary launched from Xcode-less environment, use `debugserver -x backboard` to spawn.

## Frida on iOS

```javascript
// ObjC method hook
const cls = ObjC.classes.TargetClass;
Interceptor.attach(cls["- checkLicense"].implementation, {
  onEnter(args) { console.log("self", args[0], "sel", args[1]); },
  onLeave(ret) { console.log("ret", ret); ret.replace(ptr(1)); }
});
```

```javascript
// Swift methods via mangled symbol
const addr = Module.findExportByName(null, "$s6Target6Crypto7decryptSSSgSSF");
if (addr) Interceptor.attach(addr, { onEnter(a) { console.log(ObjC.Object(a[2])); } });
```

## SSL pinning bypass

```javascript
// NSURLSession delegate hook
const NSURLSession = ObjC.classes.NSURLSession;
Interceptor.attach(NSURLSession["- URLSession:didReceiveChallenge:completionHandler:"].implementation, {
  onEnter(args) {
    const completion = new ObjC.Block(args[3]);
    const orig = completion.implementation;
    completion.implementation = function (disposition, credential) {
      orig(0, ObjC.classes.NSURLCredential.credentialForTrust_(credential.trust()));
    };
  }
});
```

For AFNetworking/Alamofire pins, hook `SecTrustEvaluate` / `SecTrustEvaluateWithError` and return `0` / `true`.

```javascript
Interceptor.replace(Module.findExportByName(null, "SecTrustEvaluateWithError"), new NativeCallback(() => 1, "bool", ["pointer","pointer"]));
```

## Jailbreak detection bypass

Common checks: `/<path>/Cydia.app`, `fork()`, `canOpenURL("cydia://")`, `stat("/Applications/Cydia.app")`, `frida-server` process, `sysctl` `KERN_PROC`.

```javascript
const NSFileManager = ObjC.classes.NSFileManager;
Interceptor.attach(NSFileManager["- fileExistsAtPath:"].implementation, {
  onEnter(args) {
    const p = new ObjC.Object(args[2]).toString();
    if (/Cydia|frida|substrate|jailbreak/i.test(p)) this.blocked = true;
  },
  onLeave(ret) { if (this.blocked) { ret.replace(ptr(0)); this.blocked = false; } }
});
```

`frida-ios-dump` and `objection` (`ios jailbreak disable`, `ios sslpinning disable`) ship ready-made scripts.

## Decrypting the binary

```bash
python3 frida-ios-dump/dump.py -u root -H DEVICE_IP -p 22 com.target.app
```

Output is a decrypted IPA. Verify with `otool -l` → `cryptid 0`.

## Keychain / data extraction

```javascript
// dump keychain items
const SecItemCopyMatching = Module.findExportByName(null, "SecItemCopyMatching");
// simpler: use objection
```

```bash
objection -g com.target.app explore
# ios keychain dump
# ios nsurlcredentialstorage dump
```

App data lives in `/var/mobile/Containers/Data/Application/<UUID>/` — dump `Documents`, `Library/Preferences/*.plist`, `Library/Caches`.

## Pitfalls

- `debugserver` fails with "not entitled" — re-sign it with `ldid -S` and a `get-task-allow` entitlement.
- iOS 15+ hardened apps detect `ptrace(PT_DENY_ATTACH)`; patch the call.
- Frida detection via `frida-gadget` port scanning — use `frida-server` renamed plus `hide`.

## Verification

The decrypted binary disassembles with real strings, and a hooked method logs values consistent with the app's UI behavior.
