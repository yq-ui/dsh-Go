---
name: re-browser-ext
description: "Reversing browser extensions: manifest structure, content scripts, background workers, and permission abuse in Chrome and Firefox extensions. Use this skill when analyzing a browser extension's logic or capabilities."
---

# Browser Extension Reversing

## Overview

An extension is a ZIP with a `manifest.json`, background scripts, content scripts, and optionally native messaging hosts. Almost always plaintext.

## Unpack

```bash
# .crx: strip the header then unzip
python3 -c "
d=open('ext.crx','rb').read()
i=d.find(b'PK\x03\x04')
open('ext.zip','wb').write(d[i:])
"
unzip -o ext.zip -d ext/
# or use the chrome-extension-downloader tool for store URLs
```

Firefox `.xpi` is a plain ZIP.

## Manifest

```json
{
  "manifest_version": 3,
  "background": { "service_worker": "bg.js" },
  "content_scripts": [{ "matches": ["https://*/*"], "js": ["cs.js"] }],
  "permissions": ["tabs", "cookies", "webRequest", "<all_urls>"],
  "host_permissions": ["https://*/*"]
}
```

Permissions reveal capability: `cookies` + `<all_urls>` means it can read any session cookie.

## Key files

| File | Role |
|---|---|
| `background.js` / `service_worker.js` | long-lived logic, network |
| `content.js` | runs in page context, DOM access |
| `inject.js` (via `web_accessible_resources`) | page-context script |
| `popup.html` / `popup.js` | UI |
| `native-messaging` host name | connects to a local binary |

## Finding the logic

```bash
grep -rn "chrome.cookies\|chrome.tabs\|fetch\|XMLHttpRequest" ext/ | head -20
grep -rn "eval\|atob\|fromCharCode" ext/ | head
```

Obfuscated extensions: `npx webcrack`.

## Runtime inspection

Load unpacked in Chrome, then:

```
chrome://extensions -> Inspect views: service worker
```

Console has full access; you can call `chrome.storage.local.get(null)` to dump state.

## Native messaging

```json
"nativeMessaging" // permission
```

The host manifest lives in `~/.config/google-chrome/NativeMessagingHosts/` (Linux) or the registry (Windows) and points at an executable. That binary is where the privileged work happens.

## Malicious patterns

- Reading all cookies and POSTing them.
- Injecting scripts into banking pages.
- `webRequest` blocking of security headers.
- Auto-update from an unsigned URL.
- Obfuscated payload fetched at runtime.

## Pitfalls

- MV3 service workers terminate; state lives in `chrome.storage`.
- Content scripts run in an isolated world — page variables are not directly visible; use `web_accessible_resources` injection.
- An extension can be force-installed by enterprise policy; check `chrome://policy`.

## Verification

The extension's behavior must be reproducible from its source alone — no unexplained network destination.
