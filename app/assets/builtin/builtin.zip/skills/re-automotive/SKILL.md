---
name: re-automotive
description: "Automotive systems reversing: CAN bus, UDS diagnostics, ECU firmware, and vehicle network security research. Use this skill when analyzing CAN traffic, diagnostic protocols, or ECU firmware."
---

# Automotive Reversing

## Overview

A modern vehicle has multiple CAN buses (powertrain, comfort, infotainment) plus Ethernet and LIN. Analysis targets: message meaning, diagnostic access (UDS), and ECU firmware.

## CAN basics

Frame: 11-bit (standard) or 29-bit (extended) ID, 0-8 bytes payload (CAN 2.0), or 64 bytes (CAN FD).

```bash
# Linux SocketCAN
sudo ip link set can0 up type can bitrate 500000
candump can0
cansend can0 123#DEADBEEF
```

```python
import can
bus = can.interface.Bus(channel="can0", bustype="socketcan")
for msg in bus:
    print(f"{msg.arbitration_id:03X} {msg.data.hex()}")
```

## Decoding signals

Capture a log, then correlate bytes with physical actions:

```bash
candump -l can0     # writes candump-<date>.log
```

```python
import collections
logs = collections.defaultdict(list)
for line in open("candump.log"):
    ts, iface, fid, data = line.split()
    logs[fid].append(bytes.fromhex(data.split("#")[1]))
# a signal that changes monotonically with speed is the speed counter
for fid, frames in logs.items():
    print(fid, len(frames), frames[0].hex())
```

CAN signals are usually bit-packed big-endian with a scale/offset (DBC format):

```
BO_ 2024 MSG_Engine: 8 ECU
 SG_ EngineSpeed : 0|16@1+ (0.25,0) [0|16383.75] rpm
```

Use `cantools` with a DBC file if one exists; otherwise reconstruct the DBC.

## UDS (ISO 14229)

Diagnostic protocol over CAN (ISO-TP framing) or DoIP.

| Service | SID | Purpose |
|---|---|---|
| DiagnosticSessionControl | 0x10 | enter extended/programming |
| ECUReset | 0x11 | reset |
| ReadDataByIdentifier | 0x22 | read a DID |
| SecurityAccess | 0x27 | seed/key unlock |
| WriteDataByIdentifier | 0x2E | write a DID |
| RoutineControl | 0x31 | run a routine |
| RequestDownload | 0x34 | firmware download |
| TransferData | 0x36 | send blocks |

```python
# ISO-TP over CAN with can-isotp
import isotp
tp = isotp.socket()
tp.bind("can0", isotp.Address(isotp.AddressingMode.Normal_11bits, rxid=0x7E0, txid=0x7E8))
tp.send(b"\x10\x03")            # extended session
print(tp.recv().hex())          # 50 03 ...
tp.send(b"\x22\xF1\x90")        # read VIN
```

**SecurityAccess (0x27)**: request seed (`27 01`), receive seed, compute key with the ECU's algorithm, send `27 02 <key>`. The algorithm is in the ECU firmware — reversing it is the classic automotive RE task.

```python
def compute_key(seed: bytes) -> bytes:
    # vendor-specific; recovered from firmware
    k = int.from_bytes(seed, "big")
    k = ((k << 2) ^ 0xDEADBEEF) & 0xFFFFFFFF
    return k.to_bytes(4, "big")
```

## ECU firmware

Extract via UDS `RequestDownload`/`TransferData`, or read the flash chip directly. Firmware images are often raw with a header; use `binwalk` and architecture detection (PowerPC, ARM, TriCore).

## Tools

```bash
# can-utils
candump, cansend, cansniffer, cangen
# python
pip install python-can cantools can-isotp udsoncan
# hardware
# SocketCAN with a PEAK/Vector/Kvaser interface, or an ELM327 for OBD-II
```

## Pitfalls

- CAN is broadcast with no authentication — every node sees everything.
- Bitrate mismatch produces silence and error frames; verify with `ip -details link show can0`.
- Gateway ECUs filter diagnostic requests; you may need to send on the right bus.

## Verification

A message you replay must produce the same physical effect (dashboard change, actuator movement) as the original.
