# 本地工具箱 · 思维链

任务来了先过这条链，别凭感觉。

## STEP 0 — 分类（3 秒）

| 任务 | 走哪 |
|---|---|
| APK / dex / 安卓逆向 | 链 A |
| 要查资料 / 联网 | 链 B |
| 要问大模型 / 总结 / 改写 | 链 C |
| 系统 / 文件 / 进程 | 链 D |
| 要记住某件事 | 链 E |

## 链 A：APK

```bash
python3 /root/toolbox/toolbox.py apk inspect <apk>   # 先看清结构
python3 /root/toolbox/toolbox.py apk decode <apk> <dir> --smali
python3 /root/toolbox/toolbox.py apk grep <dir> '<正则>'
```
**判断点：**
- dex > 10 → 先用 `wherecls.py` 定位，别全量 grep
- 见 `libVm.so` / `NativeUtil.classesInit0` → VMP 保护，静态到边界就停
- 含 `$xxx.xml` → apktool 无法完整重编译，只能回填 dex

## 链 B：联网

```bash
python3 /root/toolbox/toolbox.py web research "<问题>"   # 搜索+抓正文+AI 汇总
python3 /root/toolbox/toolbox.py web search "<关键词>"
python3 /root/toolbox/toolbox.py web get <url>
```
**硬事实：** Bing ✅ / GitHub ✅ / Google ❌ / DuckDuckGo ❌（网络不可达）
→ 永远默认 Bing，别试 Google。

## 链 C：AI

```bash
python3 /root/toolbox/toolbox.py ai ask "<问题>"
python3 /root/toolbox/toolbox.py ai models        # deepseek-flash / deepseek-v4-pro
```
Python 里：
```python
import sys; sys.path.insert(0,'/root/toolbox')
import ai
ai.ask("问题", max_tokens=2000)
ai.stream(msgs, on_chunk=print)
```

## 链 D：系统/文件

```bash
toolbox.py sys info | ps | up | net | sh "<命令>"
toolbox.py file ls <dir> | read <p> | write <p> <文本> | rm <p>
```

## 链 E：记忆

```bash
toolbox.py mem add "<内容>"
toolbox.py mem search "<关键词>"
```

---

# 调用索引

| 需求 | 命令 |
|---|---|
| APK 结构 | `toolbox.py apk inspect` |
| 解包 | `toolbox.py apk decode --smali` |
| 重编译 | `toolbox.py apk build` |
| 签名 | `toolbox.py apk sign` |
| 字符串找方法 | `findstr.py '文案'` |
| 方法找调用者 | `findcall.py 'Cls;->m('` |
| 类找 dex | `wherecls.py 'Lx/Y;'` |
| 联网查 | `toolbox.py web research` |
| 问模型 | `toolbox.py ai ask` |
| 设备信息 | `toolbox.py sys info` |
| 执行命令 | `toolbox.py sys sh` |
| 截图识字 | `tesseract x.jpg stdout -l chi_sim+eng` |

## 锚点

- 工具箱 `/root/toolbox/`（入口 `toolbox.py`）
- DEX 库 `/root/work-am/tools/dexlib.py`
- 配置 `/root/toolbox/config.json`（0600，DeepSeek key）
- 目标 APK `/storage/emulated/0/MT2/工作/Am_1.3.26.apk`
- 模板模块 `/root/work-am/mod/`（amvip.jks / amvip123）
