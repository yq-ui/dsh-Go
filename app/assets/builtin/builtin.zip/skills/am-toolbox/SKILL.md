---
name: am-toolbox
description: "本地工具链（AM 工具本地化版）：APK 逆向全流程（apktool/aapt/apksigner/androguard）、DEX 类与字符串检索、DeepSeek AI 问答与流式、Bing 搜索与网页抓取、系统与文件操作、记忆与对话存储、工作流。当需要解包/重打包/签名 APK、分析 dex、检索代码、联网查资料、调用大模型、读写文件、记录记忆时使用。"
---

# 本地工具箱（AM 工具本地化版）

所有能力都在 `/root/toolbox/`，统一入口 `toolbox.py`。

```bash
python3 /root/toolbox/toolbox.py list     # 看全部命令
```

## 已安装并实测

| 类别 | 工具 | 状态 |
|---|---|---|
| APK 解包/重编译 | apktool 2.7.0 | ✅ 实测解 Am_1.3.26 成功（596MB） |
| manifest/资源 | aapt / aapt2 | ✅ |
| 签名/对齐 | apksigner / zipalign / keytool | ✅ |
| DEX 分析 | androguard 4.1.4 + 自研 dexlib.py | ✅ |
| OCR | tesseract 5.3.4 (chi_sim+eng) | ✅ 实测读中文截图 |
| AI | DeepSeek 官方 API（deepseek-chat / v4-pro） | ✅ 0.2s 响应 |
| 搜索 | Bing（HTML 解析） | ✅ 实测出结果 |
| 网页抓取 | urllib + 标签清洗 | ✅ |
| 系统 | /proc /sys / shell | ✅ |
| 文件 | 读写/列目录/移动/复制/替换 | ✅ |
| 记忆 | JSONL 存储 + 检索 | ✅ |
| 对话 | 本地会话 + 自动带历史问 DeepSeek | ✅ |
| 工作流 | 步骤化命令序列 | ✅ |

## 命令速查

```bash
# APK
toolbox.py apk inspect <apk>          # 结构/dex/ABI/签名/sha256
toolbox.py apk manifest <apk>         # 包名版本
toolbox.py apk perms <apk>            # 权限
toolbox.py apk decode <apk> <dir>     # 解包（--smali 含反汇编）
toolbox.py apk build <dir> [out]      # 重编译
toolbox.py apk sign <apk> <out>       # 签名（默认 amvip.jks）
toolbox.py apk verify <apk>
toolbox.py apk grep <dir> <regex>
toolbox.py apk strings <apk> [regex]

# AI
toolbox.py ai ask "<问题>"
toolbox.py ai models
toolbox.py ai stream "<提示>"

# 搜索/网页
toolbox.py web search "<关键词>"
toolbox.py web research "<问题>"       # 搜索+抓正文+AI 汇总
toolbox.py web get <url>

# 系统
toolbox.py sys info | ps | up | net | sh "<命令>"

# 文件
toolbox.py file ls <dir> | read <p> | write <p> <文本> | rm <p>

# 记忆 / 对话 / 工作流
toolbox.py mem add "<内容>" | mem search "<关键词>" | mem all
toolbox.py chat new <标题> | chat list | chat ask <id> "<问题>"
toolbox.py wf list | wf run <名称>
```

## Python 直接调用

```python
import sys; sys.path.insert(0, '/root/toolbox')
import ai, search, sysinfo, tools, apk

ai.ask("问题")                       # 一问一答
ai.stream(msgs, on_chunk=print)      # 流式
search.bing("关键词")                 # 搜索
search.research("问题")["answer"]     # 搜索+AI
sysinfo.device_info()                # 设备信息
tools.read_file(path)                # 文件
tools.mem_add("记一笔", ["tag"])      # 记忆
```

## 网络实际可达性（实测）

| 目标 | 结果 |
|---|---|
| api.deepseek.com | ✅ 200 |
| www.bing.com | ✅ 200 |
| github.com | ✅ 200 |
| google.com | ❌ Network is unreachable |
| duckduckgo.com | ❌ Network is unreachable |

所以搜索默认走 Bing，别用 Google/DDG。

## 配置

`/root/toolbox/config.json`（0600）
- DeepSeek: base `https://api.deepseek.com`，model `deepseek-chat`
- 环境变量可覆盖：`DEEPSEEK_API_KEY` / `DEEPSEEK_MODEL`

## 从 AM 移植但**没有**等价物的部分

| AM 工具 | 为什么不行 | 替代 |
|---|---|---|
| 绘图（7 个） | 需各自官方 API Key，且已按要求删除 | 无 |
| `terminal`/`shell`（AM 版） | 依赖 AM 的 proot + Shizuku | 本机 `sys sh` 直接执行 |
| `windows_exec` / `linux_ssh` | 需远端 Agent 服务 | 无（本机没装 ssh） |
| UI 自动化（点击/滑动） | AM 的 JS 无障碍 API | `phone` 系列工具 |
| 通知/短信读取 | AM 的 `Tools.xxx` | `phone` 工具 |
| 云端 Agent（AmTaskAgent） | VMP native + 服务端会员校验 | DeepSeek 直连 |

## 踩过的坑

1. **Bing 的 HTML 不能按 `<li class="b_algo">...</li>` 整段匹配** —— 内部有嵌套 `</li>`，会被截断。要按 `class="b_algo"` 切段再取第一个链接。
2. **`/proc/uptime` 可能 Permission denied** —— 改用 `time.clock_gettime(CLOCK_BOOTTIME)`。
3. **绘图包全部要自备 API Key**，代码里没有任何硬编码密钥（全库扫过）。
