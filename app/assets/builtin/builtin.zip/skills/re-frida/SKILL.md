---
name: re-frida
description: "Frida fundamentals for mobile and desktop instrumentation: session setup, Interceptor, Java/ObjC bridges, memory APIs, and safe hooking patterns. Use this skill when instrumenting a running process with Frida, writing hooks, or debugging a Frida script that does not fire."
---

# Frida

## Overview

Frida injects a JS runtime into a process. You get: module enumeration, memory read/write, native `Interceptor`, and language bridges (`Java`, `ObjC`, `Swift`).

## Connect

```bash
frida-ps -U                       # USB device processes
frida-ps -H 192.168.1.5           # remote
frida -U -f com.app -l hook.js --no-pause
frida -U com.app -l hook.js       # attach to running
```

```python
import frida
dev = frida.get_usb_device()
pid = dev.spawn(["com.app"])
s = dev.attach(pid)
s.on("message", lambda m, d: print(m, d))
s.create_script(open("hook.js").read()).load()
dev.resume(pid)
```

## Native hooks

```javascript
const p = Module.findExportByName("libc.so", "open");
Interceptor.attach(p, {
  onEnter(args) { this.path = args[0].readUtf8String(); },
  onLeave(ret) { console.log(this.path, "->", ret.toInt32()); }
});
```

Replace (full override):

```javascript
const cb = new NativeCallback(function (a, b) {
  return 42;
}, "int", ["int", "int"]);
Interceptor.replace(Module.findExportByName(null, "check"), cb);
```

Module offsets for stripped targets:

```javascript
const base = Module.findBaseAddress("libfoo.so");
console.log("base", base);
Interceptor.attach(base.add(0x1234), { onEnter(a) { console.log(a[0]); } });
```

## Memory

```javascript
Memory.readUtf8String(ptr("0x1000"));
Memory.readByteArray(addr, 64);
Memory.writeByteArray(addr, [0x90, 0x90]);
Memory.scan(base, size, "48 8B ?? 89", { onMatch(m) { console.log(m); }, onComplete() {} });
Process.enumerateModules();
Process.enumerateThreads();
```

## Java bridge (Android)

```javascript
Java.perform(() => {
  const C = Java.use("com.app.Foo");
  C.bar.overload("int").implementation = function (x) {
    console.log("bar", x);
    return this.bar(x);
  };
  Java.enumerateLoadedClasses({ onMatch(n) { if (n.includes("app")) console.log(n); }, onComplete() {} });
});
```

## ObjC bridge (iOS)

```javascript
Interceptor.attach(ObjC.classes.Foo["- bar:"].implementation, {
  onEnter(args) { console.log(new ObjC.Object(args[2])); },
  onLeave(ret) { ret.replace(ptr(1)); }
});
```

## Debugging a script that does not fire

| Symptom | Cause |
|---|---|
| no output at all | app not spawned/paused; hook loaded too late |
| `Error: expected a pointer` | argument index wrong for the ABI |
| hook fires but values are garbage | wrong overload; add `.overload(...)` |
| crash on attach | anti-Frida detection, or hooking a PLT stub that is not called |
| `Java.perform` body silent | class not yet loaded — retry in a timer |

Load early with `--no-pause` after spawn, and put class lookups inside `setTimeout`.

## Stability

- Keep `onEnter` fast; heavy work in `send()` to the host.
- Never hold a `JNIEnv*` across calls.
- Use `setImmediate` for re-entrant hooks.

## Verification

The hook prints for the exact user action you performed, with argument values matching what the UI shows.
