---
name: re-license
description: "License system analysis: license file formats, key generation algorithms, hardware binding, and activation flows. Use this skill when analyzing how a product enforces licensing and what the license data actually contains."
---

# License Analysis

## Overview

A license system has: a token (file/key/server response), a validation routine, and a binding (machine, user, time). Reversing means understanding all three.

## Token formats

```bash
file license.dat; xxd license.dat | head
strings license.lic | head
# common: base64 -> JSON, or a signed blob
python3 -c "import base64;print(base64.b64decode(open('license.dat').read().strip()))"
```

| Shape | Scheme |
|---|---|
| `XXXX-XXXX-XXXX-XXXX` | key with a checksum/modulus |
| base64 JSON + signature | signed license |
| binary with a header | proprietary |
| server response | online activation |

## Validation routine

Look for the function that consumes the license:

- Reads the file, decrypts, parses fields.
- Compares an expiry date with the current date.
- Computes a hash over the license body and compares to an embedded public key (RSA/ECDSA verify).
- Checks a machine fingerprint.

```c
// typical
if (rsa_verify(license.body, license.sig, pubkey) &&
    license.expiry > time(NULL) &&
    strcmp(license.machine, get_hwid()) == 0)
    activated = 1;
```

## Key generation

License keys are usually:

- **Checksum-based**: `key = payload || crc(payload)` — forgeable once the checksum is known.
- **Modulus-based**: `key % N == 0` — solve for valid suffixes.
- **HMAC-signed**: needs the secret (usually embedded or server-side).
- **Asymmetric**: cannot be forged without the private key — patch instead.

```python
# checksum forgery
import zlib
payload = b"USER1234"
key = payload + struct.pack(">I", zlib.crc32(payload))
```

## Hardware binding

| Binding | Source |
|---|---|
| Disk serial | `IOCTL_STORAGE_QUERY_PROPERTY` |
| Motherboard UUID | `wmic csproduct get uuid` |
| MAC address | `GetAdaptersInfo` |
| CPU ID | `cpuid` |
| Volume serial | `GetVolumeInformation` |

Patch the binding comparison or spoof the source at runtime.

## Online activation

```
POST /activate { key, hwid } -> { token, expiry }
```

Intercept to see the schema and to learn whether the token is verified locally (JWT with a public key = patch the verify) or server-side per request (patching is useless).

## Pitfalls

- A license file may be encrypted with a key derived from the key itself (`key = kdf(license_id)`).
- Floating licenses count sessions server-side.
- Time-limited licenses may check in a background thread — patch every check.

## Verification

A forged license must pass validation and grant the same feature set as a genuine one.
