---
name: re-vuln
description: "Vulnerability discovery in binaries: identifying dangerous patterns, tracing untrusted input, and confirming a bug with a working trigger. Use this skill when hunting for memory-safety or logic bugs in a compiled target."
---

# Binary Vulnerability Discovery

## Overview

Hunt for the boundary between trusted and untrusted data: parsers, protocol handlers, file loaders. Look for missing length checks, integer arithmetic feeding allocations, and lifetimes.

## Dangerous sinks

| Function | Bug class |
|---|---|
| `memcpy`, `strcpy`, `sprintf` | overflow |
| `alloca(n)` with n from input | stack clash |
| `malloc(a*b)` | integer overflow |
| `free` then use | UAF |
| array index from input | OOB |
| `scanf("%s")` | unbounded read |
| format string from input | format bug |
| `atoi`/`strtol` into a size | sign/truncation |

## Static hunting

```bash
# find memcpy calls and inspect the length argument
r2 -q -c 'aaa; axt @ sym.imp.memcpy' bin
# or in IDA: xrefs to memcpy, check arg 3
```

Look for arithmetic on a length before the copy:

```c
size = n * 4;          // overflow if n large
buf = malloc(size);    // small allocation
memcpy(buf, src, n);   // overflow
```

## Taint tracing

Follow input from `recv`/`read`/`fread` to a sink. Every transformation is a potential sanitizer or a bug:

```
recv -> buf -> atoi(buf) -> len -> malloc(len) -> memcpy(..., len)
```

If `atoi` result is used as an unsigned size and can be negative, that is the bug.

## Dynamic confirmation

```bash
# ASAN build if source is available
# otherwise: gdb with a breakpoint on the sink
gdb -q ./bin
(gdb) b memcpy
(gdb) commands
> silent
> printf "dst=%p src=%p n=%d\n", $rdi, $rsi, $rdx
> c
> end
```

Feed incrementing input sizes until the crash.

## Crash triage

```bash
# core dump
gdb ./bin core
(gdb) bt
(gdb) info registers
```

Crash at `memcpy` with a large `rdx` and a small `rdi` = overflow. Crash at a `call` through a corrupted register = control-flow hijack.

## Fuzzing integration

Use `aflpp` or `libfuzzer` with a harness around the parser (see `harness-writing`). A crash plus a minimized input is a confirmed bug.

## Pitfalls

- A crash is not automatically a vulnerability — check whether the input is attacker-controlled.
- Optimized builds eliminate the checks you are looking for; compare with a debug build if available.
- Hardened allocators turn heap overflows into aborts, masking exploitability but not the bug.

## Verification

A minimized input must crash the target deterministically at the same instruction with the same corrupted state.
