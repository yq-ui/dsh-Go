---
name: re-kernel
description: "Windows and Linux kernel-mode reversing: driver structure, IRP dispatch, IOCTL handling, kernel APIs, and structure layouts. Use this skill when analyzing kernel drivers, rootkits, or kernel-mode protection components."
---

# Kernel Reversing

## Overview

Kernel code has no `main`: a driver registers dispatch routines and callbacks, then waits. The entry point is tiny; the logic lives in the handlers.

## Windows driver entry

```c
NTSTATUS DriverEntry(PDRIVER_OBJECT drv, PUNICODE_STRING reg) {
  drv->DriverUnload = Unload;
  drv->MajorFunction[IRP_MJ_CREATE]  = DispatchCreate;
  drv->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DispatchIoctl;
  IoCreateDevice(drv, 0, &devName, FILE_DEVICE_UNKNOWN, 0, FALSE, &devObj);
  return STATUS_SUCCESS;
}
```

Locate by: `IoCreateDevice`, `IoCreateSymbolicLink`, `IoCreateDriver`, `PsSetCreateProcessNotifyRoutine`.

## IRP dispatch

```c
NTSTATUS DispatchIoctl(PDEVICE_OBJECT dev, PIRP irp) {
  PIO_STACK_LOCATION s = IoGetCurrentIrpStackLocation(irp);
  ULONG code = s->Parameters.DeviceIoControl.IoControlCode;
  PVOID buf  = irp->AssociatedIrp.SystemBuffer;
  ULONG inlen = s->Parameters.DeviceIoControl.InputBufferLength;
  irp->IoStatus.Information = outlen;
  irp->IoStatus.Status = STATUS_SUCCESS;
  IoCompleteRequest(irp, IO_NO_INCREMENT);
  return STATUS_SUCCESS;
}
```

`CTL_CODE(DeviceType, Function, Method, Access)`:
- `Method 0` BUFFERED — `SystemBuffer` for both directions
- `Method 1` IN_DIRECT — `Irp->MdlAddress`
- `Method 2` OUT_DIRECT — `Irp->MdlAddress`
- `Method 3` NEITHER — raw user pointers

## Key kernel structures

```c
EPROCESS: UniqueProcessId, ActiveProcessLinks, Token, Vm, Pcb
ETHREAD:  Cid, Tcb, StartAddress
KPROCESS: DirectoryTableBase, ThreadListHead
MMVAD:    Core.VpnStart, Core.VpnEnd, StartingVpn, EndingVpn, u.VadFlags
```

Offsets differ per Windows build — always resolve via `dt nt!_EPROCESS` in WinDbg for the target build, never hardcode.

## Notifications and callbacks

```c
PsSetCreateProcessNotifyRoutineEx
PsSetLoadImageNotifyRoutine
ObRegisterCallbacks     // handle stripping
CmRegisterCallback      // registry
FltRegisterFilter       // filesystem minifilter
```

## Kernel debugging

```
windbg -k net:port=50000,key=...
0: kd> lm
0: kd> bp mydrv!DispatchIoctl
0: kd> !drvobj \Driver\mydrv 2
0: kd> dt nt!_EPROCESS poi(PsInitialSystemProcess)
```

## Linux kernel modules

```bash
modinfo mod.ko
nm mod.ko | head
# entry points: init_module / cleanup_module (or module_init macro)
objdump -d mod.ko | head -40
```

`file_operations` struct with `unlocked_ioctl`, `read`, `write`, `mmap`. `copy_from_user`/`copy_to_user` mark the user/kernel boundary in disassembly.

## Pitfalls

- Everything is packed (`#pragma pack`) — assume natural alignment at your peril.
- `__security_cookie` stack checks appear in every function.
- Debug builds have `DbgPrint` calls that reveal structure names.

## Verification

The IOCTL code you decoded must match the user-mode caller's `DeviceIoControl` argument, and the buffer layout must be consistent with both sides.
