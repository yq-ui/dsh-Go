---
name: ghidra-reverse
description: "Ghidra reversing workflow: project setup, auto-analysis, decompiler, P-code, scripting with Java/Python, data type archives, and headless batch analysis. Use this skill when reversing without IDA, when scripting analysis at scale, or when using Ghidra's decompiler or headless analyzer."
---

# Ghidra Reversing

## Overview

Ghidra is free, scriptable (Java + Jython/PyGhidra), and its decompiler output is often more readable than IDA's on optimized GCC/Clang builds. Headless mode makes it usable in pipelines.

## Workflow

1. **Import.** `File > Import File`. Ghidra auto-detects format; override the language if the loader guesses wrong.
2. **Analyze.** Accept the default analyzers. For packed samples, analyze only after dumping.
3. **Decompile.** Open the function, decompiler pane on the right. Set the signature with `Edit Function Signature` (`F`) so parameters get names and types.
4. **Rename & Retype.** `L` to rename, `Ctrl+L` to retype, `Ctrl+Shift+U` to create a struct from a selection.
5. **Script.** `Window > Script Manager`. Python via PyGhidra (Ghidra 11.2+) or Jython.

## Decompiler tips

- **Fix prototypes first.** Wrong prototypes produce nonsense locals; correct the ABI signature and re-decompile.
- **`ghidra.app.decompiler` options.** Enable "Simplify style" and turn off "Eliminate unreachable code" only when you need to see dead branches.
- **P-code view.** `Window > P-code` shows ops after lowering — the ground truth for what an instruction actually does.
- **Watch `undefined4` parameters.** They mean the calling convention was not resolved; set `__thiscall` / `__fastcall` explicitly.

## Headless batch

```bash
$GHIDRA/support/analyzeHeadless /tmp/proj MyProj \
  -import ./target.exe \
  -postScript DumpFuncs.java \
  -scriptPath ./scripts \
  -deleteProject
```

```java
// DumpFuncs.java
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
public class DumpFuncs extends GhidraScript {
    public void run() throws Exception {
        for (Function f : currentProgram.getFunctionManager().getFunctions(true))
            println(f.getEntryPoint() + " " + f.getName() + " " + f.getBody().getNumAddresses());
    }
}
```

## PyGhidra

```python
# run with: ghidra-11.x/support/pyghidraRun or analyzeHeadless -postScript script.py
from ghidra.program.model.symbol import SourceType
fm = currentProgram.getFunctionManager()
for f in fm.getFunctions(True):
    if f.getName().startswith("FUN_"):
        f.setName("sub_%x" % f.getEntryPoint().getOffset(), SourceType.USER_DEFINED)
```

## Useful analyzers toggles

| Symptom | Fix |
|---|---|
| Missing imports | Run "PE Loader" again after fixing the import table, or use `Reanalyze` |
| Wrong switch | Run "Switch" analyzer, define the jump table as pointers |
| C++ vtables unnamed | Run "Demangler" + "Create Class Struct" analyzers |
| TLS callbacks skipped | Check "Windows x86 PE TLS Callback" analyzer ran |

## Pitfalls

- Importing a 64-bit binary as 32-bit yields silently wrong code — set language at import.
- Jython is Python 2; f-strings and `pathlib` do not exist.
- Headless without `-deleteProject` fills the disk on loops.

## Verification

Compare a decompiled function against a runtime dump: same arguments produce the same branch in both.
