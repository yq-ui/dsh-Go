---
name: rev-dex-dumper
description: "Dumping DEX bytecode from a running Android app: defeating packers that load DEX from memory, using FART/BlackDex style dumpers, Frida-based extraction, and reconstructing a loadable APK. Use this skill when an APK is protected by a DEX packer and static tools see only a stub."
---

# DEX Dumper

## Overview

Packed Android apps ship a small stub DEX that, at runtime, decrypts the real DEX and hands it to `DexClassLoader` or `InMemoryDexClassLoader`. The real bytecode exists only in memory — you must dump it there.

## Signals of a packer

- `classes.dex` is tiny (< 100 KB) but the app has many features.
- `assets/` contains opaque blobs (`.bin`, `.dat`, `.so` with a random name).
- Application class does reflection and `System.loadLibrary` early.
- `AndroidManifest.xml` declares a custom `Application` with a short name.

```bash
apktool d app.apk -o app_out
ls -la app_out/smali*        # one small smali tree = stub
```

## Memory dump approaches

**1. Frida + `Java.perform` hook on class loaders**

```javascript
Java.perform(function () {
  const BaseDexClassLoader = Java.use("dalvik.system.BaseDexClassLoader");
  BaseDexClassLoader.findClass.implementation = function (name) {
    const c = this.findClass(name);
    return c;
  };
  // hook DexFile constructor to capture the path, then pull the file
  const DexFile = Java.use("dalvik.system.DexFile");
  DexFile.$init.overload("java.io.File").implementation = function (f) {
    console.log("DexFile ->", f.getAbsolutePath());
    return this.$init(f);
  };
});
```

For `InMemoryDexClassLoader`, hook `$init(ByteBuffer)` and dump the buffer:

```javascript
const IMDCL = Java.use("dalvik.system.InMemoryDexClassLoader");
IMDCL.$init.overload("java.nio.ByteBuffer", "java.lang.ClassLoader").implementation = function (bb, cl) {
  const buf = Java.array("byte", []);
  const out = new Uint8Array(bb.remaining());
  for (let i = 0; i < out.length; i++) out[i] = bb.get(i);
  send({ dex: Array.from(out) });
  return this.$init(bb, cl);
};
```

**2. BlackDex / FART** — on-device dumpers that enumerate all loaded DEX and write them to `/sdcard`. Requires root or a debuggable app.

**3. `dexhunter` / `youpk`** — custom ROM-based active invocation dumpers that force-load every class so nothing stays unloaded.

**4. `/proc/<pid>/maps` + memory scan** — locate `dex\n035` / `dex\n039` magic in the app's anon regions:

```bash
adb shell "cat /proc/$PID/maps" | grep -i dex
frida-dump-dex -p $PID
```

## Reconstructing

```python
# after dumping N dex files
import subprocess, glob, os
base = sorted(glob.glob("dump/*.dex"))
subprocess.run(["baksmali", "d"] + base[:1] + ["-o", "smali"])
```

For multi-DEX: baksmali each into the same output dir, then `smali a` back, or rename to `classes.dex`, `classes2.dex`, ... and replace in the APK.

```bash
cp dump/classes.dex app_out/
zip -r app_repacked.apk app_out/*
java -jar apksigner.jar sign --ks my.keystore app_repacked.apk
```

## Anti-dump

- `ptrace` self-attach to block debuggers.
- `/proc/self/maps` scanning for `frida`, `xposed`, `magisk`.
- DEX integrity checks over `/data/app/.../base.apk` (the on-disk file is intact, so dumping memory is still required).
- Anti-dump via `mprotect` reverting pages.

Frida script `frida-android-repinning` + `hide-frida` gadget, or patch `libmsaoaidsec.so`.

## Pitfalls

- Dumping a partial DEX (only loaded classes) yields a file that fails `dex2jar`.
- `mCookie` recovery via `dumpDexFile` needs the right class-linker layout for the Android version.
- Re-signing changes the signature — apps with signature checks need `signature` hooks too.

## Verification

Repacked APK installs, launches, and `jadx` on the dumped DEX produces a class count comparable to the original app's complexity.
