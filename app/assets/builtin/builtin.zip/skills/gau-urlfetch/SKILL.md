---
name: gau-urlfetch
description: "URL harvesting with gau and waybackurls: pulling historical URLs from archives and public sources. Use this skill when historical endpoints matter more than live crawling."
---

# gau / waybackurls

## Overview

Archives hold URLs the site no longer links to: old APIs, debug panels, deprecated parameters. gau and waybackurls extract them.

## gau

```bash
go install github.com/lc/gau/v2/cmd/gau@latest
gau target.com
gau --subs target.com
gau --threads 5 target.com | sort -u > urls.txt
gau --blacklist png,jpg,gif,css target.com
gau --from 2020 --to 2024 target.com
```

## waybackurls

```bash
go install github.com/tomnomnom/waybackurls@latest
waybackurls target.com
echo target.com | waybackurls | sort -u
```

## Other sources

```bash
# common crawl
curl -s "https://index.commoncrawl.org/CC-MAIN-2024-10-index?url=*.target.com&output=json" | jq -r '.url'

# urlscan
curl -s "https://urlscan.io/api/v1/search/?q=domain:target.com" | jq -r '.results[].page.url'

# alienvault otx
curl -s "https://otx.alienvault.com/api/v1/indicators/domain/target.com/passive_dns" | jq -r '.passive_dns[].hostname'
```

## Filtering what matters

```bash
gau target.com | grep -E "\?|=" | sort -u > params.txt
gau target.com | grep -E "\.(js|json|xml)$" | sort -u > files.txt
gau target.com | grep -iE "admin|debug|test|backup|api/v[0-9]" | sort -u
```

## Live check

```bash
gau target.com | httpx -silent -status-code -mc 200,301,302,403
```

## Pitfalls

- Archive URLs are often dead — always verify.
- Large domains produce hundreds of thousands of URLs; filter before probing.
- Historical parameters may still be processed by the backend even if the UI dropped them.

## Verification

A harvested URL must return a response when fetched now.
