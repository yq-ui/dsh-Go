---
name: edr-bypass-re
description: "Reverse engineering EDR products: locating hooks, identifying the protection driver, and understanding detection logic. Use this skill when an EDR must be analyzed rather than merely avoided."
---

# EDR Reversing

## Overview

Reversing an EDR means: find the user-mode DLL, map its hooks, identify the kernel driver, and read the detection logic.

## User-mode component

```c
// enumerate loaded modules in a protected process
// the EDR DLL is usually injected into every process
```

```powershell
Get-Process | ForEach-Object { $_.Modules } | Where-Object { $_.ModuleName -match "edr|cylance|crowd|carbon" }
```

Common DLL names: `umps.dll`, `cyoptics.dll`, `csfalcon.dll`, `cb.dll`, `atc.dll`, `eppam.dll`.

## Hook mapping

```python
import pefile
# for each ntdll export, read the first bytes in the target process
# E9 = jmp (inline hook), FF 25 = jmp [rip+off] (IAT hook)
```

Tools: `hookshot`, `Uproot` (IDA plugin that identifies inline hooks).

## Kernel driver

```
0: kd> lm
0: kd> !drvobj \Driver\EDRDRV 2
0: kd> bp EDRDRV!*Notify*
```

Look for: `PsSetCreateProcessNotifyRoutineEx`, `ObRegisterCallbacks`, `FltRegisterFilter`, minifilter altitude.

## Detection logic

- Strings in the driver: rule names, MITRE technique IDs.
- IOCTL handlers: the user-mode service sends telemetry.
- ETW providers registered.

```bash
strings edr.sys | grep -iE "mitre|technique|suspicious|inject|shellcode"
```

## Finding the detection gap

Once hooks and rules are mapped, the gap is: paths not hooked, syscalls not covered, or behaviors not modeled.

## Pitfalls

- EDR drivers are protected (ELAM, PatchGuard) — do not patch them on a live system.
- The cloud component's rules are not on the endpoint.
- Version differences change every offset.

## Verification

A claimed gap must be demonstrated by a technique that executes without an alert on that EDR version.
