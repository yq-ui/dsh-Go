---
name: ai-mobile-reverse-skills
description: "Orchestrating mobile reverse engineering with assisted tooling: picking automated scanners, validating their output, and combining scripted analysis with manual verification. Use this skill when automating mobile RE at scale or when speed matters more than depth."
---

# Automated Mobile RE

## Overview

Automation accelerates triage: secrets, endpoints, packers, and known libraries. It does not replace reasoning. The rule is: automated pass first for inventory, manual pass for the one thing that matters.

## Automated triage stack

```bash
# secrets and endpoints
apkleaks -f app.apk -o leaks.txt
trufflehog filesystem out_jadx/sources --only-verified
semgrep --config=auto out_jadx/sources

# packer / protection
diec app.apk
unzip -l app.apk | grep -Ei "libjiagu|libshella|libsecexe|libmobisec"

# manifest surface
aapt2 dump badging app.apk
aapt2 dump xmltree --file AndroidManifest.xml app.apk | grep -B2 -A6 "exported=\"true\""
```

```bash
# library inventory of native code
for so in libs/*/*.so; do echo "== $so"; strings -a "$so" | grep -E "^(OpenSSL|BoringSSL|mbedtls|libcurl)" | head -3; done
```

## Batch decompilation

```bash
for apk in *.apk; do
  id=$(basename "$apk" .apk)
  jadx -d "out/$id" "$apk" --no-res >/dev/null 2>&1
  echo "$id $(find out/$id -name '*.java' | wc -l) classes"
done
```

## What automation reliably finds

- Hardcoded API keys and endpoints
- Exported components without permission checks
- Known vulnerable library versions (from `.so` strings)
- Debug flags (`android:debuggable`, `StrictMode`)
- Packer identity
- Backup-enabled flags

## What automation reliably misses

- Runtime-computed keys
- Server-side authorization logic
- Custom crypto wrapped in a `.so`
- Obfuscated control flow
- Anything behind a packer

## Verification discipline

Every automated hit needs a manual confirmation:

```bash
# endpoint claimed by apkleaks -> confirm it is reachable and used
grep -rn "api.example.com" out_jadx/sources | head
# then hook at runtime
```

```javascript
Java.use("okhttp3.Request$Builder").build.implementation = function () {
  const r = this.build();
  console.log("[req]", r.url().toString());
  return r;
};
```

## Reporting

Group findings by evidence class: **confirmed runtime**, **confirmed static**, **inferred**. Never mix them — a report that conflates inference with proof is worthless.

## Pitfalls

- `jadx --no-res` skips resources but also skips some string tables; run without it when hunting secrets.
- Semgrep on decompiled Java produces many false positives from generated code.
- Automated decompilers fail silently on packed apps (one class, no error).

## Verification

Each reported finding carries one command or one hook that reproduces it.
