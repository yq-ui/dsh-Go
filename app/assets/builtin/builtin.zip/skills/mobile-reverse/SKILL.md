---
name: mobile-reverse
description: "Cross-platform mobile reversing router: choosing between Android and iOS paths, handling Flutter/React Native/Cordova hybrid apps, and platform-specific toolchains. Use this skill when a mobile target's framework is unclear or spans multiple runtimes."
---

# Mobile Reversing Router

## Overview

Most mobile apps are one of: native Android, native iOS, Flutter, React Native, Cordova/Ionic, Unity, or Xamarin. Each stores logic in a different place — identify the framework before picking tools.

## Framework fingerprint

| Framework | Evidence in the package |
|---|---|
| Native Android | `classes.dex`, Java/Kotlin smali |
| Native iOS | Mach-O with ObjC/Swift metadata |
| Flutter | `lib/libapp.so` (Dart AOT), `flutter_assets/` |
| React Native | `assets/index.android.bundle` (JS), `libhermes.so`, `libreactnativejni.so` |
| Cordova/Ionic | `assets/www/` with HTML/JS |
| Unity | `libunity.so`, `assets/bin/Data/`, `global-metadata.dat` |
| Xamarin | `assemblies/` (`.dll`), `libmonodroid.so` |
| .NET MAUI | `libmonosgen-2.0.so`, `assemblies/` |

```bash
unzip -l app.apk | grep -E "libapp|index.android.bundle|assets/www|libunity|assemblies"
```

## Routing

**Flutter** → `libapp.so` is Dart AOT with a snapshot. Use `blutter` to recover Dart class/method names and offsets, then Frida on the recovered addresses.

```bash
git clone https://github.com/worawit/blutter && cd blutter
python3 blutter.py path/to/app/lib/arm64-v8a out_dir
```

**React Native** → the bundle is minified JS. `react-native-decompiler` or just beautify and search. Hermes bytecode needs `hbctool` / `hermes-dec`.

```bash
npx react-native-decompiler -i index.android.bundle -o out
hbctool disasm index.android.bundle out.hasm
```

**Cordova** → `assets/www/` is plain JS; read it directly.

**Unity** → `rev-u3d-dump`.

**Xamarin** → `assemblies/*.dll` are .NET; `dnSpy` / `ilspycmd`. Native AOT parts need ARM reversing.

## Universal runtime inspection

```javascript
// find every loaded module and its base, regardless of framework
Process.enumerateModules().forEach(m => console.log(m.name, m.base, m.size));
```

Once you know the runtime, hook at its boundary:
- Flutter: hook `dart` entry or recovered function offsets.
- RN Hermes: hook `HermesRuntime::executeScript` or the JNI bridge.
- Cordova: hook `WebView` `loadUrl` and evaluate JS in the page.

## Transport layer

Regardless of framework, network calls go through platform APIs. Hook those instead of the framework:

```javascript
// Android
Java.use("java.net.URL").openConnection.implementation = function () { ... };
// iOS
ObjC.classes.NSURLSession["- dataTaskWithRequest:completionHandler:"]
```

This is framework-agnostic and usually the fastest path to plaintext.

## Pitfalls

- A Flutter app has almost no Java — smali analysis finds only the shell.
- Hermes bytecode is not JS; beautifying it as text produces garbage.
- Xamarin `assemblies/` may be encrypted (`.dll` with an unusual header) — needs a runtime dump.

## Verification

The identified framework matches the module list at runtime (`Process.enumerateModules`), and at least one hook in that framework fires when the app performs the target action.
