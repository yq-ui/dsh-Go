---
name: re-cracking
description: "Software cracking methodology: locating license checks, bypassing them correctly, and producing a working patch. Use this skill when a binary enforces a license or trial limit and the check must be neutralized for analysis or interoperability."
---

# Cracking

## Overview

A license check is a branch on a computed condition. Cracking = find the condition, decide what value it must produce, and make it produce that value — without breaking the rest of the program.

## Locate the check

| Signal | Where |
|---|---|
| Strings: "Invalid license", "Trial expired", "Unregistered" | the failure path |
| Registry reads: `RegQueryValueEx` on a product key | Windows |
| File reads: `license.dat`, `.lic` | token check |
| Network: a validation endpoint | server-side (harder) |
| `GetSystemTime` comparisons | trial timer |
| Dialog `MessageBox` on failure | user-visible result |

```bash
# IDA: find the failure string, X to its references
# Ghidra: same, then read the compare above it
```

## The classic shape

```c
if ( validate(key) ) {
    licensed = 1;
} else {
    MessageBox("Invalid license");
    licensed = 0;
}
```

The patch is at the branch (`jz`/`jnz`) or at `validate`'s return.

## Correct patching

**Least invasive first:**

1. **Return value** — patch `validate` to `mov eax, 1; ret` (or the 64-bit equivalent).
2. **Branch** — flip `jz` → `jnz`, or NOP the branch.
3. **Flag init** — set the `licensed` variable's initializer.

```asm
; x86: force success
xor eax, eax
inc eax
ret
```

```asm
; x64
mov eax, 1
ret
```

**Persist the patch:**

```bash
# x64dbg: Ctrl+P -> "Patch file"
# or binary patch
python3 -c "
d=bytearray(open('app.exe','rb').read())
d[0x1234:0x1238]=bytes.fromhex('b801000000c3')
open('patched.exe','wb').write(d)
"
```

## Trial timers

Timers are checked against a stored date or an accumulated runtime counter. Options: patch the comparison, reset the stored counter, or freeze the clock (a debugger/hook).

```javascript
// Frida: freeze the returned time
const t = Module.findExportByName("kernel32.dll", "GetSystemTimeAsFileTime");
Interceptor.attach(t, { onLeave(r) { /* write a fixed FILETIME */ } });
```

## Server-side validation

If the client asks a server, patching the client is useless. Options: replay a valid response, intercept and return success (only works if the server's answer is the sole gate), or find a local cache that the server populates once.

## Anti-tamper

- Integrity hash of `.text` — patch the hash compare too, or patch in memory only.
- Self-checksum on startup — find the checksum function and NOP its call.
- Multiple redundant checks — patch all of them; missing one produces a delayed failure.

## Pitfalls

- Patching a `jz` that has other semantics breaks unrelated features. Check what else uses that flag.
- A patched binary that still checks in the background will fail later (days later).
- Signature verification (Authenticode) breaks when patching — Windows may still load it, but some features check.

## Verification

The patched binary passes the check with no valid license, and all unrelated features still work. Test at least one feature per major code path.
