---
name: bug-bounty
description: "Bug bounty hunting methodology: program selection, recon prioritization, and high-yield vulnerability classes. Use this skill when hunting on a public bug bounty program."
---

# Bug Bounty

## Overview

Bounties reward impact, not effort. Pick programs with a wide scope and recent changes, then go deep on one asset instead of wide on many.

## Program selection

| Signal | Meaning |
|---|---|
| Wide scope (`*.target.com`) | more surface |
| New program | less competition |
| Fast triage | faster payout |
| Recent acquisitions | forgotten assets |
| VDP only | no money, skip unless learning |

## Recon prioritization

```bash
subfinder -d target.com -silent | httpx -silent -status-code -title
```

Look for: staging/dev environments, old API versions, admin panels, GraphQL endpoints, S3 buckets in JS.

## High-yield classes

| Class | Why |
|---|---|
| IDOR / BOLA | frequent, high impact |
| Auth bypass | high impact |
| SSRF to cloud metadata | critical |
| Subdomain takeover | easy, medium impact |
| Business logic | no scanner competition |
| GraphQL introspection | full schema leak |
| Exposed .git / backup files | source disclosure |

## Subdomain takeover

```bash
subfinder -d target.com | while read d; do
  cname=$(dig +short CNAME "$d")
  [ -n "$cname" ] && echo "$d -> $cname"
done
# check if the CNAME target is unclaimed
```

## Low-hanging checks

```bash
curl -s https://target/.git/config
curl -s https://target/backup.zip
curl -s https://target/.env
curl -s https://target/server-status
curl -s https://target/actuator/env
```

## Report quality

- Title states the impact.
- Steps are reproducible by a triager in one pass.
- Include the exact request and response.
- One finding per report.

## Pitfalls

- Duplicates: check the program's disclosed reports first.
- Out-of-scope assets void the report.
- Automated scanner output without a working PoC gets closed as informational.

## Verification

The report must contain a PoC that a triager can run without guessing.
