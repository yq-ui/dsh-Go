---
name: re-iot-proto
description: "Reverse engineering IoT device protocols: proprietary TCP/UDP, MQTT, CoAP, BLE, and cloud-app communication. Use this skill when a device talks to an app or cloud service in a custom protocol."
---

# IoT Protocol Reversing

## Overview

IoT devices speak: plain TCP/UDP with a custom header, MQTT, CoAP, HTTP/REST, or BLE GATT. Capture first, then find the struct.

## Capture

```bash
# network
tcpdump -i any -s0 -w iot.pcap
wireshark iot.pcap

# app-to-device (mobile app on the same LAN)
# use mitmproxy on a laptop, point the phone's proxy at it
mitmproxy -p 8080 --mode transparent

# BLE
btmon &
gatttool -b AA:BB:CC:DD:EE:FF --interactive
```

## Identifying the protocol

```bash
tshark -r iot.pcap -T fields -e tcp.dstport -e udp.dstport | sort | uniq -c | sort -rn | head
```

| Port | Likely |
|---|---|
| 1883 / 8883 | MQTT |
| 5683 | CoAP |
| 554 | RTSP |
| 80/443 | HTTP |
| 6668 | Tuya |
| 9999 | many vendor apps |
| 1900 | SSDP |

## Custom binary protocol

Find the framing:

```
[len:2][cmd:2][payload:len]
```

or

```
[magic:4][seq:2][len:2][crc:2][payload]
```

Method: capture two messages that differ in one semantic field; the bytes that change are that field.

```python
# diff two captured payloads
a = bytes.fromhex("aa0100100000000100")
b = bytes.fromhex("aa0100100000000200")
print([(i, a[i], b[i]) for i in range(min(len(a),len(b))) if a[i] != b[i]])
```

For bit-packed fields:

```python
def bitfield(buf, bit_offset, width):
    v = int.from_bytes(buf, "big")
    return (v >> (len(buf)*8 - bit_offset - width)) & ((1 << width) - 1)
```

## MQTT

```bash
mosquitto_sub -h BROKER -t '#' -v
mosquitto_pub -h BROKER -t 'cmd/device' -m '{"power":1}'
```

Control topics are usually `cmd/<id>`, state on `state/<id>`. No auth = full control.

## BLE

```bash
gatttool -b MAC --char-read -a 0x0021
 gatttool -b MAC --char-write-req -a 0x0021 -n 01
```

Services and characteristics have UUIDs; vendor-specific 128-bit UUIDs map to custom logic. `nRF Connect` on a phone gives a visual map.

## Cloud API

The app talks to a cloud with a REST API. Hook the app (see `apk-reversing`) to get the device ID, token, and endpoints, then replay with `curl`.

```bash
curl -s -H "Authorization: Bearer $TOKEN" "https://api.vendor.com/v1/device/$ID/status"
```

## Pitfalls

- TLS with pinning blocks plain MITM — hook the app or extract the client cert.
- Devices often accept unencrypted fallback on the LAN even when the cloud path is TLS.
- Sequence numbers/CRC: recompute after modifying a payload, or the device drops it.

## Verification

A replayed or synthesized packet must produce the same device state change as the original capture.
