---
name: re-angr
description: "Symbolic execution with angr: building a harness, exploring paths, and solving for inputs that reach a target. Use this skill when a check is too complex for manual analysis and a solver can find the input."
---

# angr

## Overview

angr executes a binary symbolically: registers and memory hold expressions, branches fork states, and a solver finds inputs satisfying a target.

## Basic solve

```python
import angr, claripy

proj = angr.Project("./crackme", auto_load_libs=False)
state = proj.factory.entry_state()
simgr = proj.factory.simgr(state)

simgr.explore(
    find=lambda s: b"Correct" in s.posix.dumps(1),
    avoid=lambda s: b"Wrong" in s.posix.dumps(1),
)
if simgr.found:
    s = simgr.found[0]
    print(s.posix.dumps(0))
```

## Target an address

```python
FIND = 0x401234
AVOID = [0x401240, 0x401260]
simgr.explore(find=FIND, avoid=AVOID)
print(simgr.found[0].posix.dumps(0)[:64])
```

## Constrain the input

```python
import claripy
flag = claripy.BVS("flag", 8*32)
state = proj.factory.entry_state(stdin=angr.SimFileStream(name="stdin", content=flag, has_end=False))
for i in range(32):
    state.solver.add(flag.get_byte(i) >= 0x20, flag.get_byte(i) <= 0x7e)
state.solver.add(flag.get_byte(0) == ord("f"))
```

## Hooks

```python
# replace a function with a stub
@proj.hook(0x401000, length=5)
def skip(state):
    state.regs.eax = 1

# replace a library call
proj.hook_symbol("strlen", angr.SIM_PROCEDURES["libc"]["strlen"]())
```

## Avoiding path explosion

```python
simgr.explore(find=FIND, avoid=AVOID, num_find=1)
simgr = proj.factory.simgr(state, save_unconstrained=True)

# loop limiter
state = proj.factory.entry_state()
state.options.add(angr.options.LAZY_SOLVES)
```

- Use `avoid` aggressively.
- Hook expensive functions (checksums, crypto) with concrete implementations.
- Restrict input length.

## Veritesting

```python
simgr.use_technique(angr.exploration_techniques.Veritesting())
```

Merges states at join points, dramatically reducing explosion on structured code.

## Common problems

| Symptom | Cause |
|---|---|
| no states after explore | avoid list too broad, or the target is unreachable |
| solver timeout | unconstrained symbolic loop counters |
| `found` input is garbage | unconstrained bytes; constrain with the expected charset |
| wrong input | path assumes an impossible branch — add constraints |

## Pitfalls

- `auto_load_libs=True` drags in libc symbolic execution and explodes; set it False and hook.
- A binary with anti-symbolic checks (`cpuid`, `rdtsc`) needs those hooked.
- angr's default state does not initialize the stack like the real loader in all cases; use `entry_state` carefully with argv.

## Verification

The solved input must be accepted by the real binary and produce the target output.
