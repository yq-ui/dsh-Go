---
name: re-crash-triage
description: "Crash triage: classifying crashes from fuzzing or production, deduplicating, and deciding exploitability. Use this skill when a corpus of crashes must be sorted into real bugs."
---

# Crash Triage

## Overview

Most crashes are duplicates or uninteresting. Triage: get the faulting instruction, the memory state, and the bug class.

## Capture

```bash
# AFL
ls out/default/crashes/
# libFuzzer
./fuzz crash-<hash>

# gdb
gdb -q ./target
(gdb) run < crash
(gdb) bt
(gdb) info registers
(gdb) x/20i $pc-20
```

## Bug classes

| Signal | Class |
|---|---|
| SIGSEGV at `memcpy` with large `n` | heap/stack overflow |
| SIGSEGV reading `[reg+offset]` with corrupted reg | UAF or OOB pointer |
| SIGABRT from `malloc` | heap metadata corruption |
| SIGFPE | divide by zero (low severity) |
| Assertion failure | reachable invariant (often low) |
| Stack overflow recursion | DoS |
| `__stack_chk_fail` | stack canary overflow |

## Deduplication

Group by the top 3 frames of the stack, ignoring addresses:

```python
def key(bt):
    return tuple(f"{f.name}:{f.offset}" for f in bt[:3])
```

Or by the faulting instruction offset in the binary.

## Exploitability

| Question | Impact |
|---|---|
| Attacker controls the overwritten data? | yes → likely exploitable |
| Write primitive or read only? | write is worse |
| Reaches a return address? | control flow |
| Non-deterministic? | harder, still real |
| Requires a specific heap layout? | reliability concern |

## Minimize

```bash
afl-tmin -i crash -o min -- ./target @@
```

## Report

Each unique crash: input file, stack trace, bug class, exploitability assessment, and whether the input is attacker-reachable.

## Pitfalls

- ASAN reports turn a wild write into a clean abort — still a bug.
- A crash in a debug-only assertion is not exploitable.
- Deduplicating by address fails across ASLR-rebased binaries.

## Verification

The minimized input must reproduce the same crash at the same instruction.
