---
name: re-emulation
description: "Emulating binary code for analysis without execution risk: Unicorn, Qiling, and full-system emulation with QEMU. Use this skill when running unpacking stubs, deobfuscating with emulation, or analyzing code for a foreign architecture."
---

# Emulation

## Overview

Emulation executes code in a controlled CPU model: memory, registers, and (optionally) syscalls are supplied by you. It defeats anti-debug, runs ARM/MIPS on x86, and lets you single-step a decryptor without a real environment.

## Choosing

| Need | Tool |
|---|---|
| One function, one arch | Unicorn |
| Real syscalls / libc | Qiling |
| Full OS, drivers | QEMU (system) |
| Windows API behavior | Speakeasy |

## Unicorn

```python
from unicorn import Uc, UC_ARCH_X86, UC_MODE_64, UC_HOOK_CODE
from unicorn.x86_const import UC_X86_REG_RSP, UC_X86_REG_RIP

CODE = 0x1000000
STACK = 0x2000000
uc = Uc(UC_ARCH_X86, UC_MODE_64)
uc.mem_map(CODE, 0x1000)
uc.mem_map(STACK, 0x10000)
uc.mem_write(CODE, open("stub.bin","rb").read())
uc.reg_write(UC_X86_REG_RSP, STACK + 0x8000)

def hook(uc, addr, size, _):
    print(hex(addr))
uc.hook_add(UC_HOOK_CODE, hook)
try:
    uc.emu_start(CODE, CODE + 0x200, count=10000)
except Exception as e:
    print("stop:", e)
print(hex(uc.reg_read(UC_X86_REG_RIP)))
```

**Decryptor loop pattern**

```python
# run until the loop counter stops changing, then dump
for _ in range(200000):
    uc.emu_start(pc, 0, count=1)
    pc = uc.reg_read(UC_X86_REG_RIP)
    if pc in seen and seen[pc] > 3:
        break
    seen[pc] = seen.get(pc, 0) + 1
data = uc.mem_read(DATA_ADDR, 0x2000)
```

## Qiling

```python
from qiling import Qiling
from qiling.const import QL_VERBOSE
ql = Qiling(["./arm_bin"], "rootfs/arm", verbose=QL_VERBOSE.DEBUG)
ql.hook_address(lambda ql: ql.arch.regs.write("r0", 0), 0x10400)
ql.run()
```

Qiling supplies a rootfs (syscalls, libc). Good for Linux/Android ELF and PE without a Windows box.

## Speakeasy

```python
import speakeasy
se = speakeasy.Speakeasy()
mod = se.load_module("sample.exe")
se.run_module(mod)
for e in se.get_report()["api_calls"]: print(e)
```

Speakeasy emulates user-mode Windows APIs — the fastest way to get an unpacked image or an API trace from a Windows sample on Linux.

## Full system (QEMU)

```bash
qemu-system-arm -M versatilepb -kernel zImage -hda rootfs.img \
  -append "root=/dev/sda console=ttyAMA0" -nographic
qemu-arm -L /usr/arm-linux-gnueabihf ./arm_bin
```

For firmware: `-M` a matching machine, `-drive` the image, `-serial` for console. Combine with `-s -S` for gdb.

## Pitfalls

- Unicorn has no OS: any `syscall` or import call crashes unless hooked. Map imports to stubs with `UC_HOOK_CODE` and a fake return.
- Missing stack alignment causes false crashes on SSE code (`movaps`).
- Instruction counts explode on obfuscated dispatchers; bound with `count` and a visited heuristic.

## Verification

The emulated run must produce the same decrypted buffer as the real process. Compare with a memory dump from a debugger.
