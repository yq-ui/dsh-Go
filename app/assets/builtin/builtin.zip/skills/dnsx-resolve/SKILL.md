---
name: dnsx-resolve
description: "DNS resolution and enumeration with dnsx: bulk resolution, record types, wildcard filtering, and DNS-based recon. Use this skill when resolving large host lists or querying specific record types."
---

# dnsx

## Overview

dnsx is a fast bulk DNS toolkit. It resolves, filters, and queries record types, and it is the standard post-processing step for any subdomain list.

## Install

```bash
go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest
```

## Resolve

```bash
dnsx -l subs.txt -a -resp -silent
dnsx -l subs.txt -a -resp-only -silent
```

## Record types

```bash
dnsx -l domains.txt -txt -resp
dnsx -l domains.txt -mx -resp
dnsx -l domains.txt -cname -resp
dnsx -l domains.txt -ns -resp
dnsx -l domains.txt -soa -resp
dnsx -l domains.txt -any -resp
```

## Wildcard filtering

```bash
dnsx -l subs.txt -wd target.com -a -resp -silent
```

`-wd` drops names that resolve to the wildcard IP.

## Reverse lookups and ASN

```bash
dnsx -l ips.txt -ptr -resp
dnsx -l ips.txt -asn -resp
```

## Combine with httpx

```bash
dnsx -l subs.txt -a -resp-only -silent | httpx -silent -status-code
```

## Performance

```bash
dnsx -l big.txt -t 200 -rl 500 -retries 2
```

## Pitfalls

- Too many threads against a single resolver triggers rate limiting; use a resolver list.
- CNAME chains to a CDN hide the real origin — resolve the chain, then check for a direct record.
- `-any` is often blocked by authoritative servers.

## Verification

A resolved host must answer a direct `dig` query with the same record.
