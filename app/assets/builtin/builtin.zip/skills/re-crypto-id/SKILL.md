---
name: re-crypto-id
description: "Identifying cryptographic algorithms in binaries: constants, S-boxes, round structures, and library fingerprints. Use this skill when a binary performs cryptography and you must determine which algorithms and modes."
---

# Crypto Identification

## Overview

Algorithms leave fingerprints: constants, S-boxes, loop counts, and instruction patterns. Identify the primitive, then the mode, then the key source.

## Constant fingerprints

| Constant | Algorithm |
|---|---|
| `0x67452301 0xEFCDAB89 0x98BADCFE 0x10325476` | MD5 / SHA-1 init |
| `0x6A09E667 0xBB67AE85 0x3C6EF372 0xA54FF53A` | SHA-256 init |
| `0x9E3779B9` | TEA / XTEA delta |
| `0x5A827999 0x6ED9EBA1` | SHA-1 round constants |
| `0x428A2F98` | SHA-256 round constants |
| `0xC66363A5` | AES S-box start (big-endian) |
| `0x63 0x7c 0x77 0x7b` | AES S-box (bytes) |
| `0xEDB88320` | CRC32 polynomial (reflected) |
| `0x04C11DB7` | CRC32 polynomial (normal) |
| `0x01000193` | FNV-1a 32 (the `0x193` prime) |

```bash
# byte search with radare2
r2 -q -c '/x 637c777bf26b6fc5' -c q binary
```

```python
import re
d = open("bin","rb").read()
for name, sig in {
    "aes_sbox": bytes.fromhex("637c777bf26b6fc5"),
    "sha256_init": bytes.fromhex("6a09e667bb67ae85"),
    "md5_init": bytes.fromhex("0123456789abcdeffedcba9876543210"),
}.items():
    print(name, hex(d.find(sig)))
```

## Structural fingerprints

| Pattern | Algorithm |
|---|---|
| 64 rounds, rotate 7/12/17 + add | SHA-256 |
| 80 rounds, rotate 5/30 + add | SHA-1 |
| 4 rounds x 4 steps, 16-byte blocks, `aesenc` | AES-NI |
| 256-byte S-box + 4-byte key schedule | AES (software) |
| 4x4 matrix MixColumns with `xtime` | AES |
| 32 rounds, `rotl(x,1) ^ rotl(x,8)` | ChaCha |
| 20 rounds, 32-bit words, add/xor/rotl 16/12/8/7 | ChaCha20 |
| 8 rounds, `x += y; y = rotl(y, r) ^ x` | BLAKE |
| 72 rounds, 64-bit words | Threefish |
| Feistel with 16 subkeys, IP/FP tables | DES |
| `0x13` rotate in a 256-entry table | AES key schedule |

## Library fingerprints

```bash
# OpenSSL
strings bin | grep -E "OpenSSL [0-9]"
# BoringSSL
strings bin | grep -m3 "BoringSSL"
# mbedTLS
strings bin | grep -m3 "mbedtls"
# libsodium
strings bin | grep -m3 "sodium_init"
# Crypto++
strings bin | grep -m3 "CryptoPP"
```

## Mode identification

- **ECB** — identical 16-byte blocks produce identical ciphertext.
- **CBC** — needs an IV; first block differs per message, later blocks chain.
- **CTR** — keystream XOR; ciphertext length equals plaintext, no padding.
- **GCM** — 12-byte nonce, 16-byte tag appended.
- **CBC with padding** — last block is PKCS#7.

```python
# detect ECB
from collections import Counter
ct = bytes.fromhex("...")
blocks = [ct[i:i+16] for i in range(0, len(ct), 16)]
print("duplicate blocks:", [k for k,v in Counter(blocks).items() if v > 1])
```

## Key material location

- `memcmp` on a 16/32-byte buffer = key comparison.
- A 32-byte high-entropy constant in `.rodata` = likely AES-256 key.
- Key derivation: `PBKDF2`, `scrypt`, `Argon2` constants (`0x6b` iteration counts, "salt" strings).

## Pitfalls

- White-box AES has no S-box table — the S-box is fused into a network of lookup tables.
- Compiler-vectorized code hides the round structure; look for the constants instead.
- CRC32 appears in protocols and is not encryption — do not mistake it.

## Verification

Encrypt a known plaintext with the identified algorithm and key; the ciphertext must match the binary's output byte for byte.
