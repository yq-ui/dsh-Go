---
name: re-fw-rootfs
description: "Analyzing embedded firmware root filesystems: init scripts, credentials, services, web interfaces, and update mechanisms. Use this skill after firmware extraction to find the device's actual attack surface and behavior."
---

# Firmware Rootfs Analysis

## Overview

The rootfs is the device's brain: init scripts, daemons, web server, credentials, and the update path. Read it like a Linux system, but expect stripped binaries and vendor scripts.

## First pass

```bash
ls rootfs
cat rootfs/etc/inittab 2>/dev/null
ls rootfs/etc/init.d/
cat rootfs/etc/passwd
cat rootfs/etc/shadow 2>/dev/null
```

`/etc/passwd` without a shadow file means the hashes are readable — crack with `john` or `hashcat`.

```bash
john --wordlist=rockyou.txt hashes.txt
hashcat -m 500 -a 0 hashes.txt rockyou.txt
```

## Services and ports

```bash
grep -rn "listen\|bind\|port" rootfs/etc/init.d/ rootfs/etc/*.conf 2>/dev/null | head
find rootfs -name "*httpd*" -o -name "*telnetd*" -o -name "*dropbear*" | head
strings rootfs/usr/sbin/httpd | grep -E "^/|cgi" | head -20
```

## Web interface

The vendor's web UI is the main vulnerability surface:

```bash
ls rootfs/www/
find rootfs -name "*.cgi" -o -name "*.lua" -o -name "*.asp" | head
```

CGI binaries parse query strings with `getenv("QUERY_STRING")` — command injection via `system()` is common. Grep the binary:

```bash
strings rootfs/usr/sbin/cgi-bin/foo.cgi | grep -E "system|popen|/bin/sh"
objdump -d rootfs/usr/sbin/foo.cgi | grep -B2 -A2 "system@plt"
```

## Init script patterns

```bash
cat rootfs/etc/init.d/rcS
# look for: mtd writes, nvram_set, telnetd with no password, wget from a fixed URL
grep -rn "telnetd\|wget\|curl\|nvram" rootfs/etc/ | head -20
```

An `/etc/init.d` that launches `telnetd -l /bin/sh` with no auth is a backdoor.

## Update mechanism

```bash
grep -rn "firmware\|update\|upgrade\|\.bin" rootfs/etc/ rootfs/usr/sbin/*.sh 2>/dev/null | head -20
find rootfs -name "*update*" -o -name "*upgrade*" | head
```

Update binaries that verify a signature are rare; those that do not are a persistence vector.

## NVRAM

Many embedded devices store config in NVRAM (`nvram_get`/`nvram_set`), accessible via `/dev/nvram` or a userspace daemon. Default credentials often live in a default NVRAM blob:

```bash
strings rootfs/usr/sbin/nvram | grep -iE "password|admin|ssid" | head
binwalk -e rootfs/etc/nvram.default 2>/dev/null
```

## Emulation

```bash
# chroot into the extracted rootfs with qemu
sudo cp /usr/bin/qemu-mipsel rootfs/
sudo chroot rootfs /qemu-mipsel /bin/sh
```

Fix `/etc/resolv.conf` and device nodes as needed.

## Pitfalls

- Stripped binaries lose symbol names but keep strings — grep first.
- BusyBox is often the only shell; expect `ash` syntax, not bash.
- Paths may be absolute to the flash layout, not the rootfs — check `mtd` references.

## Verification

A service started from the emulated rootfs must listen on the port the init script specifies.
