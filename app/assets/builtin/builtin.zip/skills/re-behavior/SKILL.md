---
name: re-behavior
description: "Behavioral analysis of binaries: mapping observable actions (file, registry, network, process) to intent and capabilities. Use this skill when the goal is understanding what a program does rather than how it is coded."
---

# Behavioral Analysis

## Overview

Behavior is what the program does at the OS boundary. Map every observable action to a capability, then group capabilities into intent.

## Observation points

| Layer | Tool |
|---|---|
| Process | Procmon, ETW, auditd |
| File | Procmon, `inotifywait`, fanotify |
| Registry | Procmon, `regsnap` |
| Network | Wireshark, `ss`, ETW DNS |
| Memory | Volatility, `procdump` |
| Kernel | DRAKVUF, Sysmon driver |

## Action → capability mapping

| Action | Capability |
|---|---|
| `RegSetValueEx` on `Run` | persistence |
| `CreateProcess` with `cmd /c` | command execution |
| `VirtualAllocEx` + `WriteProcessMemory` | injection |
| `CreateToolhelp32Snapshot` loops | process enumeration |
| `CryptEncrypt` over files | ransomware-like |
| `InternetOpenUrl` with POST | C2 / exfil |
| `SetWindowsHookEx` | keylogging |
| `NetUserAdd` | account creation |
| `Task Scheduler` COM | persistence |

## Automated mapping

```bash
capa -v sample.exe            # ATT&CK + MBC mapping
```

## Building a behavior trace

```bash
# Sysmon + a filter, or ETW with SilkETW
SilkETW.exe -t user -pn sample.exe -ot file -p out.json
```

```javascript
// Frida: a compact behavior log
const calls = ["CreateFileW","WriteFile","RegSetValueExW","CreateProcessW",
               "WSAConnect","connect","send","recv"];
calls.forEach(n => {
  const p = Module.findExportByName(null, n);
  if (p) Interceptor.attach(p, { onEnter(a) {
    console.log(n, a[0].isNull() ? "" : (() => { try { return a[0].readUtf8String(); } catch(e){ return a[0]; } })());
  }});
});
```

## Interpreting intent

- File writes in `%APPDATA%` + Run key = persistence via dropped payload.
- Process injection into `explorer.exe` = stealth execution.
- Periodic small POSTs = beaconing.
- Bulk `CryptEncrypt` + file rename = ransomware.

## Pitfalls

- Behavior depends on environment: a sample dormant in a VM shows nothing.
- Legitimate software uses the same APIs — intent comes from the combination and the target.
- Logging only successful calls misses attempted actions.

## Verification

Each capability claim must cite a concrete log entry with a timestamp, and the capability set must be internally consistent with a single purpose.
