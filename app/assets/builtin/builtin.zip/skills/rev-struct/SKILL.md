---
name: rev-struct
description: "Recovering data structures from binaries: inferring layouts from access patterns, rebuilding structs and classes, vtable and RTTI reconstruction, and validating layouts at runtime. Use this skill when a binary manipulates opaque objects and you need correct field types before writing a reimplementation or exploit."
---

# Struct Recovery

## Overview

A struct is inferred from **stride and offset**. Find the allocation size, the pointer arithmetic, and the field widths used at each offset; the layout falls out.

## Workflow

1. **Find the allocator.** `malloc(n)`, `new` with a size, `calloc`, or a stack frame slot.
2. **Find the stride.** `base + i*STRIDE` in an array loop gives the struct size directly.
3. **Record accesses.** For every `[reg+off]`, note width (1/2/4/8), read/write, and the operation performed.
4. **Type by use.** Compared against small ints → enum. Passed to a string function → char array/pointer. Passed to a float op → float/double.
5. **Name fields** by role, not by offset.
6. **Validate** at runtime: read the object in a debugger and check each field against your model.

## C++ vtable layout (Itanium ABI, used by GCC/Clang)

```
struct Object {
  void** vptr;        // +0x00 points into the vtable
};
// vtable[-2] = offset-to-top, vtable[-1] = typeinfo pointer
// vtable[0..n] = virtual function pointers
```

MSVC (x86):

```
+0x00 vptr (points to first virtual function slot; RTTI at vptr[-1])
```

Reconstruct by reading the vtable from `.rdata` and building a struct of function pointers. IDA's "Create struct from vtable" / Ghidra's class recovery automate the layout; you still name the methods.

## RTTI

```bash
# MSVC
strings target.exe | grep -E '^\.\?AV'
# Itanium
nm -C target | grep typeinfo
```

`type_info::name()` gives the mangled class name — demangle with `c++filt`.

## Heuristics table

| Observation | Field |
|---|---|
| `movzx eax, byte [rbx+0x10]` | `uint8` flag at 0x10 |
| `mov [rbx+0x18], rax` then `call free` | heap pointer |
| `[rbx+0x20]` compared to 0 before every use | lazy-initialized pointer |
| `[rbx+0x28]` used as `size` in a copy | length field |
| `[rbx+0x30]` loaded with `movss` | float |

## Script: record offsets

```python
import re, subprocess
out = subprocess.run(["objdump","-d","-M","intel","target"],capture_output=True,text=True).stdout
offs = {}
for m in re.finditer(r"\[(\w{3})\+(0x[0-9a-f]+)\]", out):
    offs.setdefault(int(m.group(2),16), 0)
    offs[int(m.group(2),16)] += 1
for o in sorted(offs): print(hex(o), offs[o])
```

The dense cluster of offsets is your struct; frequent small offsets often mean nested objects.

## Runtime validation

In a debugger, dump the object and test each hypothesis:

```
x/16gx $rdi
x/s *(char**)($rdi+0x8)
```

## Pitfalls

- Assuming packed layout: default alignment inserts padding after `char` fields.
- Confusing a base-subobject pointer (multiple inheritance) with the real object start.
- Mapping the same offset to different types in different code paths — that is a union.

## Verification

Write a C struct of the inferred layout, `sizeof` it, and compare with the observed allocation size and stride.
