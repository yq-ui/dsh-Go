---
name: re-format-elf
description: "ELF file format analysis: headers, program headers, sections, symbols, relocations, GOT/PLT, and dynamic linking internals. Use this skill when analyzing Linux/Android binaries, building loaders, or understanding dynamic linking behavior."
---

# ELF Format

## Overview

ELF separates the **linker view** (sections, `.text`, `.data`, `.symtab`) from the **loader view** (segments, `PT_LOAD`, `PT_DYNAMIC`). Runtime behavior follows segments; static analysis usually follows sections.

## Layout

```c
Elf64_Ehdr    // e_ident (magic 0x7f 'E' 'L' 'F'), e_type, e_machine, e_entry,
              // e_phoff/e_phnum, e_shoff/e_shnum, e_shstrndx
Elf64_Phdr[]  // p_type (PT_LOAD/PT_DYNAMIC/PT_INTERP/PT_NOTE/PT_TLS), p_offset, p_vaddr, p_filesz, p_memsz, p_flags
Elf64_Shdr[]  // sh_name, sh_type, sh_flags, sh_addr, sh_offset, sh_size, sh_link, sh_info, sh_addralign, sh_entsize
```

## Inspect

```bash
readelf -h target          # header
readelf -l target          # program headers / segments
readelf -S target          # sections
readelf -s target          # symbols
readelf -r target          # relocations
readelf -d target          # dynamic entries (NEEDED, RPATH, BIND_NOW)
objdump -d -M intel target # disassembly
nm -D --defined-only target
```

## GOT / PLT

Lazy binding: the call goes to `func@plt`, which jumps through `GOT[n]`. Initially `GOT[n]` points back to the PLT stub, which pushes the relocation index and jumps to `_dl_runtime_resolve`. After resolution, `GOT[n]` holds the real address.

```bash
objdump -d -j .plt target
readelf -r target | grep -i jump_slot
```

Full RELRO (`BIND_NOW`) resolves everything at load and makes the GOT read-only. Partial RELRO leaves `.got.plt` writable — a classic overwrite target.

## Parse with pyelftools

```python
from elftools.elf.elffile import ELFFile
f = open("target","rb"); e = ELFFile(f)
print(e.header["e_machine"], hex(e.header["e_entry"]))
for seg in e.iter_segments():
    print(seg["p_type"], hex(seg["p_vaddr"]), hex(seg["p_filesz"]), seg["p_flags"])
for sec in e.iter_sections():
    print(sec.name, hex(sec["sh_addr"]), hex(sec["sh_size"]))
```

## Relocations

| Type (x86-64) | Meaning |
|---|---|
| `R_X86_64_JUMP_SLOT` | PLT GOT entry |
| `R_X86_64_GLOB_DAT` | data GOT entry |
| `R_X86_64_RELATIVE` | base + addend (PIE) |
| `R_X86_64_64` | absolute 64-bit |

## Static vs dynamic

- `PT_INTERP` present → dynamically linked; check `DT_NEEDED` for libraries.
- No `PT_INTERP` and no `_start` → likely a shared object or a firmware blob.
- `.init_array` / `.fini_array` run before/after `main` — constructor hooks live there.

## Pitfalls

- `.bss` occupies `p_memsz > p_filesz`; file offset math must use `p_offset`.
- Stripped binaries keep `.dynsym`; dynamic symbol names survive.
- `align`/`p_align` of 0x1000 vs 0x20000 changes mapping granularity on some targets.

## Verification

`readelf -l` segment ends must cover the highest `sh_addr+sh_size` of allocatable sections.
