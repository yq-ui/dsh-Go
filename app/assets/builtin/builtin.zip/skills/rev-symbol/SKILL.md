---
name: rev-symbol
description: "Recovering symbols and function identity in stripped binaries: FLIRT/FLIRT-like signatures, library identification, demangling, function fingerprinting, and diffing against known builds. Use this skill when a binary is stripped and you need to identify library code and recover names."
---

# Symbol Recovery

## Overview

A stripped binary still contains fingerprints: compiler idioms, function prologues, string references, and byte patterns identical across builds of a library. Match those against known corpora.

## Workflow

1. **Confirm stripping.** `file`, `nm`, check `.symtab` vs `.dynsym`.
2. **Identify the toolchain.** `.comment`, `.note.gnu.build-id`, MSVC `Rich` header, Go buildinfo, Rust panic strings.
3. **Recover library code.** FLIRT (IDA), `librva`, `sig-database`, Ghidra's "Function ID".
4. **Recover runtime/CRT.** Statically linked CRT functions appear in every binary — recognize by pattern.
5. **Recover the rest manually.** Strings → xrefs → names.

## Detection

```bash
readelf -S t | grep -E 'symtab|dynsym'
objdump -s -j .comment t
strings -a t | grep -E "GCC:|clang version|Microsoft|Go build ID|rustc"
# MSVC Rich header
python3 -c "d=open('t.exe','rb').read(); i=d.find(b'Rich'); print(d[i-4:i+8].hex())"
```

## FLIRT / FID

- **IDA**: `File > Load File > FLIRT signature file`, or apply `sig/*.sig` per compiler.
- **Ghidra**: `Analysis > Function ID > Apply FID`. FID databases are per-compiler and per-library.
- **librva**: RVA-based matching against known MSVC DLL versions.

```bash
# generate a FLIRT sig from a static lib (IDA SDK)
pcf -c -n mylib.pat mylib.lib
sigmake mylib.pat mylib.sig
```

## Demangling

```bash
c++filt _ZN3Foo3barEv
# MSVC
python3 -c "import subprocess;print(subprocess.run(['dumpbin','/symbols','x.obj'],capture_output=True,text=True).stdout)"
```

Angr's `cle` backend and `miasm` also demangle.

## Function fingerprinting

- **Constants.** `0x9E3779B9` (TEA), `0x67452301` (MD5/SHA init), AES S-box at a fixed 256-byte table.
- **Prologue shape.** `55 8B EC` (MSVC x86), `48 89 5C 24 08` (MSVC x64), `F3 0F 1E FA` (endbr64).
- **String sets.** A function referencing `"invalid argument"`, `"out of range"`, `"nullptr"` is a standard-library assert.

## Cross-build matching

```bash
# compare two versions of one binary
bindiff --primary v1.exe --secondary v2.exe --output_dir ./bd
diaphora.py v1.sqlite v2.sqlite
```

Matching by call-graph topology survives recompilation better than byte matching.

## Go and Rust specifics

```bash
go tool buildid t; go version -m t        # Go: buildinfo in .rodata
strings t | grep -m5 "rustc"              # Rust: panic paths leak crate names
```

Go symbols live in `pclntab` even when stripped — `go tool objdump`, `redress`, or `go_parser` recover names.

## Pitfalls

- Applying the wrong FLIRT signature renames hundreds of functions wrongly and silently.
- Inlined functions have no symbol; the call site disappears entirely.
- LTO merges and splits functions, defeating both FLIRT and call-graph matching.

## Verification

A recovered name must be consistent with the function's arguments: if it is called `memcpy`, its first three arguments must look like `dst, src, n`.
