---
name: android-reverse-engineering
description: "Full Android reversing playbook: static and dynamic workflows, smali patching, Frida, native analysis, and repackaging, tied together as one process. Use this skill as the entry point for Android app reversing before choosing a specialized Android sub-skill."
---

# Android Reversing Playbook

## Overview

The order that works: manifest → DEX → native → runtime → patch. Skipping to runtime wastes time; skipping runtime leaves logic unproven.

## Phase 1 — Package

```bash
apktool d app.apk -o out
jadx -d out_jadx app.apk
cat out/AndroidManifest.xml | head -60
```

Record: package name, launcher activity, Application class, permissions, exported components, `minSdk`/`targetSdk`.

## Phase 2 — DEX

```bash
grep -rn "http" out_jadx/sources --include=*.java | head -20
grep -rn "Cipher\|SecretKey\|SharedPreferences" out_jadx/sources | head
```

Find the network layer and the crypto layer. Trace from an entry Activity's `onCreate` inward.

## Phase 3 — Native

```bash
unzip -o app.apk 'lib/*' -d libs/
nm -D libs/arm64-v8a/*.so | grep Java_ | head
```

If JNI methods exist, the real logic is native — switch to `re-android-native`.

## Phase 4 — Runtime

```bash
adb shell am start -n com.app/.MainActivity
frida -U -f com.app -l hook.js --no-pause
```

Confirm hypotheses from phases 1–3 with live values. This is also where packers, root checks, and SSL pinning surface.

## Phase 5 — Patch

Smali patch (small change):

```bash
# find the check
grep -rn "checkLicense" out/smali*/com/app/ | head
# edit the .smali, flip the branch
# cond_0 -> cond_1
apktool b out -o patched.apk
apksigner sign --ks my.keystore patched.apk
```

Native patch (offset):

```bash
# patch libfoo.so at 0x1234: mov w0, #0 -> mov w0, #1
printf '\x20\x00\x80\x52' | dd of=libs/arm64-v8a/libfoo.so bs=1 seek=$((0x1234)) conv=notrunc
```

Then re-zip with `zipalign -p 4` and sign.

## Common targets

| Goal | Where |
|---|---|
| API endpoints | `strings`, OkHttp interceptors |
| Auth token generation | `Crypto`, `HmacSHA256` calls |
| Premium flag | a boolean field set from a network response |
| Root detection | `RootBeer`, `su` path checks |
| Signature check | `PackageManager.getPackageInfo().signatures` |
| Integrity | `SafetyNet`/`Play Integrity` attestation |

## Pitfalls

- Play Integrity cannot be patched client-side reliably; it is a server-side decision.
- Split APKs must be merged with `bundletool` before analysis.
- `targetSdk` 34+ restricts `System.loadLibrary` from writable dirs — gadget injection needs care.

## Verification

The patched app installs, launches, and the changed behavior is visible in `logcat` plus the UI, on a clean device without the debugger attached.
