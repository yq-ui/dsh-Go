---
name: re-lldb
description: "LLDB reversing on macOS and iOS: breakpoints, expression evaluation, memory read, Objective-C introspection, and remote debugging via debugserver. Use this skill when reversing Mach-O binaries, debugging on macOS, or attaching to iOS processes."
---

# LLDB

## Overview

LLDB is the debugger for Mach-O targets. On macOS/iOS it also gives Objective-C runtime introspection, which is the fastest way into app logic.

## Basics

```bash
lldb ./target
(lldb) settings set target.x86-disassembly-flavor intel
(lldb) b main
(lldb) b -a 0x100003f20
(lldb) run
(lldb) bt
(lldb) register read
(lldb) memory read -f x -c 16 $rsp
(lldb) disassemble -n main
(lldb) image list
```

## Expression engine

```lldb
(lldb) p (int)$rax
(lldb) expr -- (void)printf("hi\n")
(lldb) po [obj description]           # Objective-C print object
(lldb) p/x *(uint64_t*)($rsp+8)
```

## Breakpoints

```lldb
(lldb) br s -n "-[MyClass checkLicense]"
(lldb) br s -n objc_msgSend -c '$rdi != 0'
(lldb) br command add 1
> register read rdi
> continue
> DONE
(lldb) br list
```

## Objective-C introspection

```lldb
(lldb) image lookup -rn checkLicense
(lldb) expr -l objc -O -- [[UIApplication sharedApplication] delegate]
(lldb) po (Class)objc_getClass("MyClass")
(lldb) expr -l objc -O -- [MyClass new]
```

## Mach-O structure

```bash
otool -l target      # load commands
otool -L target      # linked dylibs
nm -m target         # symbols
codesign -dvvv target
```

Slide calculation for PIE:

```
(lldb) image list -o -f | grep target
```
Runtime address = file offset + slide + base.

## Remote iOS

```bash
# on device (jailbroken): debugserver *:1234 -a PID
(lldb) platform select remote-ios
(lldb) process connect connect://DEVICE_IP:1234
(lldb) image list
```

Then `br s -a 0x<module_base+offset>`.

## Patching at runtime

```lldb
(lldb) memory write 0x100003f20 0x90 0x90
(lldb) register write rip 0x100003f40
```

## Pitfalls

- ASLR: file offsets are meaningless without the slide; always resolve via `image list -o`.
- `po` swallows exceptions; use `expr -l objc -O --` when it silently fails.
- On Apple Silicon, breakpoints in the dyld shared cache need `--arch arm64e` handling.

## Verification

`image lookup -a $pc` resolves to the intended symbol; the patched instruction survives a step.
