---
name: master-routing
description: "Master control routing table for the full 218-skill reverse engineering and penetration testing library. Load this skill first on any security task: it maps a request to the right skill, defines the recall protocol for reusing skills across turns, and specifies the evidence chain. Use this skill when starting work, when unsure which skill applies, or when the user says 调用技能 / 总控 / routing."
---

# Master Routing — 总控

## Overview

This is the entry point for the whole reverse-engineering and penetration-testing library (116 reverse + 102 pentest skills). Read the request, classify it, load one to three skills, then work.

## Bundle contents (read these files, they are next to this SKILL.md)

| File | Purpose |
|---|---|
| `/root/.dsh/skills/master-routing/AI-RE-ROUTER.md` | 58 KB portable router: full 235-entry index, 5-step protocol, composition table, output template. Hand this file to any model that can read files. |
| `/root/.dsh/skills/master-routing/SKILLS-INDEX.tsv` | Machine-readable index: `name \t path \t bytes \t what \t when`. Grep this to route by keyword. |
| `/root/.dsh/skills/master-routing/skills-index.json` | Same data as JSON with an explicit `load_protocol` array, for agents that parse. |
| `/root/.dsh/skills/master-routing/BOOTSTRAP.txt` | Copy-paste prompts (full / lite / one-line) for models without file access. |

Skill bodies live at `/root/.dsh/skills/<name>/SKILL.md`.

## Routing protocol

1. **Classify.** Which domain: reverse, pentest, mobile, crypto, forensics, report?
2. **Route.** Match against the tables below. Pick the most specific skill, not the most general.
3. **Load.** Read the SKILL.md body. Follow its workflow, not your default habits.
4. **Compose.** A task usually needs 1–3 skills (e.g. `re-apk` + `re-frida` + `apk-reversing`).
5. **Record.** Note which skills were used so a later turn can resume without re-deriving.

## Reverse engineering routes

| Request | Skill |
|---|---|
| any binary, unknown | `reverse-engineering` |
| tool choice / methodology | `re-skill` |
| IDA | `ida-reverse`, `rev-idapython` |
| Ghidra | `ghidra-reverse` |
| terminal / scripted | `radare2` |
| Binary Ninja | `binary-ninja-reverse` |
| x64dbg / WinDbg / gdb / lldb | `re-x64dbg`, `re-windbg`, `re-gdb`, `re-lldb` |
| emulation | `re-emulation`, `rev-unicorn-debug` |
| PE / ELF / Mach-O | `re-format-pe`, `re-format-elf`, `re-format-macho`, `portable-executable-analysis` |
| structs / symbols / odd files | `rev-struct`, `rev-symbol`, `specialized-file-analyzer` |
| packing | `re-packer-id`, `re-unpack-simple`, `re-unpack-advanced` |
| obfuscation / VM | `re-deobfuscate`, `dsl-vm-reverse` |
| anti-analysis | `re-anti-analysis` |
| scripts / bytecode | `re-script-deob`, `re-wasm` |
| games / anti-cheat | `re-game`, `re-anti-cheat`, `rev-u3d-dump` |
| Android | `re-apk`, `apk-reverse`, `apk-reversing`, `re-android-native`, `android-reverse-engineering` |
| DEX packing | `rev-dex-dumper`, `re-mobile-pack` |
| iOS | `re-ios`, `re-ios-jb` |
| Flutter / hybrid | `re-flutter`, `re-hybrid-app`, `mobile-reverse` |
| Frida | `re-frida`, `re-frida-script-author`, `rev-frida` |
| .NET / Java / Python | `re-dotnet`, `dotnet-reverse`, `re-managed`, `re-java`, `re-python` |
| Go / Rust / Zig / Nim / Swift | `re-go`, `re-rust`, `re-zig`, `re-nim`, `re-swift`, `go-rust-reverse` |
| ARM / MIPS / RISC-V / C++ ABI | `re-arm`, `re-mips`, `re-riscv`, `re-cpp-abi` |
| kernel / rootkit / hypervisor | `re-kernel`, `analyzing-linux-kernel-rootkits`, `re-hypervisor` |
| UEFI / firmware / IoT / car / ICS | `re-uefi`, `re-firmware`, `re-fw-extract`, `re-fw-rootfs`, `re-iot-proto`, `re-automotive`, `re-ics` |
| crypto | `re-crypto-id`, `re-crypto-keys`, `re-crypto-decrypt`, `13-crypto-analysis` |
| TLS / whitebox / TEE / JavaCard | `re-tls`, `re-whitebox`, `re-tee`, `re-javacard` |
| protocol / JS / Electron / extensions | `protocol-reverse`, `js-reverse`, `re-electron`, `re-browser-ext` |
| cracking / license / keygen / DRM | `re-cracking`, `re-license`, `re-keygen`, `re-drm` |
| patching / diffing | `re-patching`, `binary-diff`, `patch-diff-exploit`, `re-variant` |
| vulnerabilities / ASLR / exploit chain | `re-vuln`, `re-address-space`, `pwn-chain` |
| malware / ransomware / forensics | `re-malware`, `re-ransomware`, `re-sandbox`, `re-behavior`, `re-triage`, `re-ti`, `re-memdump`, `re-doc-malware`, `malware-analysis` |
| YARA / memory forensics | `yara-rule-authoring`, `analyzing-memory-dumps-with-volatility` |
| symbolic execution / fuzzing | `re-angr`, `re-z3`, `aflpp`, `libfuzzer`, `atheris`, `harness-writing` |
| fingerprinting / plugins | `re-fp-runtime`, `re-plugin-dev` |
| CTF / blockchain | `re-ctf`, `re-blockchain` |

## Penetration testing routes

| Request | Skill |
|---|---|
| overall planning | `kali-pentest-zh`, `pentest-tools`, `security-arsenal` |
| recon | `recon`, `passive-recon`, `target-profiling` |
| subdomains / DNS / ports | `subdomain-deep`, `subfinder-recon`, `dnsx-resolve`, `naabu-portscan`, `nmap-scan`, `masscan-scan` |
| probing / crawling / urls | `httpx-probe`, `katana-crawl`, `gau-urlfetch`, `js-api-extract` |
| fuzzing paths | `ffuf-fuzz`, `dirsearch-fuzz` |
| SQL / XSS / SSRF / SSTI | `sql-injection-methodology`, `sqlmap-advanced`, `xss-methodology`, `ssrf-methodology`, `ssti-methodology` |
| file / request / cache | `xxe-injection-methodology`, `lfi-rfi-methodology`, `file-upload-methodology`, `request-smuggling`, `http-smuggling-advanced`, `cache-poisoning-smuggling` |
| auth / session | `jwt-attack-methodology`, `oauth-sso-attack`, `csrf-methodology`, `idor-methodology`, `cors-misconfiguration` |
| logic / deserialization / injection | `business-logic-attack`, `deserialization-methodology`, `java-deserialization-methodology`, `php-serialization-audit`, `prototype-pollution-exploit`, `expression-language-injection` |
| APIs | `api-security`, `graphql-methodology`, `websocket-attack` |
| WAF / filtering | `waf-bypass-methodology` |
| Active Directory | `ad-attacks`, `ad-recon`, `bloodhound-enum`, `kerberoast-attack`, `kerberos-advanced-attack`, `adcs-certipy-attack`, `ntlm-relay-attack`, `acl-abuse`, `ad-persistence`, `windows-ad` |
| lateral / post-exploit | `lateral-movement`, `impacket-toolkit`, `nxc-cme`, `internal-recon`, `post-exploit-linux`, `post-exploit-windows`, `tunnel` |
| privilege escalation | `privesc-linux`, `privesc-win` |
| credentials | `cred-spray`, `hashcat-crack`, `hydra-brute` |
| cloud / containers | `cloud-metadata`, `cloud-aksk-exploit`, `aws-pentesting`, `azure-pentesting`, `gcp-pentesting`, `k8s-container-escape`, `k8s-network-recon`, `container-escapes`, `docker-pentesting`, `oss-bucket-exploit` |
| C2 / evasion | `cobalt-strike`, `mythic-c2`, `shellcode-loader-generate`, `evasion-technique-integrate`, `edr-bypass`, `av-edr-evasion`, `edr-bypass-re` |
| web shells | `webshell-deploy`, `webshell-management` |
| mobile / wireless / radio | `ios-pentesting`, `mobile-backend`, `wifi-wireless`, `radio-sdr` |
| social engineering | `phishing-and-social-engineering-campaigns`, `email-security`, `social-engineering-communitytools` |
| reporting | `bug-bounty`, `src-hunter`, `pentest-engagement`, `redteam-report-template`, `pentest-report-generator`, `vulnerability-triage-brocards` |
| firmware pentest / crash triage | `firmware-pentest`, `re-crash-triage` |

## Cross-domain combinations

| Task | Compose |
|---|---|
| packed Android app | `re-packer-id` + `rev-dex-dumper` + `apk-reversing` |
| malware with custom C2 | `malware-analysis` + `protocol-reverse` + `yara-rule-authoring` |
| IoT device audit | `re-firmware` + `re-fw-rootfs` + `firmware-pentest` |
| game anti-cheat research | `re-anti-cheat` + `windows-kernel-security` + `dma-attack-techniques` |
| exploit development | `re-vuln` + `re-address-space` + `pwn-chain` + `patch-diff-exploit` |
| mobile app audit | `re-apk` + `apk-reversing` + `mobile-backend` + `api-security` |
| AD compromise chain | `ad-recon` + `bloodhound-enum` + `kerberoast-attack` + `lateral-movement` + `ad-persistence` |
| license bypass | `re-license` + `re-cracking` + `re-keygen` |

## Recall protocol (memory chain)

When a later turn needs a skill used earlier, invoke it by name instead of re-deriving:

- "use the `re-deobfuscate` deflat approach from earlier"
- "apply the `yara-rule-authoring` string-selection rules"
- "continue with `pwn-chain` stage 2"

Naming a prior skill is a valid instruction. If a skill's output format was established (a findings table, an IOC list, an exploit stage), keep that format for the rest of the session.

## Output standard

Every deliverable states:

1. **What was observed** (artifact, version, exact offset/command).
2. **What was inferred** (hypothesis, marked as such).
3. **What was verified** (the test that confirms it).
4. **What remains unknown** (the next concrete step).

Mixing 1 and 2 without labeling is the failure mode this library exists to prevent.

## Pitfalls

- Loading five skills when one suffices wastes context. One to three.
- Using a general skill for a specific problem loses the specifics that make it work.
- Skipping the verification step turns analysis into guesswork.

## Verification

A routing decision is correct when the loaded skill's workflow produces the artifact the request asked for.
