---
name: re-memdump
description: "Process memory dumping and analysis: acquiring memory from live or crashed processes, reconstructing modules, and extracting secrets. Use this skill when the interesting data lives in memory rather than on disk."
---

# Memory Dumping

## Overview

Memory holds decrypted payloads, keys, configuration, and unpacked code. Acquisition options: live process, crash dump, full physical image.

## Live process

```bash
# Windows
procdump -ma <pid> out.dmp
# or Task Manager -> Create dump file
# Linux
gcore <pid>
cat /proc/<pid>/mem > out.bin   # needs ptrace rights
```

```javascript
// Frida: dump a module or range
const m = Process.getModuleByName("libfoo.so");
send({ name: m.name, data: m.base.readByteArray(m.size) });
```

## Module reconstruction

A dumped module has different section alignment than the file. Fix:

```python
import pefile
pe = pefile.PE("dump.bin", fast_load=True)
pe.OPTIONAL_HEADER.FileAlignment = pe.OPTIONAL_HEADER.SectionAlignment
for s in pe.sections:
    s.PointerToRawData = s.VirtualAddress
    s.SizeOfRawData = s.Misc_VirtualSize
pe.write("fixed.exe")
```

For ELF, `lief` re-maps segments to file offsets.

## Secrets extraction

```bash
strings -a -el dump.bin | grep -iE "password|token|key" | head -20
```

```python
# search for a known plaintext, dump context
data = open("dump.bin","rb").read()
i = data.find(b"BEGIN RSA PRIVATE KEY")
print(data[i:i+2000].decode("latin1", "replace"))
```

## Process injection artifacts

Injected code appears as `MEM_PRIVATE` regions with `PAGE_EXECUTE_READWRITE` and no file backing. Enumerate:

```python
# gdb/pwndbg
vmmap
# look for rwx regions not mapped from a file
```

Volatility for full images:

```bash
vol -f mem.raw windows.malfind
vol -f mem.raw windows.procdump --pid 1234 --dump-dir out/
```

## Crash dumps

```bash
windbg -z app.dmp
0:000> !analyze -v
0:000> lm
0:000> .dump /ma full.dmp
```

## Pitfalls

- Reading `/proc/pid/mem` requires the process to be stopped or the read to be page-aligned.
- Dumps taken after a crash may have the stack unwound.
- Windows minidumps omit most heap data — use a full dump (`-ma`).

## Verification

A reconstructed module must load in a disassembler with correct section permissions and resolvable imports.
