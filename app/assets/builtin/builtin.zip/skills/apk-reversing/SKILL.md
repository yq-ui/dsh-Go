---
name: apk-reversing
description: "Dynamic Android app reversing: Frida instrumentation, method hooking, SSL unpinning, root/emulator detection bypass, and runtime data extraction. Use this skill when static analysis is blocked by packing or obfuscation and you need runtime observation."
---

# APK Dynamic Reversing

## Overview

Runtime work answers what static cannot: decrypted strings, computed keys, server payloads, and detection logic outcomes. Frida is the instrument; `adb` is the transport.

## Setup

```bash
adb devices
adb shell getprop ro.product.cpu.abi
# push frida-server matching the ABI
adb push frida-server-16.x-android-arm64 /data/local/tmp/fs
adb shell "su -c 'chmod 755 /data/local/tmp/fs; /data/local/tmp/fs &'"
frida-ps -U | head
```

Non-root: repackage the app with a Frida gadget in `lib/<abi>/` and load it from the Application class.

## Hooking Java

```javascript
Java.perform(function () {
  const C = Java.use("com.target.net.Crypto");
  C.decrypt.implementation = function (s) {
    const r = this.decrypt(s);
    console.log("decrypt", s, "->", r);
    return r;
  };
  // constructor hook
  const D = Java.use("dalvik.system.DexClassLoader");
  D.$init.overload("java.lang.String","java.lang.String","java.lang.String","java.lang.ClassLoader")
   .implementation = function (a,b,c,d) { console.log("DCL", a); return this.$init(a,b,c,d); };
});
```

Enumerate loaded classes to find targets:

```javascript
Java.perform(() => {
  Java.enumerateLoadedClasses({
    onMatch(n) { if (n.includes("target")) console.log(n); },
    onComplete() {}
  });
});
```

## Hooking native

```javascript
const addr = Module.findExportByName("libnative.so", "Java_com_target_Native_check");
Interceptor.attach(addr, {
  onEnter(args) { console.log("arg", args[2].readUtf8String()); },
  onLeave(ret) { console.log("ret", ret.toInt32()); ret.replace(1); }
});
```

For stripped `.so`, resolve by offset: `Module.findBaseAddress("libnative.so").add(0x1234)`.

## SSL unpinning

```javascript
Java.perform(() => {
  const X509TrustManager = Java.use("javax.net.ssl.X509TrustManager");
  const SSLContext = Java.use("javax.net.ssl.SSLContext");
  const TrustManager = Java.registerClass({
    name: "com.fake.TM",
    implements: [X509TrustManager],
    methods: {
      checkClientTrusted() {}, checkServerTrusted() {},
      getAcceptedIssuers() { return []; }
    }
  });
  const ctx = SSLContext.getInstance("TLS");
  ctx.init(null, [TrustManager.$new()], null);
  SSLContext.getInstance.overload("java.lang.String").implementation = function (p) {
    return ctx;
  };
});
```

For OkHttp `CertificatePinner`, hook `check`:

```javascript
Java.use("okhttp3.CertificatePinner").check.overload("java.lang.String","java.util.List")
  .implementation = function () { };
```

## Root / emulator detection bypass

```javascript
Java.perform(() => {
  const Files = Java.use("java.io.File");
  Files.exists.implementation = function () {
    const p = this.getAbsolutePath();
    if (/su$|magisk|frida|xposed/i.test(p)) return false;
    return this.exists();
  };
  const Build = Java.use("android.os.Build");
  Build.TAGS.value = "release-keys";
  Build.FINGERPRINT.value = "google/walleye/walleye:8.1.0/OPM1/1234567:user/release-keys";
});
```

`objection -g com.target.app explore` bundles these as `android root disable`, `android sslpinning disable`.

## Extracting decrypted data

```javascript
// dump a decrypted DEX passed to InMemoryDexClassLoader
const I = Java.use("dalvik.system.InMemoryDexClassLoader");
I.$init.overload("java.nio.ByteBuffer","java.lang.ClassLoader").implementation = function (bb, cl) {
  const n = bb.remaining(), out = [];
  for (let i = 0; i < n; i++) out.push(bb.get(i) & 0xff);
  const f = new File("/sdcard/dump.dex", "wb");
  // use send() + host-side write, or Java FileOutputStream
  send({dex: out});
  return this.$init(bb, cl);
};
```

## Pitfalls

- `Java.perform` before `attach` completes silently does nothing; wait for the callback.
- Overloads need `.overload(...)` when the method is overloaded — otherwise Frida throws.
- Hooked replacements must call the original when behavior depends on it, or the app deadlocks.

## Verification

The hook logs before and after the original call, and the app's observable behavior changes consistently with the patched return.
