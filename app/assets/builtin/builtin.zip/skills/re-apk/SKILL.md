---
name: re-apk
description: "Android APK analysis: unpacking the archive, manifest decoding, smali/DEX work, native library extraction, and rebuilding a modified APK. Use this skill when starting any Android APK reversal, patching an app, or extracting its resources."
---

# APK Analysis

## Overview

An APK is a ZIP with `AndroidManifest.xml` (binary XML), `classes*.dex`, `resources.arsc`, `lib/<abi>/*.so`, and `assets/`. Each needs its own tool.

## Unpack

```bash
unzip -l app.apk | head -30
apktool d app.apk -o out        # decodes manifest, resources, smali
jadx -d out_jadx app.apk        # decompiles to Java
```

`apktool` when you need to rebuild; `jadx` when you need to read.

## Manifest

```bash
apktool d app.apk -o out && cat out/AndroidManifest.xml
# or
aapt2 dump xmltree --file AndroidManifest.xml app.apk
```

Look for: `android:debuggable`, `android:allowBackup`, exported components, `android:usesCleartextTraffic`, custom `android:name` on `<application>` (packer stub), permissions.

## DEX

```bash
unzip -o app.apk 'classes*.dex' -d dex/
d2j-dex2jar.sh dex/classes.dex -o app.jar     # then JD-GUI
baksmali d dex/classes.dex -o smali/
smali a smali/ -o classes.dex
```

Multi-DEX order matters: `classes.dex` loads first.

## Native

```bash
unzip -o app.apk 'lib/*' -d libs/
file libs/arm64-v8a/*.so
# strip check
readelf -s libs/arm64-v8a/libfoo.so | head
```

Then reverse with IDA/Ghidra (ARM64). JNI entry points are named `Java_<package>_<class>_<method>` when using static registration; dynamic registration (`RegisterNatives`) hides them — find the `JNI_OnLoad` call to `RegisterNatives` and read the table.

## Rebuild & sign

```bash
apktool b out -o patched.apk
keytool -genkey -v -keystore my.keystore -alias k -keyalg RSA -keysize 2048 -validity 10000
apksigner sign --ks my.keystore --ks-pass pass:android patched.apk
apksigner verify patched.apk
# or, for a quick debug signature
java -jar uber-apk-signer.jar -a patched.apk
```

`zipalign -p 4 in.apk out.apk` before signing on older toolchains.

## Signature check bypass

Apps comparing `PackageManager.getPackageInfo(...).signatures` need a smali patch: replace the comparison with a constant `true` return, or hook with Frida:

```javascript
Java.perform(() => {
  const PM = Java.use("android.app.ApplicationPackageManager");
  PM.getPackageInfo.overload("java.lang.String", "int").implementation = function (n, f) {
    const r = this.getPackageInfo(n, f);
    if (n === "com.target.app") r.signatures = [/* original */];
    return r;
  };
});
```

## Pitfalls

- `apktool` fails on apps with modified `resources.arsc`; use `--no-res` and patch only smali.
- Rebuilding loses the original signature — Play Integrity and signature-bound crypto break.
- Split APKs (`.apks` / AAB) need `bundletool` to reassemble before analysis.

## Verification

`apksigner verify` passes and the app launches on a device/emulator with the patched behavior visible in `logcat`.
