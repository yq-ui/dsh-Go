---
name: apk-reverse
description: "Static APK reversing methodology: entry point discovery, control-flow reconstruction from smali, string and constant recovery, and identifying security-relevant logic in Android apps. Use this skill when you need to understand an app's logic statically rather than patching it."
---

# APK Static Reversing

## Overview

Static APK work is a graph walk: manifest → Application class → entry activities → SDKs → the code you care about. Smali is verbose but unambiguous; jadx output is readable but lossy.

## Entry mapping

```bash
jadx -d out app.apk
grep -n "android:name" out/resources/AndroidManifest.xml | head -30
```

Start at the `<application android:name=...>` class — it is the earliest app code, where packers, SDK init, and anti-tamper live.

## Reading smali

```smali
.method public check(Ljava/lang/String;)Z
    .registers 4
    invoke-virtual {p1}, Ljava/lang/String;->length()I
    move-result v0
    const/16 v1, 0x10
    if-ne v0, v1, :cond_0
    const/4 v2, 0x1
    return v2
    :cond_0
    const/4 v2, 0x0
    return v2
.end method
```

Key ops: `const-string`, `invoke-*`, `if-*`, `iget/iput` (instance field), `sget/sput` (static), `new-instance`, `filled-new-array`.

## Native bridge

Find JNI methods:

```bash
grep -rn "native " out/sources/**/*.java 2>/dev/null | head
# smali
grep -rn "\.method.*native" out/smali* | head
```

Match to `Java_com_pkg_Class_method` in the `.so`, or to the `RegisterNatives` table when the name is absent.

## Crypto and secrets

```bash
grep -rn "AES\|DES\|RSA\|Cipher.getInstance" out/sources | head
grep -rEn "https?://[a-zA-Z0-9./_-]+" out/sources | head -30
grep -rn "API_KEY\|secret\|token" out/resources/strings.xml | head
```

Hard-coded keys are usually in `strings.xml`, `BuildConfig`, or a `.so`. `apkleaks` automates the sweep:

```bash
apkleaks -f app.apk -o leaks.txt
```

## Obfuscation handling

- ProGuard/R8 renames classes to `a.b.c`; behavior is intact — follow the calls, not the names.
- String encryption: find the decryptor (a static method called with a constant array) and emulate it.
- Reflection: `Class.forName("...")` with encrypted strings — decrypt first.

## Deep-link and IPC surface

```bash
aapt2 dump xmltree --file AndroidManifest.xml app.apk | grep -A3 "intent-filter"
```

Exported activities/services/receivers with intent filters are the attack surface.

## Pitfalls

- jadx fails on some obfuscated constructs and emits `// decompilation error` — fall back to smali.
- Multi-DEX: a class referenced in `classes.dex` may be defined in `classes3.dex`.
- Resources referenced through `getIdentifier()` hide strings from grep; search `res/values/strings.xml` directly.

## Verification

Trace one complete flow from an entry point to a sink in smali, and confirm each hop's arguments are consistent with its type signature.
