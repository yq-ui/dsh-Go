---
name: protocol-reverse
description: "Reversing unknown network protocols from captures: framing discovery, field identification, state machine recovery, and building a working client. Use this skill when a target speaks a custom protocol and you must document and reproduce it."
---

# Protocol Reversing

## Overview

Work from capture to specification: framing → fields → semantics → state machine → reimplementation. Each step is verified by replay.

## 1. Capture

```bash
tcpdump -i any -s0 -w cap.pcap
tshark -r cap.pcap -T fields -e tcp.payload | head
```

For encrypted transport, terminate at the client (hook the library) rather than the network.

## 2. Framing

Look for a length field at a fixed offset:

```python
import struct, collections
streams = collections.defaultdict(bytearray)
for pkt in packets:
    streams[(pkt.src, pkt.sport, pkt.dst, pkt.dport)] += pkt.payload

def plausible_len_prefix(buf):
    for off, fmt in ((0,">H"),(0,"<H"),(0,">I"),(2,">I")):
        try:
            n = struct.unpack_from(fmt, buf, off)[0]
            if 0 < n < 65535:
                yield off, fmt, n
        except struct.error:
            pass
```

Test: take the candidate length at each message start and see whether `offset + hdr + len` lands on the next recognizable header magic. The candidate that stays consistent across the whole capture is the frame length.

## 3. Field discovery

- **Differential analysis**: two captures that differ in one action; the differing bytes are that action's parameters.
- **Monotonic fields**: a counter that increments per message — sequence number.
- **Constant fields**: magic, version, message type.
- **Length-correlated fields**: change with payload size.

```python
# find fields that correlate with payload length
import numpy as np
lens = np.array([len(m) for m in msgs])
for off in range(header_len):
    col = np.array([m[off] for m in msgs])
    if np.corrcoef(col, lens)[0,1] > 0.9:
        print("length field at", off)
```

## 4. Semantics

Correlate with observable effects: send a message, see what changes on the device (LED, log line, response).

```python
# fuzz one field at a time
for v in range(0, 256):
    pkt = bytearray(base)
    pkt[7] = v
    send(pkt)
    print(v, recv())
```

## 5. State machine

Collect message sequences per session; build a graph of `(state, msg_type) -> next_state`. Responses to malformed requests reveal error paths.

## 6. Reimplementation

```python
import socket, struct

class Client:
    def __init__(self, host, port):
        self.s = socket.create_connection((host, port)); self.seq = 0
    def send(self, mtype, payload: bytes):
        body = struct.pack(">BBH", 0xA5, mtype, self.seq) + payload
        self.s.sendall(struct.pack(">H", len(body)) + body)
        self.seq = (self.seq + 1) & 0xFFFF
    def recv(self):
        n = struct.unpack(">H", self.s.recv(2))[0]
        data = b""
        while len(data) < n:
            data += self.s.recv(n - len(data))
        return data
```

## 7. Bit-packed protocols

For protocols packing fields into bit ranges (common in game and telecom protocols):

```python
class BitReader:
    def __init__(self, b): self.b, self.p = b, 0
    def read(self, n):
        v = 0
        for _ in range(n):
            byte, bit = divmod(self.p, 8)
            v = (v << 1) | ((self.b[byte] >> (7 - bit)) & 1)
            self.p += 1
        return v
```

## Pitfalls

- TCP coalesces and splits messages — parse the stream, never assume one packet per message.
- TLS 1.3 hides the handshake but not the record sizes; metadata still leaks.
- Checksums: recompute after modification or the peer drops the frame.

## Verification

Your client must complete the same transaction as the original client, verified by the server's response and the resulting state change.
