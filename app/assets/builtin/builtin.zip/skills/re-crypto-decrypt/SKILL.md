---
name: re-crypto-decrypt
description: "Decrypting data protected by a reversed binary: reconstructing the cipher pipeline, handling custom modes, and validating plaintext. Use this skill when the algorithm and key are known and the data must be decrypted."
---

# Crypto Decryption

## Overview

Decryption is pipeline reconstruction: identify every stage between stored bytes and plaintext (base64, compression, encryption, checksum), then reproduce it.

## Pipeline discovery

Typical chain:

```
stored -> base64 decode -> AES-CBC decrypt -> unpad -> zlib inflate -> protobuf
```

Find the order by breaking at each stage and inspecting the buffer.

```javascript
// Frida: log buffers at every crypto boundary
["EVP_DecryptUpdate","inflate","uncompress","BZ2_bzBuffToBuffDecompress"].forEach(n => {
  const p = Module.findExportByName(null, n);
  if (p) Interceptor.attach(p, { onEnter(a) { console.log(n, a[1], hexdump(a[0], {length:32})); } });
});
```

## Implementing

```python
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import zlib, base64

def decrypt(blob: bytes, key: bytes, iv: bytes) -> bytes:
    pt = AES.new(key, AES.MODE_CBC, iv).decrypt(blob)
    pt = unpad(pt, 16)
    return zlib.decompress(pt)

raw = base64.b64decode(open("data.b64").read())
print(decrypt(raw, KEY, IV))
```

## Custom / non-standard modes

Watch for:
- Byte-swapped block operations.
- A "tweak" derived from the block index (XTS-like).
- A key schedule modified by a constant.
- Round count changed (e.g., 10 -> 12 rounds).

Reproduce exactly: a single changed constant makes output garbage. Verify by encrypting a known plaintext and comparing.

## Keystream reuse

If CTR or a stream cipher reuses a nonce, XOR two ciphertexts to get the XOR of plaintexts:

```python
c1, c2 = bytes.fromhex("..."), bytes.fromhex("...")
x = bytes(a ^ b for a, b in zip(c1, c2))
print(x)   # plaintext1 XOR plaintext2, often human-readable in parts
```

## Format-aware decryption

| Container | Approach |
|---|---|
| SQLite | decrypt pages then repair the header |
| PDF (encrypted) | `qpdf --password=` once the key is known |
| ZIP (AES) | `7z x -p` or `pyzipper` |
| JWT | base64url decode, verify HMAC with the recovered secret |
| Protobuf | decode after decryption with `protoc --decode_raw` |

```bash
protoc --decode_raw < plain.bin
```

## Padding oracles

If a service reveals padding validity, you can decrypt CBC without the key:

```
send C[i-1] || C[i] with modified C[i-1] until padding is valid
```

Each valid padding leaks one byte of the previous block.

## Pitfalls

- IV location: CBC IV may be prepended to the ciphertext (first 16 bytes) — do not decrypt it as data.
- Compression before encryption means the plaintext is compressed; inflate after decrypt.
- Authenticated modes (GCM) reject modified ciphertext — you need the key, not an oracle.

## Verification

Decrypted output must parse as the expected format (valid protobuf, valid JSON, valid file magic).
