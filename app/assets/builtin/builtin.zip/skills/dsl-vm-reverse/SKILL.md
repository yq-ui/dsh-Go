---
name: dsl-vm-reverse
description: "Reversing custom virtual machines and bytecode interpreters implemented in protected binaries: identifying the dispatcher, mapping opcodes to handlers, lifting the VM bytecode, and rebuilding an equivalent program. Use this skill when a protector or obfuscator implements its own instruction set (VMProtect, Themida code virtualization, custom DSLs)."
---

# DSL / VM Reversing

## Overview

A virtualized region replaces native code with: fetch bytecode → decode opcode → jump to handler → mutate VM state. To reverse it you recover the instruction set and then lift the bytecode back into a high-level form.

## Anatomy

```
dispatch:
  movzx eax, byte [vm_eip]     ; fetch
  inc   vm_eip
  jmp   [handler_table + rax*8] ; dispatch
handler_add:
  mov   ecx, [vm_sp]           ; pop a
  mov   edx, [vm_sp+4]         ; pop b
  add   ecx, edx
  mov   [vm_sp], ecx           ; push result
  jmp   dispatch
```

VM state: a context struct holding `vm_eip`, `vm_sp`, the register file, and flags.

## Workflow

1. **Locate the region.** Look for the dispatch loop: one indirect jump whose targets are a dense cluster of handlers.
2. **Find the context.** A pointer that persists across handlers and is indexed consistently — often a single register (e.g. `rbp` or `r15`) holding the VM struct base.
3. **Enumerate handlers.** For each case: which stack slots it pops, what it computes, where it jumps back.
4. **Recover the opcode map.** Byte value → handler → semantics. Watch for encrypted opcodes (`opcode ^ key` before dispatch): the key is in the dispatcher.
5. **Extract bytecode.** The `vm_eip` initial value points into a data section; its length is bounded by the region that stays constant across runs.
6. **Lift.** Emulate with Unicorn or hand-write a lifter: read bytecode, map each opcode to an IR instruction.
7. **Reconstruct.** Feed the lifted IR to a decompiler or pretty-print pseudocode.

## Handler classification

```text
0x00  push imm32         -> stack push
0x01  pop / discard      -> stack adjust
0x02  add                -> binary op
0x03  load [reg+off]     -> memory read
0x04  jcc                -> conditional using vm flags
0x05  native_call        -> call into real code (the escape hatch)
```

`native_call` handlers are where real Windows APIs are reached — log the target and arguments to understand behavior without lifting everything.

## Automation sketch

```python
from unicorn import *
from unicorn.x86_const import *

uc = Uc(UC_ARCH_X86, UC_MODE_64)
# map code + data + stack, set up the VM context manually, then single-step
vm_eip = 0x600000
opcodes = []
seen = set()
pc = ENTRY
for _ in range(200000):
    uc.emu_start(pc, 0, count=1)
    pc = uc.reg_read(UC_X86_REG_RIP)
    eip = uc.mem_read(vm_eip, 1)[0]
    if (pc, eip) not in seen:
        seen.add((pc, eip))
        opcodes.append((pc, eip))
    if pc == DISPATCH:
        uc.mem_write(vm_eip, bytes([eip + 1]))   # advance
```

Build the `handler → opcode` mapping from this trace, then decode the bytecode statically.

## VMProtect specifics

- Handlers are mutated per build; no public signature set applies.
- The dispatcher is often reached through a chain of `push`/`ret` instead of `jmp [table]`.
- Native transitions ("VMEXIT") re-enter real code with adjusted context — break there to see the real API calls.

## Pitfalls

- Confusing bytecode offsets with native addresses.
- Emulating without hooking `native_call` produces a dead-end at the first API call.
- Assuming the opcode map is contiguous — many VMs scramble it per region.

## Verification

A correct lift reproduces the protected region's output for inputs the original VM handled; cross-check against the un-virtualized build of the same program if one exists.
