---
name: re-flutter
description: "Reversing Flutter apps: the Dart AOT snapshot in libapp.so, recovering class and method names with blutter, hooking Dart functions, and analyzing flutter_assets. Use this skill when a mobile or desktop target is built with Flutter and Java/ObjC analysis finds only a shell."
---

# Flutter Reversing

## Overview

Release Flutter apps compile Dart AOT into `libapp.so`, which embeds a snapshot: object pool, class table, function table, and code. Symbols are stripped but the snapshot retains structure — recoverable with `blutter`.

## Anatomy

```bash
unzip -o app.apk 'lib/*' -d libs/
file libs/arm64-v8a/libapp.so
ls libs/arm64-v8a/              # libapp.so, libflutter.so
unzip -l app.apk | grep flutter_assets | head
```

`libflutter.so` is the engine (stable per Flutter version, publicly symbolized). `libapp.so` is the app.

## blutter

```bash
git clone https://github.com/worawit/blutter
cd blutter && python3 scripts/init_env.py
python3 blutter.py /path/to/lib/arm64-v8a out_dir
```

Output:

```
out_dir/asm/            # disassembly per Dart function
out_dir/pp.txt          # the object pool (every constant, string, function ref)
out_dir/objs.txt        # class/function/field listing with offsets
out_dir/blutter_out.txt # summary
```

`objs.txt` is the map: class names, method names, and their addresses. Even with obfuscation, structure survives.

## Hooking Dart

```javascript
// blutter gives the address of a Dart function; hook it like native code
const base = Module.findBaseAddress("libapp.so");
const fn = base.add(0x3A2B10);
Interceptor.attach(fn, {
  onEnter(args) { console.log("[dart] call", args[0], args[1]); }
});
```

Dart ABI: first argument is the `Thread*` (or the receiver for instance methods); remaining arguments are in registers per Dart's calling convention. Values are tagged pointers — an integer `n` appears as `(n << 1) | 1`.

```javascript
function untag(ptr) { return ptr.toInt32() >> 1; }
```

## Strings and constants

```bash
grep -a "https://" out_dir/blutter_out.txt | head
python3 - <<'EOF'
import re
d = open("out_dir/pp.txt", encoding="utf8", errors="ignore").read()
for m in re.findall(r'"([^"]{6,80})"', d)[:60]:
    print(m)
EOF
```

The object pool holds all string literals — a full plaintext inventory without running the app.

## TLS pinning

Flutter uses BoringSSL inside `libflutter.so` (or a custom `libssl`). Hook `SSL_CTX_set_custom_verify` or patch `ssl_crypto_x509_session_verify_cert_chain` to always return 1.

```javascript
const f = Module.findExportByName("libflutter.so", "ssl_crypto_x509_session_verify_cert_chain");
if (f) Interceptor.replace(f, new NativeCallback(() => 1, "int", ["pointer","pointer"]));
```

## Pitfalls

- `blutter` requires a matching Dart version; a mismatch produces a garbage object pool. Read the Flutter version from `flutter_assets/kernel_blob.bin` strings or `version.json`.
- Obfuscated Flutter (`--obfuscate`) strips names but keeps structure — offsets still work.
- Dart integers are tagged; printing raw pointers as ints doubles them.

## Verification

A hooked Dart function must fire on the exact UI action you triggered, with argument values consistent with the input you supplied.
