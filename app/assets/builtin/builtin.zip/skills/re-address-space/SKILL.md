---
name: re-address-space
description: "Address space analysis: ASLR, PIE, memory layout, and information leaks that defeat randomization. Use this skill when an exploit needs an address leak or when analyzing a target's memory layout and mitigations."
---

# Address Space Analysis

## Overview

ASLR randomizes base addresses; a leak converts an unknown into a known. Analysis: map the layout, identify what is randomized, find leaks.

## Layout (Linux x86-64)

```
0x00007fffffffffff  stack
0x00007ffff7xxx000  shared libraries / ld.so
0x0000555555554000  PIE executable (if PIE)
0x000055xxxxxxx000  heap (brk)
0x00007fxxxxxxxxxx  mmap regions
```

```bash
cat /proc/self/maps
```

## Mitigations

```bash
checksec --file=bin
# or
readelf -h bin | grep Type        # DYN = PIE
readelf -l bin | grep GNU_STACK   # RW vs RWE
readelf -d bin | grep -E "BIND_NOW|FLAGS"
```

| Mitigation | Check |
|---|---|
| PIE | `e_type == ET_DYN` |
| NX | `GNU_STACK` without `E` |
| Canary | `__stack_chk_fail` in symbols |
| Full RELRO | `BIND_NOW` + `GNU_RELRO` |
| FORTIFY | `_chk` function symbols |

## Leak primitives

| Primitive | Leaks |
|---|---|
| Format string `%p` | stack values, return addresses |
| Uninitialized buffer output | heap/libc pointers |
| OOB read | adjacent structs with pointers |
| Partial overwrite + print | low bytes of an address |
| Error messages | pointer values in hex |

```c
printf(buf);      // if buf is input: leak everything on the stack
```

## Computing bases

Given a leaked address of a known symbol:

```python
leak = 0x7ffff7a0d123
libc_base = leak - libc.symbols["puts"]
```

With a leaked code address and no symbols, use the offset from the binary's ELF:

```python
code_base = leak - 0x1240   # offset of the leaking instruction
```

## ASLR entropy

Linux x86-64: 28 bits for mmap base, 28 for stack, ~28 for PIE. Brute force is impractical; a single leak suffices.

## Partial overwrites

If you can only overwrite the low 2 bytes of a return address, the high bytes stay valid — redirect within the same 64 KB page. Useful for re-entering a function without a full leak.

## Pitfalls

- Forked servers keep the same ASLR layout across children — one leak covers all.
- `personality(ADDR_NO_RANDOMIZE)` or `setarch -R` disables ASLR for testing; do not confuse that with a working exploit.
- A leak printed once may be rate-limited; check whether the primitive is reusable.

## Verification

The computed base must match `/proc/pid/maps` for the same process instance.
