---
name: katana-crawl
description: "Web crawling with katana: headless and standard modes, scope control, JavaScript parsing, and URL extraction. Use this skill when mapping an application's endpoints and client-side routes."
---

# katana

## Overview

katana is a crawler that parses HTML, JS, and forms. Headless mode executes JavaScript and finds routes that static parsing misses.

## Basic

```bash
katana -u https://target -silent
katana -u https://target -d 3 -silent
katana -list domains.txt -d 2 -o urls.txt
```

## JavaScript parsing

```bash
katana -u https://target -jc -silent          # parse JS files for endpoints
katana -u https://target -jsl -silent          # jsluice mode
```

## Headless

```bash
katana -u https://target -headless -silent -d 3
katana -u https://target -headless -no-sandbox -system-chrome
```

## Scope control

```bash
katana -u https://target -fs rdn -d 3          # same registered domain only
katana -u https://target -cs target.com -d 3   # custom scope regex
```

## Filtering output

```bash
katana -u https://target -silent | grep -E "\.(js|json)$" | sort -u
katana -u https://target -silent | httpx -silent -status-code
```

## Forms and parameters

```bash
katana -u https://target -fx -silent            # extract form fields
katana -u https://target -aff -silent           # automatic form fill
```

## Output formats

```bash
katana -u https://target -jsonl -o out.jsonl
katana -u https://target -f url -o urls.txt
```

## Pitfalls

- Headless mode is slow and memory-hungry; limit depth.
- Without scope control it wanders off-domain.
- JS endpoints may be relative to a base the crawler misses — feed known JS files with `-js`.

## Verification

Crawled endpoints must return valid responses; dead URLs indicate over-parsing.
