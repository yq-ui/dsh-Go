---
name: mobile-backend
description: "Mobile backend security: API authentication, token lifecycle, and server-side trust of the mobile client. Use this skill when assessing the server side of a mobile app."
---

# Mobile Backend

## Overview

Mobile apps trust the server and the server trusts the app. Break the second assumption: the client is fully controlled by the attacker.

## Capture the API

```javascript
// Frida: log every request
Java.use("okhttp3.Request$Builder").build.implementation = function () {
  const r = this.build();
  console.log(r.method(), r.url().toString(), r.headers().toString());
  return r;
};
```

Or use mitmproxy with the app's pinning bypassed.

## Authentication review

| Scheme | Question |
|---|---|
| Bearer token | how long lived? refreshable? revocable? |
| HMAC signature | is the secret in the app? (it is) |
| Certificate pinning | is it enforced server-side too? |
| Device binding | what identifies the device, and can it be spoofed? |

## Server-side trust issues

- Client sends `user_id` / `role` and the server honors it.
- Client-side validation of price, quantity, or entitlement.
- API version without auth (`/v1/` open, `/v2/` protected).
- Debug endpoints enabled in production.
- Rate limits per device ID, which is client-controlled.

```bash
curl -s https://api.target/v1/user/1002 -H "Authorization: Bearer $TOKEN"
```

## Token lifecycle

```bash
# try an old token
curl -s https://api.target/me -H "Authorization: Bearer $OLD"
# try after logout
# try on a different device
```

Tokens that survive logout or password change are a finding.

## Push notifications

- Push payloads may contain sensitive data.
- Push tokens are long-lived identifiers.

## Deep links into the app

A server-controlled deep link that triggers an authenticated action is a CSRF-like vector.

## Pitfalls

- Some apps pin certificates in a native library — hook the native verify.
- Rate limits may be per-IP, so a proxy pool bypasses them.
- Attestation (Play Integrity, App Attest) is server-side and cannot be patched client-side.

## Verification

A server-side trust failure must be shown with a modified client request producing an unauthorized effect.
