---
name: re-dotnet
description: "Reversing .NET assemblies: metadata structure, IL, dnSpy/ILSpy workflows, deobfuscation with de4dot, and reconstruction of native AOT and single-file bundles. Use this skill when the target is a .NET executable or library and you need readable source-level logic."
---

# .NET Reversing

## Overview

A .NET assembly carries full metadata: type names, method signatures, IL bodies, string literals. Reversal is decompilation, not disassembly — unless the app is obfuscated or AOT-compiled.

## Structure

```
PE header -> CLR header (data directory 14)
  -> COR20 header { MetaData RVA, Flags, EntryPointToken }
  -> Metadata root { streams: #~ (tables), #Strings, #US (user strings), #Blob, #GUID }
  -> MethodDef table -> RVA -> IL body
```

```bash
# identify
strings app.exe | grep -m2 "mscoree\|BSJB"
python3 -c "import pefile;pe=pefile.PE('app.exe');print(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress)"
```

## Decompile

```bash
ilspycmd app.exe -o out/            # ILSpy CLI
# or dnSpy (GUI): open, browse, edit IL/C#, save module
# or dotPeek
```

dnSpy's edit-and-save is the practical patching path: change a method body, `File > Save Module`.

## Obfuscation

| Obfuscator | Marker |
|---|---|
| ConfuserEx | `ConfusedByAttribute`, many `<Module>.cafe` types |
| .NET Reactor | `NativePayload`, `Reactor` strings |
| SmartAssembly | `PoweredByAttribute`, `[CompilerGenerated]` noise |
| Dotfuscator | renaming patterns, string encryption |
| Eazfuscator | `Eazfuscator.NET` attributes |

```bash
de4dot app.exe -o clean.exe
de4dot --dont-rename clean.exe   # when renaming breaks reflection
```

Then re-open in dnSpy. For control-flow flattening, run `de4dot` with `--cflow` or use `dnSpy` + `Unflatten` extensions.

## Strings

```bash
# encrypted strings resolved at runtime
# hook the decryptor in dnSpy: set a breakpoint on the String decryption method
# or use a script: Script Engine (C#)
```

```csharp
// dnSpy script: dump all strings from a decryptor
var m = typeof(SomeType).GetMethod("Decrypt", BindingFlags.Static | BindingFlags.NonPublic);
foreach (var f in typeof(SomeType).GetFields(BindingFlags.Static | BindingFlags.NonPublic))
    if (f.FieldType == typeof(string)) Console.WriteLine(f.Name + " = " + f.GetValue(null));
```

## Native AOT / single-file

Modern .NET can publish native AOT (`app.exe` with no IL) or single-file bundles (`--self-contained`).

```bash
# single-file: extract the bundle
python3 -c "
d=open('app.exe','rb').read()
i=d.find(b'\x00\x00\x00\x00\x00\x00\x00\x00')
print(len(d))
"
# use single-file-bundle-extractor / dnSpy 7+ which handles bundles
```

Native AOT: no metadata, treat as native code (see `reverse-engineering`).

## Runtime hooking

```bash
# Harmony patch via a loader DLL
# or Frida + CLR bridge is unreliable; prefer Harmony
```

```csharp
var harmony = new Harmony("x");
harmony.Patch(AccessTools.Method(typeof(Check), "IsValid"),
  prefix: new HarmonyMethod(typeof(Patch), nameof(Patch.Pre)));
```

## Pitfalls

- `de4dot` on a mixed-mode assembly destroys the native parts.
- Reflection-based code breaks when names are renamed — run `--dont-rename`.
- `dnSpy` saving an assembly with strong-name signing produces an invalid signature; strip the strong name first (`SNRemove`).

## Verification

The decompiled method body compiles conceptually (valid IL), and patched behavior is observable at runtime.
