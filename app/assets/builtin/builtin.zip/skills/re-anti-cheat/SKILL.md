---
name: re-anti-cheat
description: "Reverse engineering anti-cheat systems and their detection surfaces: driver IOCTL protocols, callback registration, integrity checks, heartbeat telemetry, and how protections observe the process. Use this skill when analyzing anti-cheat modules, evaluating detection mechanisms, or researching protection design."
---

# Anti-Cheat Reversing

## Overview

An anti-cheat is a set of sensors plus a policy engine. Reversing it means enumerating sensors (kernel callbacks, user-mode scans, telemetry) and understanding what each reports.

## Sensor inventory

**Kernel:**

| Mechanism | What it sees |
|---|---|
| `PsSetCreateProcessNotifyRoutineEx` | process creation, image path |
| `PsSetLoadImageNotifyRoutine` | every DLL/driver load, including manual maps |
| `ObRegisterCallbacks` | handle creation with `PROCESS_VM_READ`, `THREAD_SET_CONTEXT` |
| `CmRegisterCallback` | registry writes |
| `FltRegisterFilter` | file system operations |
| `KeStackAttachProcess` + walk | cross-process memory reads by the AC itself |
| `NtQuerySystemInformation` | handles, modules, threads |
| `EtwRegister` / TI | telemetry providers |
| `HalPrivateDispatchTable` hook | hypervisor visibility |

**User mode:** module hashing, window enumeration, debugger checks, timing, screenshot capture, input analytics.

## IOCTL protocol reversing

```c
// driver: locate the dispatch
DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DispatchIoctl;

NTSTATUS DispatchIoctl(PDEVICE_OBJECT dev, PIRP irp) {
  auto stack = IoGetCurrentIrpStackLocation(irp);
  switch (stack->Parameters.DeviceIoControl.IoControlCode) {
    case 0x222003: /* ... */
  }
}
```

`IoControlCode` encodes: `DeviceType(16) | Access(2) | Function(12) | Method(2)`.

```
CTL_CODE(devicetype, function, method, access)
method: 0=BUFFERED, 1=IN_DIRECT, 2=OUT_DIRECT, 3=NEITHER
```

Dump the switch in IDA — the case constants are the ABI. Request struct layout comes from `AssociatedIrp.SystemBuffer` casts.

## Callback detection

```c
// enumerate without symbols: scan the callback arrays
// PsSetCreateProcessNotifyRoutineEx2 stores entries in PspCreateProcessNotifyRoutine
```

Symbols resolve it in WinDbg:

```
0: kd> dps nt!PspCreateProcessNotifyRoutine L10
0: kd> !drvobj \Driver\acdrv 2
```

## Integrity checks

- Hash of `.text` via `MmCopyVirtualMemory` or MD5 loop — find the compare and the hash source.
- Page-table walk to detect hidden pages (`!pte`).
- `NtQueryVirtualMemory` + `MEM_PRIVATE` executable regions.
- `KiPreprocessFault` / `#PF` handler checks for shadow hooks.

## Telemetry / heartbeat

Look for periodic `DeviceIoControl` calls from the user-mode service. The payload often contains: process list hash, module hashes, loaded driver list, and a session token.

```python
# Frida: log every DeviceIoControl on the AC device handle
const f = Module.getExportByName("kernel32.dll", "DeviceIoControl");
Interceptor.attach(f, {
  onEnter(a) { console.log("ioctl", a[1].toInt32().toString(16), a[2], a[3].toInt32()); }
});
```

## Pitfalls

- The driver is often packed/obfuscated with a custom VM; start from the IOCTL strings and imports.
- PatchGuard protects SSDT and some structures; do not write to them.
- A driver that fails to load silently reports nothing — check `!drvobj` first.

## Verification

Every sensor you map must be triggerable: cause the event and observe the report in the AC's network traffic or log file.
