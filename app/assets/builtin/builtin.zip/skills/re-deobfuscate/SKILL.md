---
name: re-deobfuscate
description: "Deobfuscating code: control-flow flattening, opaque predicates, string encryption, junk code, mixed boolean-arithmetic, and binary rewriting to a readable form. Use this skill when the target's logic is obscured but not virtualized, and you need readable control flow."
---

# Deobfuscation

## Overview

Obfuscation adds noise without changing semantics. Deobfuscation removes the noise while preserving behavior. Work on a copy, verify equivalence at each step.

## Taxonomy and counters

| Obfuscation | Appearance | Counter |
|---|---|---|
| Control-flow flattening | `while(1) switch(state)` dispatcher | state variable analysis, `deflat` plugin |
| Opaque predicates | `if ((x*x - x) % 2 == 0)` always true | constant folding, symbolic execution |
| MBA (mixed boolean-arithmetic) | `(x ^ y) + 2*(x & y)` for `x + y` | `sspam`, `MBA-Solver`, simplification rules |
| String encryption | decrypt loop before each `strcmp` | emulation, run-and-dump |
| Dead code / junk | unreachable blocks, junk jumps | reachability analysis |
| Instruction substitution | `sub eax, -1` for `inc eax` | peephole normalization |
| Call indirection | every call via a table | table resolution |
| Bogus branches | `jz` to the next instruction | pattern removal |

## Control-flow flattening

IDA plugin `deflat` (by eshard) or Ghidra's `deobfuscation` scripts detect the dispatcher, find the state variable, and rebuild direct edges.

Manual method:
1. Identify the dispatcher block: a large `switch` on one variable.
2. For each case, find the assignment to the state variable that follows it — that is the real successor.
3. Rebuild the CFG from those assignments.

```python
# sketch: find "mov <state>, imm" right before the dispatcher jump
for ea in idautils.Functions():
    for h in idautils.Heads(*ida_funcs.get_func(ea).__iter__() if False else (ida_funcs.get_func(ea).start_ea, ida_funcs.get_func(ea).end_ea)):
        if idc.print_insn_mnem(h) == "mov" and idc.get_operand_type(h, 0) == idc.o_reg:
            print(hex(h), idc.generate_disasm_line(h, 0))
```

## String decryption

Two paths:

- **Static**: emulate the decryption function with Unicorn for every call site; patch the decrypted literal in place.
- **Dynamic**: set a breakpoint on the consumer (`strcmp`, `lstrcmpW`), read the argument, log `(call_site, plaintext)` pairs, then annotate the database.

```python
# hook the consumer in Frida, dump plaintext per call site
Interceptor.attach(Module.getExportByName(null, "strcmp"), {
  onEnter(a) {
    console.log(this.returnAddress, a[0].readUtf8String(), a[1].readUtf8String());
  }
});
```

## MBA simplification

```python
# rule examples applied with a peephole engine
RULES = [
    ("(x ^ y) + 2 * (x & y)", "x + y"),
    ("(x | y) + (x & y)",     "x + y"),
    ("(x ^ y) + (x & y)",     "x | y"),
    ("x - (-y)",              "x + y"),
    ("(x & ~y) | (x & y)",    "x"),
]
```

Tools: `sspam` (IDA), `SiMBA` (symbolic MBA solver), `msynth` (Neural MBA simplification), Ghidra `MBA` scripts.

## Binary rewriting

Use `lief` to patch instructions, `capstone` + `keystone` to disassemble and reassemble a block, or `Triton` to symbolically execute and emit simplified expressions.

```python
from capstone import Cs, CS_ARCH_X86, CS_MODE_64
from keystone import Ks, KS_ARCH_X86, KS_MODE_64
cs = Cs(CS_ARCH_X86, CS_MODE_64); ks = Ks(KS_ARCH_X86, KS_MODE_64)
for i in cs.disasm(code, addr):
    print(hex(i.address), i.mnemonic, i.op_str)
```

## Pitfalls

- Removing a branch that looks opaque but is input-dependent breaks the binary.
- Reassembly changes instruction lengths; every relative jump after the patch site must be fixed.
- Handles: a deobfuscated binary must still pass its own integrity check if it hashes its code.

## Verification

Run the deobfuscated binary on the same test inputs as the original; identical observable behavior plus a straight-line CFG is the success condition.
