---
name: radare2
description: "radare2/rizin command-line reversing: analysis flags, function navigation, visual modes, binary info, patching, scripting with r2pipe, and emulation with ESIL. Use this skill when reversing from a terminal, scripting analysis, or working on targets where a GUI is unavailable."
---

# radare2 / rizin

## Overview

r2 is a scriptable RE framework on the command line. Everything is a command; everything is pipeable. Same knowledge transfers to rizin (`rizin`, `rz-bin`, `rz-asm`).

## Startup

```bash
r2 -A ./target           # analyze all
r2 -d ./target           # debug
r2 -n ./target           # no analysis (raw)
r2 -b 32 ./target        # force 32-bit
r2 -a arm -b 16 fw.bin   # ARM Thumb firmware
r2 -m 0x8000000 fw.bin   # map at base
```

## Core commands

| Command | Meaning |
|---|---|
| `iI` | file info (arch, bits, class, compiler) |
| `iS` | sections |
| `ii` / `iE` | imports / exports |
| `iz` / `izz` | strings (data / whole file) |
| `afl` | list functions |
| `axt @ addr` | xrefs to |
| `pdf @ sym.main` | disassemble function |
| `pdc @ f` | pseudo-decompile |
| `pdg @ f` | ghidra decompiler (r2dec/ghidra plugin) |
| `VV` | graph view |
| `V` | visual mode |
| `wx 90 @ addr` | write NOP |
| `wa nop @ addr` | assemble-and-write |
| `wtf file @ addr` | dump to file |
| `/x 488b??89` | byte search |
| `/R pop rdi` | ROP gadget search |
| `e asm.arch=arm` | change arch at runtime |

## Practical session

```bash
r2 -A ./crackme
[0x00401000]> aaa                 # deeper analysis
[0x00401000]> afl~main            # find main
[0x00401000]> s sym.main
[0x00401000]> pdf
[0x00401000]> axt @ str.Wrong     # who uses the failure string
[0x00401000]> s 0x00401234
[0x00401000]> wa jmp 0x401300 @ 0x00401234
[0x00401000]> wao /tmp/patched    # write patched binary
```

## r2pipe scripting

```python
import r2pipe
r2 = r2pipe.open("./target", flags=["-A"])
for f in r2.cmdj("aflj") or []:
    print(hex(f["offset"]), f["name"], f["size"])
r2.cmd("s sym.check; pdf")
r2.quit()
```

```bash
r2 -q -c 'aflj' -c 'q' ./target | jq -r '.[] | "\(.offset) \(.name)"'
```

## Emulation

```bash
r2 -A ./target
> aeim                 # init ESIL memory
> aeip                 # set PC to current seek
> s sym.check
> afij                 # function info
> aeim; aeip
> aesu 0x401050        # step until
> ar eax                # read register
```

## Patching

```bash
# patch file in place, no GUI
rabin2 -O help ./t.exe
r2 -w -q -c 's 0x401000; wx eb' -c q ./t.exe
python3 -c "d=bytearray(open('t.exe','rb').read()); d[0x400]=0xEB; open('p.exe','wb').write(d)"
```

## Pitfalls

- File offset vs virtual address: use `iS` to map sections, `s` sets virtual by default in a loaded binary.
- `-A` on a packed binary produces junk; dump first.
- ESIL is incomplete — syscalls and some FPU ops are stubs.

## Verification

`pd` before and after the patch; dump and diff with `cmp -l`.
