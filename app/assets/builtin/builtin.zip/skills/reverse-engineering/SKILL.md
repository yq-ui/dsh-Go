---
name: reverse-engineering
description: "Overview and entry point for binary reverse engineering: static analysis, dynamic analysis, unpacking, and reconstruction of program logic across PE/ELF/Mach-O, mobile, embedded and managed targets. Use this skill when starting any RE task, choosing a toolchain, or routing to a more specialized reverse skill."
---

# Reverse Engineering — Master Entry

## Overview

Reverse engineering is a loop: observe an artifact, form a hypothesis about its logic, test the hypothesis against bytes or runtime state, record the result. Static tools read structure without executing. Dynamic tools observe execution. Neither alone is enough on protected targets.

## Workflow

1. **Triage.** Identify format, architecture, bitness, compiler, linker, protections (packer, VMProtect/Themida, .NET obfuscator, anti-debug, integrity checks).
2. **Map.** Enumerate imports, exports, sections, strings, resources, entropy per section. High entropy + few imports usually means packed.
3. **Locate the decision.** Find where behavior diverges: a compare, a branch on a flag, a license check, a decryptor loop, a dispatcher.
4. **Reach it.** Static: follow xrefs. Dynamic: breakpoint the API/data, walk back the stack.
5. **Model it.** Write down the algorithm in pseudocode before patching or reimplementing.
6. **Verify.** Reproduce the behavior: same output, same branch, same generated key.

## Triage commands

```bash
file target; rabin2 -I target         # arch, bits, strip, canary, nx, pic
diec target                            # Detect It Easy: compiler, packer
strings -a -n 6 target | head -50
ent target 2>/dev/null || python3 -c "import math,sys;d=open('target','rb').read();\
import collections;c=collections.Counter(d);print(-sum(v/len(d)*math.log2(v/len(d)) for v in c.values()))"
```

```bash
# packed? compare raw size vs in-memory size, check section names
readelf -lS target | head -60
objdump -h target | sort -k3 -r | head
```

## Choosing the tool

| Situation | Tool |
|---|---|
| Native x86/x64 disassembly + decompiler | IDA Pro / Ghidra / Binary Ninja |
| Quick scripting / CI / no GUI | radare2 `r2 -A`, rizin |
| Live Windows debugging | x64dbg, WinDbg |
| Live Linux debugging | gdb + pwndbg/gef |
| Live macOS/iOS | lldb |
| Emulate one function | Unicorn, Qiling |
| Managed code | dnSpy, ILSpy, de4dot |
| Mobile | jadx, apktool, Frida |

## Core techniques

- **Xref walking.** Data-driven: find the string/constant, list code references, read the compare that consumes it.
- **API breakpointing.** Break on `CreateFileW`, `RegQueryValueEx`, `MessageBoxA`, `getaddrinfo`; the call stack shows the caller and the argument construction.
- **Delta debugging.** NOP one branch at a time and observe which one changes behavior.
- **Differential analysis.** Diff two versions of the same binary (`bindiff`, `diaphora`) to find the changed check.
- **Constant hunting.** Search for magic numbers, S-boxes, round constants (`0x9E3779B9`, `0x5A827999`) to identify crypto.

## Pitfalls

- Trusting a decompiler on optimized code — re-read the assembly when a variable looks impossible.
- Ignoring the loader: TLS callbacks, delay-load imports, and manual mapping run before `main`.
- Forgetting relocation/ASLR when comparing runtime addresses to file offsets.
- Patching a copy that still holds an integrity hash elsewhere (two checks, not one).

## Verification

A reversal is correct when the reconstructed logic reproduces observed behavior on inputs the original never saw. Keep a test vector table: input, original output, reconstructed output.
