---
name: re-ctf
description: "CTF reversing workflow: rapid triage under time pressure, common challenge patterns, and solver scripting. Use this skill when solving a reversing challenge with a deadline."
---

# CTF Reversing

## Overview

CTF reversing is time-boxed: get the flag, not a full understanding. Pattern recognition beats depth.

## First 5 minutes

```bash
file chal; checksec --file=chal
strings -a chal | head -40
./chal
```

Many challenges are solvable from `strings` alone (flag in plaintext, or a single `strcmp`).

## Common patterns

| Pattern | Approach |
|---|---|
| `strcmp(input, "flag{...}")` | read the constant |
| XOR loop | dump the key, reverse |
| VM / interpreter | dump the opcode map, write a disassembler |
| Anti-debug | patch `ptrace`, run |
| Packed | `upx -d` |
| Python bytecode | `uncompyle6` / `decompyle3` |
| .NET | `dnSpy` |
| Java | `cfr` |
| Self-modifying | dump after the modification |

## Fast solver: symbolic execution

```python
import angr
p = angr.Project("./chal")
s = p.factory.entry_state()
simgr = p.factory.simgr(s)
simgr.explore(find=lambda st: b"Correct" in st.posix.dumps(1))
print(simgr.found[0].posix.dumps(0))
```

## Fast solver: Z3 transcription

```python
from z3 import *
f = [BitVec(f"c{i}", 8) for i in range(24)]
s = Solver()
for c in f: s.add(c >= 32, c < 127)
# transcribe the checks
s.add(f[0] == ord("f"), f[1] == ord("l"), f[2] == ord("a"), f[3] == ord("g"))
s.add(((f[4] ^ 0x42) + f[5]) & 0xFF == 0x9C)
if s.check() == sat: print("".join(chr(s.model()[c].as_long()) for c in f))
```

## Dynamic shortcut

Set a breakpoint right before the success branch and read the flag from memory — often faster than solving:

```bash
gdb -q ./chal
(gdb) b *main+0x1a0
(gdb) run <<< "AAAA"
(gdb) x/s $rsp
```

## Anti-debug quick patches

```bash
# ptrace check
python3 -c "
d=bytearray(open('chal','rb').read())
i=d.find(b'\x0f\x85')  # jne after ptrace
"
```

## Pitfalls

- Don't over-engineer — CTF flags are often in `strings`.
- Check for multiple stages (the binary reads a second file).
- Verify the flag format from the challenge description.

## Verification

The flag must be accepted by the challenge's submission endpoint.
