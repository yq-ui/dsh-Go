---
name: masscan-scan
description: "Masscan for high-speed port scanning: rate control, output formats, and combining with nmap for verification. Use this skill when scanning large address ranges quickly."
---

# masscan

## Overview

masscan is an asynchronous scanner that can cover the IPv4 space in minutes. It trades depth for speed — always verify with nmap.

## Basic

```bash
masscan -p1-65535 --rate 10000 10.0.0.0/24
masscan -p80,443,22,3389 --rate 5000 -iL targets.txt
masscan 10.0.0.0/8 -p443 --rate 100000
```

## Output

```bash
masscan -p1-65535 --rate 10000 10.0.0.0/24 -oJ out.json
masscan -p1-65535 --rate 10000 10.0.0.0/24 -oX out.xml
masscan -p1-65535 --rate 10000 10.0.0.0/24 -oL out.txt
```

## Handoff to nmap

```bash
masscan -p1-65535 --rate 10000 10.0.0.0/24 -oG masscan.gnmap
nmap -sV -sC -iL <(grep -oE "[0-9.]+" masscan.gnmap | sort -u)
```

Or with `--nmap` output:

```bash
nmap -sV -p $(masscan --rate 10000 -p1-65535 target -oL - | awk '/open/{print $4}' | paste -sd,)
```

## Rate guidance

| Network | Rate |
|---|---|
| Local LAN | 10000–100000 |
| Internet, single host | 1000–5000 |
| Internet, wide range | 100000 (with care) |
| Fragile OT/ICS | 10–100 |

## Interface and source

```bash
masscan --interface eth0 --router-mac 00:11:22:33:44:55 -p80 target
masscan -p80 --adapter-ip 10.0.0.5 target
```

## Pitfalls

- masscan's own TCP stack can conflict with the OS — use `--src-ip` or a dedicated interface.
- High rates look like a DoS; stay within authorization.
- No version detection, no scripts, no OS fingerprint.

## Verification

Every port masscan reports must be confirmed open by nmap or a direct connect.
