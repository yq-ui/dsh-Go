---
name: ad-recon
description: "Active Directory reconnaissance: domain enumeration, trust mapping, user and computer discovery, and attack-path collection. Use this skill right after gaining any domain credential."
---

# AD Recon

## Overview

Map: domains, trusts, users, groups, computers, GPOs, ACLs, sessions, and delegation. Everything else follows from that map.

## Unauthenticated

```bash
enum4linux-ng -A 10.0.0.10
nxc smb 10.0.0.0/24 -u '' -p '' --shares
rpcclient -U '' -N 10.0.0.10 -c 'enumdomusers;enumdomgroups;querydominfo'
ldapsearch -x -H ldap://10.0.0.10 -b "dc=domain,dc=local" "(objectClass=user)" sAMAccountName
```

## Authenticated

```bash
bloodhound-python -u user -p pass -d domain.local -ns 10.0.0.10 -c all
nxc ldap DC -u user -p pass --users --groups --admin-count
nxc smb DC -u user -p pass --shares --sessions --loggedon-users
```

## Trust enumeration

```bash
nxc ldap DC -u user -p pass -M enum_trusts
# or
Get-ADTrust -Filter * | select Name,Direction,Target
```

Trust direction determines attack direction: bidirectional + SID history enabled = cross-domain escalation.

## Delegation

```bash
# unconstrained
nxc ldap DC -u user -p pass --trusted-for-delegation
# constrained / RBCD
bloodyAD -u user -p pass -d domain.local --host DC get object 'COMPUTER$' --attr msDS-AllowedToDelegateTo,msDS-AllowedToActOnBehalfOfOtherIdentity
```

## ACL collection

BloodHound's `Shortest Paths to Domain Admins` is the output that matters. Key edges: `GenericAll`, `GenericWrite`, `WriteDacl`, `WriteOwner`, `ForceChangePassword`, `AddMember`, `AllExtendedRights`.

```bash
bloodyAD -u user -p pass -d domain.local --host DC get writable
```

## Sessions and local admins

```bash
nxc smb 10.0.0.0/24 -u user -p pass --local-auth --shares
# or
netexec smb 10.0.0.0/24 -u user -p pass --loggedon-users
```

A domain admin's session on a workstation = an escalation target.

## GPO enumeration

```bash
nxc ldap DC -u user -p pass -M gpp_password
nxc ldap DC -u user -p pass -M gpp_autologin
# PowerShell
Get-GPO -All | select DisplayName,Id
```

## Output to BloodHound

```bash
bloodhound-python -u user -p pass -d domain.local -ns DC -c All --zip
# then upload the zip to BloodHound
```

## Pitfalls

- LDAP signing and channel binding block some unauthenticated enumeration.
- Unauthenticated null sessions are rare on modern domains.
- Trust enumeration from a child domain does not show parent resources.

## Verification

Each discovered object must be confirmable by a direct LDAP query or SMB connection.
