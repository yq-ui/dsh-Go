---
name: portable-executable-analysis
description: "Deep analysis of Windows PE internals for detection and reconstruction: section anomalies, import table tampering, resource carving, overlay payloads, signature validation, and loader behavior. Use this skill when triaging suspicious PE files, building loaders, or detecting injected or hollowed images."
---

# Portable Executable Analysis

## Overview

Where `re-format-pe` teaches the structure, this skill is about **judging** a PE: which fields are inconsistent with a normally built binary, and what that implies.

## Triage scorecard

| Signal | Meaning |
|---|---|
| Entry point in a writable, non-executable section | Loader stub / packer |
| `VirtualSize` 0, nonzero raw size | Section appended after build |
| Imports < 10 for a large binary | Resolved dynamically or packed |
| Import RVA outside any section | Rebuilt IAT / hollowing |
| Section name gibberish (`.aspack`, `UPX0`, `MPRESS1`) | Known packer |
| Overlay after last section | Appended payload, config, or dropper |
| `.text` entropy > 7.2 | Encrypted or compressed code |
| Timestamp 0 or far future | Deliberate anti-forensics |
| Checksum mismatch | Patched post-build |
| `SizeOfImage` < last section end | Truncated / hand-crafted |

## Section anomaly script

```python
import pefile, math
pe = pefile.PE("s.exe")
last = max(s.VirtualAddress + s.Misc_VirtualSize for s in pe.sections)
assert pe.OPTIONAL_HEADER.SizeOfImage >= ((last + 0xfff) & ~0xfff), "SizeOfImage too small"
for s in pe.sections:
    ent = s.get_entropy()
    if ent > 7.2: print("high entropy:", s.Name, ent)
for d in pe.OPTIONAL_HEADER.DATA_DIRECTORY[pefile.DIRECTORY_ENTRY["IMAGE_DIRECTORY_ENTRY_IMPORT"]:][:1]:
    if d.VirtualAddress and not any(s.VirtualAddress <= d.VirtualAddress < s.VirtualAddress + s.Misc_VirtualSize for s in pe.sections):
        print("import dir outside sections")
```

## Import table reconstruction

Detect a rebuilt IAT by checking that each `IMAGE_IMPORT_DESCRIPTOR.Name` points to a readable section containing a plausible DLL name, and each thunk's `Name` RVA resolves to an ASCII function name. Mismatches mean a manual-mapped module.

## Resources

```python
for r in pe.DIRECTORY_ENTRY_RESOURCE.entries:
    print(r.id, r.name)
    for t in r.directory.entries:
        for l in t.directory.entries:
            d = l.data.struct
            off = d.OffsetToData - pe.OPTIONAL_HEADER.ImageBase  # usually already RVA in pefile
```

Carve embedded executables by looking for a second `MZ`/`PE\0\0` pair inside resources or the overlay.

## Signature validation

```powershell
Get-AuthenticodeSignature .\target.exe | Format-List
```

```python
import pefile
pe = pefile.PE("target.exe")
print("security dir size:", pe.OPTIONAL_HEADER.DATA_DIRECTORY[4].Size)  # nonzero = signed blob present
```

A signature that covers only part of the file (the `SpcIndirectDataContent` digest excludes the overlay) means the overlay can be modified without breaking the signature.

## Hollowing / injection artifacts

- Image base mismatch between the on-disk PE and the memory-mapped one.
- `PIMAGE_DOS_HEADER` zeroed in memory but intact on disk (classic process hollowing) — requires live memory.
- Section with `IMAGE_SCN_MEM_WRITE | IMAGE_SCN_MEM_EXECUTE` (RWX) — JIT or injected shellcode.
- Mismatched `SizeOfImage` vs actual mapped region — check with `VirtualQuery`.

## Pitfalls

- pefile normalizes some RVAs; confirm raw offsets with `pe.get_offset_from_rva`.
- A wrong checksum is normal for many linkers; do not treat it as malicious.
- Entropy is a heuristic: a compressed bitmap resource is also high entropy.

## Verification

Cross-check with `dumpbin /headers` or `objdump -x`; discrepancies between parsers usually indicate a deliberately malformed file.
