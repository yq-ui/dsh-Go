---
name: analyzing-linux-kernel-rootkits
description: "Analyzing Linux kernel rootkits: module hiding, syscall table hooking, DKOM, eBPF abuse, and detection of kernel-level persistence. Use this skill when analyzing a Linux kernel module or investigating a suspected kernel compromise."
---

# Linux Kernel Rootkits

## Overview

A kernel rootkit hides its own presence and usually the attacker's processes, files, and connections. Analysis is about finding the divergence between what the kernel reports and what actually exists.

## Classes

| Technique | Mechanism |
|---|---|
| LKM hiding | remove from `modules` list, zero `list.prev/next` |
| Syscall hooking | patch `sys_call_table`, or ftrace/kprobe hooks |
| VFS hooking | replace `file_operations`, `inode_operations` |
| DKOM | unlink `task_struct` from `tasks`, hide PID |
| eBPF | load a program that filters `getdents`, `readlink` |
| `kallsyms` tampering | hide symbols from `/proc/kallsyms` |
| ftrace | register `ftrace_ops` for a syscall |
| IDT/MSR hooks | rare on Linux, but `sysenter` patching exists |

## Detection: compare sources

```bash
# processes: /proc vs BPF vs raw task list
ls /proc | grep -E '^[0-9]+$' | sort -n > a
ps -e -o pid= | sort -n > b
diff a b          # PIDs in /proc but not in ps = hidden from ps
```

```bash
# modules: loaded vs /sys/module
ls /sys/module | sort > a
cat /proc/modules | awk '{print $1}' | sort > b
diff a b
```

```bash
# syscall table integrity
grep sys_call_table /proc/kallsyms
# dump and compare each entry against the expected symbol within the kernel text range
```

Anyone with `kallsyms` access can script the check:

```bash
python3 - <<'EOF'
import re, subprocess
sym = {}
for l in open("/proc/kallsyms"):
    a, t, n = l.split()
    sym[n] = int(a, 16)
base = sym.get("_stext", 0); end = sym.get("_etext", 0)
print("kernel text:", hex(base), hex(end))
EOF
```

Handlers outside `[_stext, _etext]` are hooked.

## Memory forensics

Volatility 3 with a Linux profile:

```bash
vol -f mem.raw linux.pslist
vol -f mem.raw linux.check_modules
vol -f mem.raw linux.check_syscall
vol -f mem.raw linux.hidden_modules
vol -f mem.raw linux.malfind
```

## Static module analysis

```bash
modinfo suspect.ko
readelf -S suspect.ko
nm -u suspect.ko | head -30     # imported kernel symbols reveal intent
strings -a suspect.ko | grep -E "hide|root|secret|/proc"
objdump -d suspect.ko | grep -E "call.*kallsyms_lookup_name"
```

A module referencing `kallsyms_lookup_name`, `sys_call_table`, `set_memory_rw` is a hooking rootkit.

## eBPF rootkits

Check loaded BPF programs:

```bash
bpftool prog list
bpftool prog dump xlated id <id>
bpftool map list
```

Suspicious: programs attached to `kprobe` on `vfs_read`/`getdents64` that filter results.

## Pitfalls

- `ps` and `ls /proc` both read the same kernel structures — a DKOM rootkit hides from both. Use `crash` on a memory image or raw `task_struct` walking from `init_task`.
- Hooking via ftrace leaves no `sys_call_table` modification; check `ftrace_enabled` and registered ops.
- Kernel modules can be built into the image (no `.ko`); compare against a known-good kernel.

## Verification

A hidden object must be findable through a path the rootkit does not hook, and that path must not be one the rootkit itself controls.
