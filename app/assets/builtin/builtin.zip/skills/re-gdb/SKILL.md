---
name: re-gdb
description: "GDB reversing and exploitation workflow on Linux: pwndbg/gef, breakpoints, watchpoints, memory inspection, patching, core dumps, and scripted analysis. Use this skill when debugging ELF binaries, analyzing crashes, or developing exploits on Linux."
---

# GDB

## Overview

GDB with pwndbg or gef turns into a reversing and exploitation console. Analogue of x64dbg for ELF.

## Setup

```bash
# pwndbg
git clone https://github.com/pwndbg/pwndbg && cd pwndbg && ./setup.sh
# gef
bash -c "$(curl -fsSL https://gef.blah.cat/sh)"
```

```bash
gdb -q ./target
(gdb) set disassembly-flavor intel
(gdb) set pagination off
(gdb) b *main+42
(gdb) r arg1 arg2
```

## Core commands

| Command | Meaning |
|---|---|
| `b *0x401000` | breakpoint at address |
| `b func` / `b *func+8` | symbolic |
| `watch *(int*)0x404040` | watchpoint |
| `rwatch` / `awatch` | read / access watch |
| `x/20i $pc` | disassemble around pc |
| `x/32gx $rsp` | dump stack |
| `info registers` | registers |
| `vmmap` (pwndbg) | memory map |
| `telescope $rsp 40` | stack with symbols |
| `stack 40` | gef equivalent |
| `heap`, `bins`, `vis_heap_chunks` | heap state |
| `set $eax = 1` | modify register |
| `set *(int*)0x404040 = 5` | modify memory |
| `call (void)puts("x")` | call into the process |
| `generate` (gef) | dump state for restore |

## Reversing flow

```bash
gdb -q ./crackme
(gdb) starti
(gdb) info functions main
(gdb) disassemble main
(gdb) b *main+0x60
(gdb) c
(gdb) x/s $rdi              # first argument of the failing call
(gdb) p $rax
```

## Conditional / command breakpoints

```gdb
b *0x4011a0 if *(int*)$rsp == 42
commands
  silent
  printf "hit eax=%d\n", $eax
  continue
end
```

## Scripting

```python
# gdb -q -x script.py
import gdb
class DumpRet(gdb.Command):
    def __init__(self): super().__init__("dumpret", gdb.COMMAND_USER)
    def invoke(self, arg, tty):
        f = gdb.newest_frame()
        while f: print(f.name(), f.pc()); f = f.older()
DumpRet()
```

```bash
gdb -q -batch -ex 'b *0x401000' -ex 'run' -ex 'info registers' -ex 'x/10i $pc' ./t
```

## Core dumps

```bash
ulimit -c unlimited
./crash
gdb ./crash core
(gdb) bt full
(gdb) info registers
(gdb) x/40gx $rsp
```

## Pitfalls

- Breakpoints inside PIE binaries need `b *main+offset`, not absolute addresses before `starti`.
- `set follow-fork-mode child` is required for forked servers.
- Reading optimized-out variables returns garbage — read registers and stack instead.

## Verification

`bt` plus register state must explain the crash deterministically; replaying the same input reproduces the same `$pc`.
