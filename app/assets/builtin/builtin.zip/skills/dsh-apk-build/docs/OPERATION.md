# DSH APK 云端打包：运作方法

## 思维导图

```mermaid
mindmap
  root((DSH APK 云端打包))
    触发
      "打包 APK" 一句话
      skill: dsh-apk-build
      命令 ~/.dsh/bin/apk
    凭据
      ~/.dsh/keys/github.token
      环境变量 GITHUB_TOKEN 覆盖
      权限只给 repo + workflow
    代码同步
      fork 服务端复制
      Contents API 单文件上传
      push_files.py
    构建
      workflow 必须在 main
      dispatch ref=功能分支
      记录 max_run_id 防串号
      Flutter 3.47.7 + JDK 17
    等待
      每 15s 轮询
      失败自动拉日志 zip
      成功列出 artifact
    下载
      artifact ~150MB
      900s 超时 + 5 次重试
      解压取 *.apk
    校验
      aapt2 badging 包名版本
      apksigner 证书
      sha256
    安装
      debug 签名 ≠ 正式签名
      覆盖装需同 keystore 或先卸载
      卸载会清数据
```

## 流程图

```mermaid
sequenceDiagram
  participant Me as 我
  participant Skill as dsh-apk-build
  participant GH as GitHub API
  participant CI as Actions Runner
  participant Phone as /sdcard/Download

  Me->>Skill: apk --repo yq-ui/dsh-Go --ref root-dev
  Skill->>GH: GET /user（验证 token）
  GH-->>Skill: login + scopes
  Skill->>GH: GET workflow（必须在 main）
  alt 不存在
    Skill->>GH: PUT contents(.github/workflows/build-apk.yml) on main
  end
  Skill->>GH: GET runs?branch=ref（取 max run id）
  Skill->>GH: POST dispatches {ref: root-dev}
  loop 每 15s，最多 45min
    Skill->>GH: GET runs
  end
  GH-->>Skill: run completed
  alt success
    Skill->>GH: GET artifacts
    Skill->>GH: GET archive_download_url（900s）
    Skill->>Phone: 解压并复制 APK
  else failure
    Skill->>GH: GET logs.zip
    Skill-->>Me: /tmp/dsh-build-logs.zip
  end
```

## 目录

```
~/.dsh/
  bin/apk                         # 包装命令：解析 token 后调用 build.py
  keys/github.token               # 600，一行 PAT
  skills/dsh-apk-build/
    SKILL.md                      # 何时用、怎么用
    scripts/build.py              # 触发/等待/下载
    scripts/push_files.py         # 批量上传改动
    scripts/status.py             # 看最近 run
    scripts/verify_apk.sh         # aapt2 + apksigner + sha256
    docs/PITFALLS.md              # 坑位表
    docs/OPERATION.md             # 本文件
```

## 日常操作

### 1. 只改了几个文件

```bash
python3 ~/.dsh/skills/dsh-apk-build/scripts/push_files.py \
  --repo yq-ui/dsh-Go --branch root-dev \
  --base '/storage/emulated/0/MT2/项目源码/dsh-Go-main/app' \
  --path android/app/src/main/kotlin/.../PhoneCore.kt \
  --path lib/phone/android_shell_channel.dart
```

### 2. 打包

```bash
~/.dsh/bin/apk --repo yq-ui/dsh-Go --ref root-dev
```

产物：`/sdcard/Download/dsh-go-debug-arm64.apk`

### 3. 挂到已有构建

```bash
~/.dsh/bin/apk --run 44932868860
```

### 4. 查状态

```bash
python3 ~/.dsh/skills/dsh-apk-build/scripts/status.py
```

### 5. 验包

```bash
~/.dsh/skills/dsh-apk-build/scripts/verify_apk.sh /sdcard/Download/dsh-go-debug-arm64.apk
```

## 失败处理顺序

1. 看 `/tmp/dsh-build-logs.zip` 里的 `*/6_build debug arm64.txt` 尾部
2. Kotlin 错 → 修源码 → `push_files.py` → 再 `apk`
3. 缺文件类 `Unresolved reference` → 本地 `ls` 对照上游目录，补传新增文件
4. `404 dispatch` → 检查 workflow 是否在 `main`
5. 网络类 → 重试；脚本已带退避

## 时间与成本

- 首次构建约 8 分钟（Flutter SDK 下载占大头）
- 之后有缓存约 5–6 分钟
- 公开仓库 Actions 免费额度足够；别空跑

## 安全边界

- token 只存本机 600 文件；不写进仓库、不写进任何提交
- 只给 `repo` + `workflow`，不要 `admin:*` / `delete_repo` / `billing`
- 不要自动化注册 GitHub 账号（DataDome 会拦，也违反 ToS）
- 卸载旧版装 debug 包会清数据，先确认


---

## 第二轮修正（2026-11-22，必读）

### 标准 workflow 只有一份
以 `templates/build-apk.yml` 为准，必须同时包含：

1. `bash runtime/build-runtime.sh arm64-v8a` —— 否则 APK 缺内置运行环境，装好会报「App 内的运行环境包不完整」
2. `DSH_SIDE_BUILD: '1'` —— 包名变 `io.github.ccch1mneyyy.dsh_app.test`，名称「DSH Go 测试」，与正式版并存
3. `--debug --flavor arm64` —— release 需要 companion pack 与正式 keystore，仓库里没有

### 产物形态
- 大小：约 300–310 MB（rootfs 压缩包 ~159 MB + Flutter/依赖）
- artifact 下载：脚本给 1800 s 超时并重试，本机约 8–12 分钟
- 安装：认准「DSH Go 测试」；首次启动解压 rootfs 较慢

### 交付前硬门
`scripts/verify_apk.sh <apk>` 必须全绿：
- `assets/runtime/manifest.json` + `rootfs-arm64-v8a.tar.xz`
- `libproot.so` / `libproot-loader.so` / `libtalloc.so` / `libandroid-shmem.so`
- 包名以 `.test` 结尾
- 打印签名与 sha256

### 预检新增
`preflight.py` 现在还会读默认分支的 workflow 正文：
- 缺 `build-runtime.sh` → **FAIL**
- 缺 `DSH_SIDE_BUILD` → **WARN**
这样新会话在触发前就能发现“又打了一个缺环境的包”。

