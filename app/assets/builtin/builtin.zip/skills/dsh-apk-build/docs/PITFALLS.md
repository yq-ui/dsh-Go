# 这次踩过的坑（2026-11-22，DSH Go 首轮云端打包）

按发生顺序记录，每条都写了「现象 → 根因 → 现在的处理」，脚本已经内置，不用再踩。

## 环境与来源

| # | 现象 | 根因 | 现状 |
|---|---|---|---|
| 1 | 本机没有 Flutter / Gradle / Android SDK，直接 `flutter build` 不存在 | 本机是 PRoot Ubuntu，只有 JDK、aapt2、apksigner；Flutter 未装 | 改走 GitHub Actions，本机只做 API 调度 |
| 2 | 源码快照缺 `app/pubspec.yaml`、`gradlew`、wrapper jar | 共享存储里的工程是**不完整拷贝** | 不再依赖本地源码构建；fork 上游拿完整树 |
| 3 | `git clone` 10 分钟只下 3MB；codeload tar 包 45KB/s | GitHub 大文件直连被限速 | **不下载整仓**：服务端 fork + Contents API 只传改动文件 |
| 4 | `raw.githubusercontent.com` 不通，`gh-proxy.com` 被 Cloudflare 拦 | 网络策略 | 改用 `api.github.com/contents`（可用） |

## GitHub 侧

| # | 现象 | 根因 | 现状 |
|---|---|---|---|
| 5 | `workflow_dispatch` 返回 404 | workflow 只放在 `root-dev` 分支；GitHub **只注册默认分支上的 workflow** | workflow 必须同时放 `main`；dispatch 时 `ref` 指向功能分支 |
| 6 | fork 里 Actions 列表是 0 | fork 默认不启用 Actions | `PUT /actions/permissions {enabled:true}` |
| 7 | 脚本把**上一次失败**的 run 当成新构建 | 先列 run 再取第一个同名 | 触发前记最大 run id，只认 `id > max_id`；支持 `--run` 直接挂 |
| 8 | 自动化注册 GitHub 账号被 DataDome 拦 | GitHub 风控识别无头/自动化浏览器 | **不要尝试自动注册**；账号必须真人在手机 Chrome 完成 |

## 编译

| # | 现象 | 根因 | 现状 |
|---|---|---|---|
| 9 | 首轮 Kotlin 编译 6 个错 | 只推了「本次改过的文件」，漏了 Root 功能依赖的新增/支撑文件 | 推送清单现在包含：`RootShellCommand.kt`、`ShellLink.root()`、`ShellProtocol` root UID、`AndroidShellMain`、Controller import |
| 10 | `public function exposes internal type` | `PhoneAndroidShell.inspectRoot` 参数是 internal 的 `RootDeviceInfoTool.Request` | 函数改 `internal` |
| 11 | `Unresolved reference 'RootDeviceInfoTool'` | `AndroidShellController` 在 `phone.shell` 包，未 import | 补 import |

## 产物

| # | 现象 | 根因 | 现状 |
|---|---|---|---|
| 12 | 下载 artifact 时 DNS 偶发 `Name or service not known` | 网络抖动 | 请求带 5 次退避重试；artifact 用 900s 超时 |
| 13 | debug APK 装不上旧版 | 调试证书与正式签名不同 | 要覆盖安装必须用同一 release keystore 重签，或先卸载旧版（会丢数据） |
| 14 | release 构建需要 companion pack 与签名密钥，仓库里没有 | 授权素材/私钥不进仓库 | 本轮用 `--debug`；release 需本机 `tooling/build-apk.sh` + 密钥 |

## 凭据

| # | 现象 | 根因 | 现状 |
|---|---|---|---|
| 15 | token 被多勾了 `admin:org`、`admin:public_key` 等 | 追求“最大权限” | 只需要 `repo` + `workflow`；权限越大泄露后果越重 |
| 16 | token 明文放在 `/storage/emulated/0/MT2/GitHub打包api` | 方便 | 改放 `~/.dsh/keys/github.token`（600）；共享存储那份建议删 |

## 追加（2026-11-22，第二轮）

| # | 现象 | 根因 | 现状 |
|---|---|---|---|
| 17 | 装好后提示“App 内的运行环境包不完整” | workflow 只跑 `flutter build apk`，没跑 `runtime/build-runtime.sh`，APK 里没有 `assets/runtime/rootfs-*.tar.xz` 与 proot 库 | workflow 先 `bash runtime/build-runtime.sh arm64-v8a`，再编译；产物约 300MB |
| 18 | 想并存安装、不覆盖正式版 | 默认 applicationId 与正式版相同，且 debug 签名不同 | 用工程自带 side build：`DSH_SIDE_BUILD=1` → `io.github.ccch1mneyyy.dsh_app.test`，名称“DSH Go 测试”，数据独立 |
| 19 | 编译体积大、artifact 300MB | 内置 rootfs 压缩包 159MB + 依赖 | 下载超时放宽到 1800s；本机下载约 10 分钟 |


## 追加（2026-11-22，第三轮：Android Shell 只走 root）

| # | 现象 | 根因 | 现状 |
|---|---|---|---|
| 20 | Android Shell 页面每一行都点不动（灰的） | `status()` 里无条件探测 Shizuku：未装/未运行时 binder 调用阻塞数秒，超时后 `supported=false`，所有行 `onTap=null` | 只探测当前 backend（root），Shizuku/ADB 状态返回空表，不再阻塞页面 |
| 21 | 开关打得开，但“连接”没反应 | 前端把“启用 Shell”绑在手机操控 ready（无障碍）上；原生 `configure` 里还有 `control.isEnabled()` 拦截 | 前端 `canEnable=canSetup && phone.loaded`；原生删掉该拦截；Shell 与无障碍互相独立 |
| 22 | 用户要求“默认全开”，装完还是关的 | `enabled` 默认 false，且从未写过 prefs | 控制器 init 里做一次性迁移：`rootDefaultOnApplied` 标记 + 写 `enabled=true/backend=root` + 后台线程自动 `connect()` |
| 23 | root 探测要卡好几分钟 | 候选 su 路径逐个 120s 超时，8 个候选最坏 16 分钟 | 单候选 20s、整体 90s 上限；失败把 stderr 尾巴（2KB）回传，页面显示“最近一次失败” |
| 24 | 页面还有 Shizuku/ADB 卡片和“配对码”报错 | 只改后端，没清 UI 文案与死代码；`invalidArguments` 还挂着 ADB 文案 | 后端列表只剩 Root；删除 Shizuku/ADB 卡片、配对弹窗类与映射；`invalidArguments` 改成通用文案 |
| 25 | 清理死代码后编译失败 | 删了 `_selectBackend` 方法却留着调用点；删了 import 但组件还在用 | 先 `grep` 每个符号的引用，再删；后端行改成静态展示行，不再有 onTap |
| 26 | 真机 root 弹窗只弹一次，之后没反应 | 自动连接只在进程启动跑一次；用户当时点了拒绝 | 页面始终保留“连接 Root Shell”行，随时可手动重连（连不上会显示 su 路径/失败原因） |

**验证顺序（缺一不可）**
1. `grep -n -i -E 'shizuku|adb|pairing'` 页面文件应为空。
2. 上传后先比对远端 sha 与本地 blob sha，确认只有预期文件变化。
3. 构建产物必须过 `scripts/verify_apk.sh`（包名 .test / runtime manifest / rootfs / 4 个 proot .so / 签名 / sha256）再发路径。

