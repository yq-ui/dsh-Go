---
name: dsh-apk-build
description: 用 GitHub Actions 云端打包 DSH Go APK：推改动到 fork、触发 workflow、等待、下载到 /sdcard/Download、验包（运行环境/包名/签名）。用户说「打包 APK」「云端构建」「推上去打」「重新打包」时使用。token 在 ~/.dsh/keys/github.token。
---

# DSH APK 云端打包

本机没有 Flutter/Gradle，APK 由 GitHub Actions 编译；本机只负责推代码、触发、下载、验包。
**动手前先读** `docs/PITFALLS.md`（19 个坑）、`docs/OPERATION.md`（图与手册）、`templates/build-apk.yml`（标准 workflow）。

## 一条命令

```bash
~/.dsh/bin/apk --repo yq-ui/dsh-Go --ref root-dev --name dsh-go-side-debug-arm64.apk
# 产物：/sdcard/Download/dsh-go-side-debug-arm64.apk
```

## 标准流程（顺序不能省）

1. **预检** `scripts/preflight.py`
   token、scope、fork、Actions、workflow 是否在默认分支，**以及 workflow 是否包含 runtime 与 side 开关**。
2. **推改动** `push_files.py` —— 新增/支撑文件必须一起传。
3. **构建** `build.py` —— workflow 必须先 `runtime/build-runtime.sh arm64-v8a`，再 `DSH_SIDE_BUILD=1 flutter build apk --debug`。
4. **验包（硬门）** `scripts/verify_apk.sh <apk>` —— 缺 runtime / 包名不是 `.test` / 签名不对，直接判失败，不许交付。
5. **交付话术** 说明 debug 签名、并存安装、首次解压 159MB rootfs 较慢。

## 硬规则（每一条都是踩出来的）

1. **不跑 `runtime/build-runtime.sh` 就打包 = 废包**：装上去能开，一装本机引擎就报「App 内的运行环境包不完整」。APK 必须含 `assets/runtime/manifest.json`、`rootfs-arm64-v8a.tar.xz` 和 4 个 proot 相关 `.so`。
2. **要并存安装就设 `DSH_SIDE_BUILD=1`**：包名变 `…dsh_app.test`、名称「DSH Go 测试」、数据独立；否则会和正式版撞包名，debug 签名又覆盖不了，只能卸载（丢数据）。
3. workflow 只认**默认分支**；只放功能分支会 404 dispatch。
4. 触发后只认 `id > max_run_id` 的新 run，否则读到上次失败结果。
5. fork 可能默认禁用 Actions；`PUT /actions/permissions` 打开。
6. 只推改动文件时，**新增/支撑文件一起传**，否则 `Unresolved reference`。
7. `RootDeviceInfoTool` 是 internal，公开函数不能暴露；跨包要 import。
8. artifact **约 300MB**：读超时 ≥900s（下载脚本给 1800s），网络错误要退避重试。
9. 不自动注册 GitHub 账号（DataDome）；token 不进仓库、不放共享存储。
10. release 需要 companion pack + 正式 keystore，仓库没有；要 release 只能本机 `tooling/build-apk.sh`。
11. **改后端必须先清 UI 死代码**：只改 Kotlin、留着 Shizuku/ADB 卡片与配对码文案，用户会以为没修好。删之前 `grep` 每个符号的调用点，先删调用再删定义。
12. **改"开关"类功能先查三处**：prefs 默认值、原生拦截（如 `control.isEnabled()`）、前端 `canXxx` 门禁。只改一处，用户看到的还是"点不动"。
13. **`status()` 只读缓存，不许做阻塞探测**：探 Shizuku/binder 会让整个页面灰掉；真正的耗时动作放显式连接里，并给单项/整体双超时。
14. 上传后先比对**远端 blob sha** 与本地，确认只有预期文件变化，再触发构建——省掉一次废构建。

## 失败时

1. `build.py` 失败落 `/tmp/dsh-build-logs.zip`
2. 看 `*/6_build debug arm64.txt` 或 runtime 步骤日志
3. 修 → push → 重跑；同类错误第二次出现，说明漏传文件或 workflow 少了步骤
