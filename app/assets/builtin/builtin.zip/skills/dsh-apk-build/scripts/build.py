#!/usr/bin/env python3
"""Dispatch (or attach to) the DSH Go APK workflow, then download the artifact.

Pitfalls this script already handles:
  * fork workflows are only registered from the DEFAULT branch -> dispatch would 404
  * listing runs can match an older failed run -> we only accept id > max_id, or --run
  * api.github.com / objects.githubusercontent.com DNS blips -> retries with backoff
  * the artifact is ~150 MB -> long read timeout, not the 60 s API timeout
"""
import argparse, json, os, shutil, subprocess, sys, tempfile, time, urllib.request, urllib.error, urllib.parse, zipfile

API = "https://api.github.com"
KEY = os.path.expanduser("~/.dsh/keys/github.token")

def token():
    t = os.environ.get("GITHUB_TOKEN", "").strip()
    if not t and os.path.exists(KEY):
        t = open(KEY).read().strip()
    if not t:
        sys.exit("no token: one line in %s (repo + workflow)" % KEY)
    return t

class Gh:
    def __init__(self): self.t = token()

    def req(self, method, path, data=None, raw=False, timeout=60, attempts=5):
        last = None
        for i in range(attempts):
            r = urllib.request.Request(API + path, method=method, headers={
                "Authorization": "Bearer " + self.t,
                "Accept": "application/vnd.github+json",
                "User-Agent": "dsh-apk-build"})
            body = json.dumps(data).encode() if data is not None else None
            try:
                with urllib.request.urlopen(r, body, timeout=timeout) as f:
                    b = f.read()
                    return f.status, (b if raw else json.loads(b.decode() or "{}"))
            except urllib.error.HTTPError as e:
                b = e.read()
                try: p = json.loads(b.decode() or "{}")
                except Exception: p = {"raw": b[:300].decode("utf-8", "replace")}
                return e.code, p
            except (urllib.error.URLError, TimeoutError, OSError) as e:
                last = e
                time.sleep(5 * (i + 1))
        sys.exit("network failed after %d attempts: %s" % (attempts, last))

def runs_of(g, repo, ref):
    st, d = g.req("GET", "/repos/%s/actions/runs?per_page=20&branch=%s" % (repo, urllib.parse.quote(ref)))
    return d.get("workflow_runs", []) if st == 200 else []

def wait_run(g, repo, ref, workflow, run_id=None, max_id=0, timeout=2700):
    deadline = time.time() + timeout
    run = None
    while time.time() < deadline:
        for r in runs_of(g, repo, ref):
            match = r.get("path", "").endswith(workflow) or r.get("name") == "Build debug APK"
            if not match: continue
            if run_id and r["id"] == run_id: run = r; break
            if not run_id and r["id"] > max_id: run = r; break
        if run and run["status"] == "completed": return run
        time.sleep(15)
    return run

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default="yq-ui/dsh-Go")
    ap.add_argument("--workflow", default="build-apk.yml")
    ap.add_argument("--ref", default="root-dev")
    ap.add_argument("--out", default="/sdcard/Download")
    ap.add_argument("--name", default="dsh-go-debug-arm64.apk")
    ap.add_argument("--timeout", type=int, default=2700)
    ap.add_argument("--run", type=int, default=0, help="attach to an existing run id")
    ap.add_argument("--no-runtime", action="store_true", help="UI-only build: skip the 159MB bundled runtime (APK ~150MB, local engine won't start)")
    a = ap.parse_args()
    g = Gh()
    st, me = g.req("GET", "/user")
    if st != 200: sys.exit("token rejected: %s" % me)
    print("github user: %s" % me.get("login"))
    if a.run:
        run = wait_run(g, a.repo, a.ref, a.workflow, run_id=a.run, timeout=a.timeout)
    else:
        st, wf = g.req("GET", "/repos/%s/actions/workflows/%s" % (a.repo, a.workflow))
        if st != 200:
            sys.exit("workflow %s not found (must exist on the DEFAULT branch): %s" % (a.workflow, wf.get("message")))
        max_id = max([r["id"] for r in runs_of(g, a.repo, a.ref)] or [0])
        payload = {"ref": a.ref}
        if a.no_runtime: payload["inputs"] = {"runtime": "false"}
        st, res = g.req("POST", "/repos/%s/actions/workflows/%s/dispatches" % (a.repo, a.workflow), payload)
        if st not in (200, 201, 204): sys.exit("dispatch failed: %s %s" % (st, res))
        print("dispatched %s on %s (previous max run %s)" % (a.workflow, a.ref, max_id))
        run = wait_run(g, a.repo, a.ref, a.workflow, max_id=max_id, timeout=a.timeout)
    if not run: sys.exit("timed out waiting for the run")
    print("run %s: %s" % (run["id"], run.get("conclusion")))
    if run.get("conclusion") != "success":
        st, logs = g.req("GET", "/repos/%s/actions/runs/%s/logs" % (a.repo, run["id"]), raw=True)
        if st == 200:
            open("/tmp/dsh-build-logs.zip","wb").write(logs)
            print("logs: /tmp/dsh-build-logs.zip")
        sys.exit("build failed (%s)" % run.get("conclusion"))
    st, arts = g.req("GET", "/repos/%s/actions/runs/%s/artifacts" % (a.repo, run["id"]))
    if not arts.get("artifacts"): sys.exit("no artifacts")
    art = arts["artifacts"][0]
    print("artifact: %s (%.1f MB)" % (art["name"], art["size_in_bytes"] / 1048576))
    zip_path = "/tmp/dsh-apk-artifact.zip"
    try:
        st, blob = g.req("GET", art["archive_download_url"], raw=True, timeout=900)
        if st != 200: raise RuntimeError("HTTP %s" % st)
        open(zip_path, "wb").write(blob)
    except (SystemExit, Exception, RuntimeError) as error:
        # DNS flakiness on objects.githubusercontent.com is common; curl retries better.
        print("urllib failed (%s); falling back to curl" % error)
        rc = subprocess.run(["curl", "-sSL", "--retry", "8", "--retry-delay", "5",
                             "-m", "1800", "-H", "Authorization: Bearer " + g.t,
                             art["archive_download_url"], "-o", zip_path]).returncode
        if rc != 0 or not os.path.getsize(zip_path): sys.exit("artifact download failed")
    tmp = tempfile.mkdtemp()
    with zipfile.ZipFile("/tmp/dsh-apk-artifact.zip") as zf: zf.extractall(tmp)
    apks = [os.path.join(r, f) for r, _, fs in os.walk(tmp) for f in fs if f.endswith(".apk")]
    if not apks: sys.exit("no apk in artifact")
    os.makedirs(a.out, exist_ok=True)
    dst = os.path.join(a.out, a.name)
    shutil.copy2(apks[0], dst)
    print("APK: %s (%d bytes)" % (dst, os.path.getsize(dst)))

if __name__ == "__main__":
    main()