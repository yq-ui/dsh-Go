#!/usr/bin/env python3
"""Upload local files to a fork branch (path relative to --base, repo path app/<rel>)."""
import argparse, base64, json, os, sys, urllib.request, urllib.error, urllib.parse

API = "https://api.github.com"
KEY = os.path.expanduser("~/.dsh/keys/github.token")

def token():
    t = os.environ.get("GITHUB_TOKEN", "").strip() or (open(KEY).read().strip() if os.path.exists(KEY) else "")
    if not t: sys.exit("no token in %s" % KEY)
    return t

def req(t, method, path, data=None):
    r = urllib.request.Request(API + path, method=method, headers={
        "Authorization": "Bearer " + t, "Accept": "application/vnd.github+json",
        "User-Agent": "dsh-apk-build"})
    body = json.dumps(data).encode() if data is not None else None
    try:
        with urllib.request.urlopen(r, body, timeout=60) as f:
            return f.status, json.loads(f.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default="yq-ui/dsh-Go")
    ap.add_argument("--branch", default="root-dev")
    ap.add_argument("--base", required=True, help="local root, e.g. .../dsh-Go-main/app")
    ap.add_argument("--path", action="append", required=True, help="path relative to --base")
    ap.add_argument("--prefix", default="app/")
    ap.add_argument("--message", default="sync local changes")
    a = ap.parse_args()
    t = token()
    for rel in a.path:
        src = os.path.join(a.base, rel)
        if not os.path.isfile(src): sys.exit("missing %s" % src)
        repo_path = a.prefix + rel
        st, cur = req(t, "GET", "/repos/%s/contents/%s?ref=%s" % (a.repo, urllib.parse.quote(repo_path), a.branch))
        data = {"message": a.message, "branch": a.branch,
                "content": base64.b64encode(open(src, "rb").read()).decode()}
        if st == 200: data["sha"] = cur["sha"]
        st, res = req(t, "PUT", "/repos/%s/contents/%s" % (a.repo, urllib.parse.quote(repo_path)), data)
        print(("OK  " if st in (200, 201) else "FAIL"), st, repo_path, res.get("message", ""))

if __name__ == "__main__":
    main()
