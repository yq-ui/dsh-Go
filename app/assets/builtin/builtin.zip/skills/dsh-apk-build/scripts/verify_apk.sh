#!/usr/bin/env bash
# Gate before handing an APK to the person: package, runtime bundle, signature.
set -euo pipefail
A="${1:?usage: verify_apk.sh <apk>}"
[ -f "$A" ] || { echo "FAIL no such file: $A" >&2; exit 1; }
fail=0
LIST=$(mktemp)
unzip -l "$A" > "$LIST"
badge=$(aapt2 dump badging "$A" 2>/dev/null | head -1)
pkg=$(printf '%s' "$badge" | grep -o "name='[^']*'" | head -1 | cut -d"'" -f2)
ver=$(printf '%s' "$badge" | grep -o "versionName='[^']*'" | head -1 | cut -d"'" -f2)
ls -lh "$A"
echo "package: $pkg   version: $ver"
aapt2 dump badging "$A" 2>/dev/null | grep -E "sdkVersion|targetSdkVersion" || true

if grep -q 'assets/runtime/manifest.json' "$LIST"; then
  echo "OK   runtime manifest present"
else
  echo "FAIL runtime manifest missing -> app would show 运行环境包不完整"; fail=1
fi
if grep -q 'assets/runtime/rootfs-' "$LIST"; then echo "OK   rootfs archive present"; else echo "FAIL rootfs archive missing"; fail=1; fi
for so in libproot libproot-loader libtalloc libandroid-shmem; do
  if grep -q "lib/arm64-v8a/$so.so" "$LIST"; then echo "OK   $so.so"; else echo "FAIL missing $so.so"; fail=1; fi
done

case "$pkg" in
  *.test) echo "OK   side package (.test) installs next to the release app" ;;
  *) echo "WARN package has no .test suffix: use DSH_SIDE_BUILD=1 for a side build" ;;
esac

echo "--- signature"
apksigner verify --print-certs "$A" | head -2
if apksigner verify --print-certs "$A" | grep -q 'CN=Android Debug'; then
  echo "WARN debug certificate: cannot upgrade an existing release install; uninstall first (data loss)"
fi
echo "--- sha256"
sha256sum "$A"
rm -f "$LIST"
exit "$fail"
