#!/usr/bin/env python3
"""Show the latest workflow runs on the fork."""
import json, os, sys, urllib.request, urllib.error
API="https://api.github.com"
KEY=os.path.expanduser("~/.dsh/keys/github.token")
t=os.environ.get("GITHUB_TOKEN","").strip() or (open(KEY).read().strip() if os.path.exists(KEY) else "")
if not t: sys.exit("no token in %s" % KEY)
repo=sys.argv[1] if len(sys.argv)>1 else "yq-ui/dsh-Go"
r=urllib.request.Request(API+"/repos/%s/actions/runs?per_page=8"%repo,headers={"Authorization":"Bearer "+t,"Accept":"application/vnd.github+json","User-Agent":"dsh-apk-build"})
try:
    with urllib.request.urlopen(r,timeout=30) as f: d=json.load(f)
except urllib.error.HTTPError as e:
    sys.exit("HTTP %s: %s"%(e.code,e.read()[:200]))
for x in d.get("workflow_runs",[]):
    print(x["id"], x["name"], x["head_branch"], x["status"], x.get("conclusion"))
