#!/usr/bin/env python3
"""Preflight: token, fork, Actions, workflow-on-default-branch. Fix hints included."""
import json, os, sys, urllib.request, urllib.error
API = "https://api.github.com"
KEY = os.path.expanduser("~/.dsh/keys/github.token")
REPO = sys.argv[1] if len(sys.argv) > 1 else "yq-ui/dsh-Go"
WF = sys.argv[2] if len(sys.argv) > 2 else "build-apk.yml"

t = os.environ.get("GITHUB_TOKEN", "").strip() or (open(KEY).read().strip() if os.path.exists(KEY) else "")
if not t:
    sys.exit("FAIL token: %s missing" % KEY)

def req(path):
    r = urllib.request.Request(API + path, headers={
        "Authorization": "Bearer " + t, "Accept": "application/vnd.github+json",
        "User-Agent": "dsh-apk-build"})
    try:
        with urllib.request.urlopen(r, timeout=30) as f:
            return f.status, dict(f.headers), json.loads(f.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), json.loads(e.read().decode() or "{}")

st, h, me = req("/user")
if st != 200: sys.exit("FAIL token: %s" % me)
h = {k.lower(): v for k, v in h.items()}
print("OK   token user=%s" % me["login"])
scopes = h.get("x-oauth-scopes", "")
print("     scopes=%s" % scopes)
if "repo" not in scopes or "workflow" not in scopes:
    print("WARN need repo + workflow scopes for push/dispatch")

st, _, repo = req("/repos/" + REPO)
if st != 200: sys.exit("FAIL fork %s: %s (create it: POST /repos/<upstream>/forks)" % (REPO, repo.get("message")))
print("OK   repo=%s default_branch=%s fork=%s" % (repo["full_name"], repo["default_branch"], repo.get("fork")))

st, _, perm = req("/repos/%s/actions/permissions" % REPO)
print(("OK   " if perm.get("enabled") else "WARN ") + "actions enabled=%s" % perm.get("enabled"))
if not perm.get("enabled"):
    print("     fix: PUT /actions/permissions {enabled:true,allowed_actions:all}")

st, _, wf = req("/repos/%s/actions/workflows/%s" % (REPO, WF))
if st != 200:
    print("FAIL workflow %s not registered: %s" % (WF, wf.get("message")))
    print("     hint: the file must exist on the DEFAULT branch (%s), not only on the feature branch" % repo["default_branch"])
else:
    print("OK   workflow %s state=%s" % (wf.get("path"), wf.get("state")))
    st2, _, body = req("/repos/%s/contents/.github/workflows/%s?ref=%s" % (REPO, WF, repo["default_branch"]))
    if st2 == 200:
        import base64
        text = base64.b64decode(body.get("content", "")).decode("utf-8", "replace")
        if "build-runtime.sh" in text:
            print("OK   workflow builds the bundled runtime")
        else:
            print("FAIL workflow skips runtime/build-runtime.sh -> APK will say 运行环境包不完整")
        if "DSH_SIDE_BUILD" in text:
            print("OK   workflow builds a .test side package")
        else:
            print("WARN workflow lacks DSH_SIDE_BUILD=1 -> package collides with the release app")
    else:
        print("WARN cannot read workflow body: %s" % st2)

st, _, runs = req("/repos/%s/actions/runs?per_page=3" % REPO)
for r in runs.get("workflow_runs", []):
    print("     run %s %s %s %s" % (r["id"], r["name"], r["status"], r.get("conclusion")))
