---
name: re-arm
description: "ARM and ARM64 reversing: instruction sets, Thumb/Thumb-2, calling conventions, NEON, and common compiler idioms. Use this skill when analyzing ARM firmware or mobile binaries."
---

# ARM / ARM64 Reversing

## Overview

Two very different ISAs: AArch64 (ARM64) fixed 4-byte instructions, 31 GPRs; AArch32 with ARM (4-byte) and Thumb/Thumb-2 (2/4-byte mixed). Getting the mode wrong produces total garbage.

## Mode detection

```bash
readelf -h fw.elf | grep Flags
file fw.bin
# ARM32: Flags: 0x5000400, Version5 EABI  -> check bit 0x20 for Thumb entry
```

If the entry address is odd in an ARM ELF, subtract 1 and switch to Thumb.

## AArch64 essentials

| Instruction | Meaning |
|---|---|
| `stp x29, x30, [sp, #-0x20]!` | prologue, save frame + LR |
| `ldp x29, x30, [sp], #0x20` | epilogue |
| `adrp x8, page` + `add x8, x8, #off` | address of a global |
| `cbz` / `cbnz` | compare and branch on zero |
| `tbz` / `tbnz` | test bit and branch |
| `csel` | conditional select (branchless) |
| `ldr w0, [x1, x2, lsl #2]` | array index |
| `bl` / `blr` | call / indirect call |
| `ret` | return |

Calling convention: `x0-x7` args, `x0` return, `x8` indirect result, `x9-x15` scratch, `x19-x28` callee-saved, `x29` frame pointer, `x30` link register, `sp` 16-byte aligned.

## AArch32 / Thumb-2

| Instruction | Meaning |
|---|---|
| `push {r4-r7, lr}` | prologue |
| `pop {r4-r7, pc}` | epilogue + return |
| `ldr r0, [pc, #imm]` | literal pool load (constant) |
| `add r0, pc` | PC-relative address |
| `movs` / `mov.w` | 16-bit vs 32-bit encoding |
| `blx r3` | call with mode switch |

AAPCS: `r0-r3` args, `r0` return, `r4-r11` callee-saved, `r12` scratch, `r13` SP, `r14` LR, `r15` PC.

## NEON / SIMD

```asm
ld1 {v0.16b}, [x0]        ; load 16 bytes
eor v1.16b, v0.16b, v2.16b ; byte-wise XOR (crypto or obfuscation)
aese v0.16b, v1.16b        ; AES round
sha256h q0, q1, v2.4s      ; SHA-256
```

A `eor` over 16 bytes in a loop that walks a buffer = XOR cipher. Find the key material loaded just before.

## Compiler idioms

- `mov w0, #0` before return = return false/0.
- `cmp` + `b.eq` = equality check.
- `adrp` + `ldr` = accessing a global/string.
- Switch: jump table via `adrp` + `ldrsw` + `br`.

## Pitfalls

- Mixed ARM/Thumb in one binary: mode switches via `bx`/`blx` with bit 0 set.
- Literal pools are data inside `.text`; disassembling them yields nonsense — mark as data.
- ARM64 `ldr` with pre/post-index changes the base register — read the `!`.

## Verification

The reconstructed function must balance the stack (`push`/`pop` sizes equal) and end in `ret`/`pop {pc}`.
