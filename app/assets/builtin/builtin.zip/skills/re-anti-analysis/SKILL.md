---
name: re-anti-analysis
description: "Defeating anti-analysis: anti-debug, anti-VM, anti-sandbox, timing checks, environment fingerprinting, and anti-disassembly techniques, plus safe observation strategies. Use this skill when a sample detects analysis and changes or refuses behavior, and you need a clean observation environment."
---

# Anti-Analysis

## Overview

Anti-analysis splits into two goals: detect the analyst (anti-debug, anti-VM, anti-sandbox) and corrupt the analysis (anti-disassembly, anti-dump). Handle both, or the sample shows you decoy behavior.

## Anti-debug checklist

Windows:

- `IsDebuggerPresent`, `CheckRemoteDebuggerPresent`
- `NtQueryInformationProcess` → `ProcessDebugPort(7)`, `ProcessDebugObjectHandle(30)`, `ProcessDebugFlags(31)`
- `NtSetInformationThread` → `ThreadHideFromDebugger(17)`
- PEB `BeingDebugged`, `NtGlobalFlag` (`0x70` set), heap flags (`ForceFlags`)
- `CloseHandle(INVALID_HANDLE_VALUE)` under a debugger raises
- `int 3` / `int 2d` / `icebp` exception tricks
- `rdtsc`, `QueryPerformanceCounter`, `GetTickCount` deltas
- `NtQueryObject` handle-count enumeration (debug object)
- thread-count checks, `CreateProcess` with `DEBUG_ONLY_THIS_PROCESS`

Linux:

- `ptrace(PTRACE_TRACEME)` failure
- `/proc/self/status` → `TracerPid`
- `prctl(PR_SET_DUMPABLE)`
- timing via `clock_gettime`
- `LD_PRELOAD` and `LD_AUDIT` environment checks

## Anti-VM / sandbox

| Check | Indicator |
|---|---|
| CPUID leaf 1, ECX bit 31 | hypervisor present |
| `cpuid` leaf `0x40000000` | hypervisor vendor string |
| Registry `HKLM\HARDWARE\DESCRIPTION\System\BIOS` | VMware/VirtualBox strings |
| Disk/BIOS serials | known VBox/VMware values |
| MAC prefix | `00:0C:29`, `00:50:56` (VMware), `08:00:27` (VBox) |
| Uptime, RAM size, CPU count | sandboxes are small and freshly booted |
| Process/module list | `VBoxService`, `vmware.exe`, `wireshark`, `procexp` |
| User interaction | no mouse movement, no cursor changes |
| Username/hostname | `sandbox`, `mal`, `cuckoo`, `MALTEST` |
| Recent files, browser history | empty profile |
| Sleep skipping | sleep returns instantly |

## Instrumentation strategy

- **Patch + log** rather than patch + ignore: replace the check's result with "clean" and continue so behavior unfolds.
- **Frida script** to neutralize many checks at once:

```javascript
const clean = () => 0;
["IsDebuggerPresent","CheckRemoteDebuggerPresent"].forEach(n => {
  const p = Module.findExportByName(null, n);
  if (p) Interceptor.replace(p, new NativeCallback(clean, "int", ["pointer","pointer"]));
});
Interceptor.attach(Module.getExportByName("kernel32.dll","GetTickCount64"), {
  onLeave(r) { r.replace(0x7ff000); }
});
```

- **Unicorn/Qiling** for CPU-only decryption logic: no OS checks exist, so nothing to detect.
- **Time spoofing** in the VM: freeze the guest clock or set `rdtsc` offset.

## Anti-disassembly

- Junk bytes after a jump; overlapping instructions
- `jmp` into the middle of an instruction
- `call $+5; pop reg` to get EIP
- Opaque predicates producing unreachable-looking code paths
- Section with `IMAGE_SCN_MEM_EXECUTE` but no code during static analysis

Fix in IDA by forcing the correct instruction at each site (`D` for data, `C` for code) and deleting the false flow.

## Pitfalls

- Patching one check often trips a second (checksum on text, or a second timing probe).
- Hiding from a sandbox can make the sample inert — always confirm with a "believed clean" run.
- `ScyllaHide` profiles that hide too much break the sample's own anti-tamper detection.

## Verification

The sample's behavior under the cleaned environment must match its behavior on bare metal, confirmed by comparing network and file artifacts.
