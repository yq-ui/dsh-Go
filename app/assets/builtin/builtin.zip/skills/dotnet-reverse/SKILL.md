---
name: dotnet-reverse
description: "Advanced .NET reversing: IL analysis, metadata table manipulation, runtime detours, and analyzing protected or packed .NET executables. Use this skill when dnSpy-level decompilation is not enough and you need to work at the IL or metadata layer."
---

# .NET IL Reversal

## Overview

When the C# view lies or is obfuscated beyond recognition, drop to IL. `ildasm`, `dnlib`, and `Mono.Cecil` let you read and rewrite assemblies programmatically.

## IL basics

```il
.method private hidebysig static bool Check(string s) cil managed
{
  .maxstack 2
  IL_0000: ldarg.0
  IL_0001: callvirt instance int32 [mscorlib]System.String::get_Length()
  IL_0006: ldc.i4.s 16
  IL_0008: ceq
  IL_000a: ret
}
```

| Op | Meaning |
|---|---|
| `ldarg.n` / `ldloc.n` | push argument / local |
| `stloc.n` | pop into local |
| `call` / `callvirt` | invoke |
| `brtrue` / `brfalse` | conditional branch |
| `ceq` / `cgt` / `clt` | compare |
| `newobj` | construct |
| `ldstr` | literal string |
| `ldsfld` / `stfld` | static / instance field |

```bash
ildasm /out=app.il app.exe
ilasm /dll app.il
```

## dnlib scripting (C#)

```csharp
using dnlib.DotNet;
using dnlib.DotNet.Emit;

var mod = ModuleDefMD.Load("app.exe");
foreach (var t in mod.GetTypes())
    foreach (var m in t.Methods)
    {
        if (!m.HasBody) continue;
        foreach (var ins in m.Body.Instructions)
            if (ins.OpCode == OpCodes.Ldstr)
                Console.WriteLine($"{t.FullName}::{m.Name} -> {ins.Operand}");
    }
mod.Write("out.exe");
```

Patch a method to return true:

```csharp
var m = mod.Find("App.License", "IsValid", MethodSig.CreateStatic(mod.CorLibTypes.Boolean));
m.Body.Instructions.Clear();
m.Body.Instructions.Add(OpCodes.Ldc_I4_1.ToInstruction());
m.Body.Instructions.Add(OpCodes.Ret.ToInstruction());
m.Body.OptimizeMacros();
mod.Write("patched.exe");
```

## Mono.Cecil (cross-platform)

```csharp
var asm = AssemblyDefinition.ReadAssembly("app.exe");
var t = asm.MainModule.GetType("App.License");
var m = t.Methods.First(x => x.Name == "IsValid");
m.Body = new MethodBody(m) { Instructions = { Instruction.Create(OpCodes.Ldc_I4_1), Instruction.Create(OpCodes.Ret) } };
asm.Write("patched.exe");
```

## Metadata table surgery

Obfuscators corrupt the `#Strings` heap with invalid UTF-8 offsets so dumpers crash. Fix with `dnlib`:

```csharp
mod.StringsStream.Strings = ...   // rebuild the heap
```

Or set `<UseNewStringsStream>` equivalent by writing the module once through dnlib, which normalizes heaps.

## Runtime detours

- **Harmony** for method patching in-process.
- **MonoMod.RuntimeDetour** for lower-level detours.
- **CLR profiling API** for call tracing without code changes.

```csharp
var d = new NativeDetour(
    AccessTools.Method(typeof(Target), "Check").MethodHandle.GetFunctionPointer(),
    AccessTools.Method(typeof(Hook), "Fake").MethodHandle.GetFunctionPointer());
```

## Packed .NET

- Native packers (Themida .NET) → treat as native, unpack first.
- ConfuserEx `ctrl flow` → `de4dot --cflow`.
- ConfuserEx `constants` → strings encrypted; dump at runtime after the module is loaded and decrypted.

```csharp
// dump the decrypted module in memory
var asm = Assembly.GetExecutingAssembly();
var bytes = File.ReadAllBytes(asm.Location);   // if location is the original
// else: use ModuleMemoryDumper via reflection
```

## Pitfalls

- `ilasm` round-trip loses custom attributes unless exported with them.
- `dnlib` writes with a new MVID — signature validation that hashes the assembly fails.
- Strong-name verification must be skipped (`sn -Vr *`) or the name removed.

## Verification

`peverify`/`ilverify` passes on the rewritten assembly and the patched behavior reproduces at runtime.
