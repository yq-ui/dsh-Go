---
name: libfuzzer
description: "Fuzzing with libFuzzer: writing an in-process harness, building with sanitizers, and triaging findings. Use this skill when the target is a library or has a source build."
---

# libFuzzer

## Overview

libFuzzer is in-process and coverage-guided: `LLVMFuzzerTestOneInput(data, size)` is called repeatedly. Fast and simple when a harness is possible.

## Harness

```c
#include <stdint.h>
#include <stddef.h>

int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    if (size < 4) return 0;
    parse_buffer(data, size);   // your target
    return 0;
}
```

## Build

```bash
clang -g -O1 -fsanitize=fuzzer,address -o fuzz fuzz.c parser.c
./fuzz -max_len=4096 corpus/
```

For C++:

```bash
clang++ -g -O1 -fsanitize=fuzzer,address -o fuzz harness.cc lib.cc
```

## Structure-aware

```c
extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    FuzzedDataProvider p(data, size);
    auto mode = p.ConsumeIntegralInRange<int>(0, 3);
    auto payload = p.ConsumeRemainingBytesAsString();
    dispatch(mode, payload);
    return 0;
}
```

`FuzzedDataProvider` (from `-fsanitize=fuzzer`) maps bytes to typed fields.

## Custom mutator

```cpp
extern "C" size_t LLVMFuzzerCustomMutator(uint8_t *D, size_t S, size_t Max, unsigned Seed) {
    // keep the header intact, mutate the payload
    return S;
}
```

## Corpus

```bash
mkdir corpus
cp seeds/* corpus/
./fuzz corpus/ -jobs=8 -workers=8
```

libFuzzer minimizes the corpus automatically; `-merge=1` merges directories.

## Triage

```bash
./fuzz crash-<hash>
# with ASAN it prints the full stack and the failing address
```

```bash
# dedupe by stack
./fuzz -merge=1 corpus crashes/
```

## Pitfalls

- A harness that never reaches the parser fuzzes nothing — assert coverage with `-print_coverage=1`.
- Global state across iterations causes false positives; reset it.
- Without ASAN, overflows read past the buffer silently.

## Verification

A crash reproduces with the same stack trace when running the reproducer file directly.
