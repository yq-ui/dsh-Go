---
name: rev-idapython
description: "IDAPython scripting for automated reverse engineering: batch renaming, xref walking, pattern search, struct creation, emulation inside IDA, and exporting analysis. Use this skill when automating IDA tasks, writing plugins, or extracting data from a large IDA database."
---

# IDAPython

## Overview

IDAPython drives the same API the UI uses. Automate the repetitive parts: renaming by signature, dumping xrefs, decrypting strings, exporting call graphs.

## Environment

```python
import idaapi, idc, idautils, ida_bytes, ida_funcs, ida_name, ida_typeinf
print(idaapi.get_kernel_version())   # e.g. '9.0'
```

Run ad hoc with `Shift+F2` (snippet) or the console at the bottom. For persistent tools, drop a `.py` into `%APPDATA%\Hex-Rays\IDA Pro\plugins`.

## Core recipes

**Iterate functions and xrefs**

```python
for ea in idautils.Functions():
    name = ida_funcs.get_func_name(ea)
    for xref in idautils.XrefsTo(ea, 0):
        print(hex(xref.frm), name)
```

**Bytes / dwords / strings**

```python
b = ida_bytes.get_bytes(ea, 16)
d = ida_bytes.get_dword(ea)
s = ida_bytes.get_strlit_contents(ea, -1, ida_nalt.STRTYPE_C)
```

**Search patterns**

```python
pat = "48 8B ?? 89 ?? ?? 48 85 C0"
hits = ida_bytes.bin_search(0, ida_nalt.get_imagebase() + 0x100000,
                            bytes.fromhex(pat.replace("??", "00")), None,
                            ida_bytes.BIN_SEARCH_NOCASE | ida_bytes.BIN_SEARCH_FORWARD)
```

For real wildcard search use `ida_search.find_binary` or a regex over bytes from `ida_bytes.get_bytes`.

**Rename by signature**

```python
SIGS = {0xDEADBEEF: "crc_table_init"}
for ea in idautils.Functions():
    f = ida_funcs.get_func(ea)
    for h in idautils.Heads(f.start_ea, f.end_ea):
        if ida_bytes.get_dword(h) in SIGS and ida_bytes.is_code(ida_bytes.get_flags(h)):
            ida_name.set_name(ea, SIGS[ida_bytes.get_dword(h)])
```

**Auto-comment**

```python
idc.set_cmt(ea, "License check: accepts any key whose CRC32 == 0", 0)
```

**Decrypt strings in place**

```python
def deob(ea, n, key):
    data = bytearray(ida_bytes.get_bytes(ea, n))
    out = bytes(b ^ key for b in data)
    ida_bytes.patch_bytes(ea, out)
    idc.set_cmt(ea, "decrypted: " + out.decode("latin1"), 0)
```

**Emulate a function**

```python
import ida_emulate as emu  # IDA 8.4+; otherwise use unicorn directly
```

## Batch export

```python
import json
out = []
for ea in idautils.Functions():
    f = ida_funcs.get_func(ea)
    out.append({"ea": ea, "name": ida_funcs.get_func_name(ea),
                "size": f.end_ea - f.start_ea,
                "callers": [x.frm for x in idautils.XrefsTo(ea, 0)]})
json.dump(out, open("funcs.json", "w"), indent=1)
```

## Pitfalls

- `idautils.XrefsTo(ea, 0)` misses flow xrefs; pass `idautils.XrefsNoFlow` semantics by filtering `xref.iscode`.
- Writing to the database in a loop without `ida_bytes.patch_bytes` leaves the disassembly stale — call `ida_auto.auto_make_code` after.
- Plugin imports at module import time break IDA startup; import lazily inside `run()`.

## Verification

Run the same script twice — output must be idempotent. Compare renamed counts against the function count before/after.
