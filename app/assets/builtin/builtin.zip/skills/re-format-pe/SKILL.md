---
name: re-format-pe
description: "Windows PE file format analysis: DOS/NT headers, sections, data directories, imports, exports, relocations, TLS, resources, and how to manipulate each field. Use this skill when parsing or patching PE files, building loaders, or diagnosing malformed PE structures."
---

# PE Format

## Overview

A PE file is a DOS stub, an `IMAGE_NT_HEADERS` (FileHeader + OptionalHeader), a section table, and section data addressed by RVAs through data directories. Everything a loader does is described there.

## Layout

```c
IMAGE_DOS_HEADER        // e_lfanew -> NT headers
IMAGE_NT_HEADERS {
  Signature "PE\0\0"
  IMAGE_FILE_HEADER     // Machine, NumberOfSections, SizeOfOptionalHeader, Characteristics
  IMAGE_OPTIONAL_HEADER // Magic 0x10b (PE32) / 0x20b (PE32+), ImageBase, EntryPoint,
                        // SectionAlignment, FileAlignment, SizeOfImage, DataDirectory[16]
}
IMAGE_SECTION_HEADER[]  // Name, VirtualSize, VirtualAddress, SizeOfRawData, PointerToRawData, Characteristics
```

**RVA → file offset**

```python
def rva_to_off(pe, rva):
    for s in pe.sections:
        if s.VirtualAddress <= rva < s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (rva - s.VirtualAddress)
    raise ValueError("rva outside sections")
```

## Data directories

| Index | Directory |
|---|---|
| 0 | Export |
| 1 | Import |
| 2 | Resource |
| 3 | Exception |
| 4 | Security (file offset, not RVA) |
| 5 | Base relocation |
| 6 | Debug |
| 7 | Architecture |
| 8 | Global pointer |
| 9 | TLS |
| 10 | Load config |
| 11 | Bound import |
| 12 | IAT |
| 13 | Delay import |
| 14 | CLR (.NET) |
| 15 | Reserved |

## Parse with pefile

```python
import pefile
pe = pefile.PE("target.exe")
print(hex(pe.OPTIONAL_HEADER.ImageBase), hex(pe.OPTIONAL_HEADER.AddressOfEntryPoint))
for s in pe.sections:
    print(s.Name.rstrip(b"\0"), hex(s.VirtualAddress), hex(s.SizeOfRawData), s.get_entropy())
for imp in pe.DIRECTORY_ENTRY_IMPORT:
    print(imp.dll.decode(), [i.name for i in imp.imports][:5])
```

## Common manipulations

**Add a section** — align `SizeOfRawData` to `FileAlignment`, `VirtualSize` to `SectionAlignment`, update `NumberOfSections`, `SizeOfImage`.

**Repoint entrypoint** — set `AddressOfEntryPoint` to the new RVA and make the section `IMAGE_SCN_MEM_EXECUTE`.

**Rebuild imports** — write a new import descriptor array plus the ILT/IAT and thunk data, point directory 1 at it.

**TLS callbacks** — directory 9 → `IMAGE_TLS_DIRECTORY` → `AddressOfCallBacks` is a VA array of callbacks that run before entrypoint.

## Malformed-PE indicators

- Section with `VirtualSize` 0 but nonzero raw data.
- `SizeOfImage` smaller than the highest section end.
- Import directory pointing into a section with `IMAGE_SCN_MEM_WRITE`.
- Entrypoint outside any section (process hollowing artifact).
- Overlay data after the last section (appended payload).

## Pitfalls

- 32-bit vs 64-bit optional header changes every field offset — read `Magic` first.
- `SizeOfRawData` can be 0 for `.bss`; never read file bytes for it.
- Checksum is often wrong and ignored by the loader; do not use it as an integrity signal.

## Verification

`pefile` reparse plus `objdump -x` must agree on entrypoint, section count, and import list.
