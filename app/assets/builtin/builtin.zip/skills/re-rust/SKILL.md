---
name: re-rust
description: "Reversing Rust binaries: name mangling, monomorphization, iterator and Option/Result layouts, panic paths, and identifying crate structure. Use this skill when the target is compiled Rust and symbol recovery or argument passing differs from C conventions."
---

# Rust Binary Reversing

## Overview

Rust binaries are large, heavily monomorphized, and use `v0` or legacy mangling. `Option`/`Result` use niche optimization, so argument passing is not always obvious.

## Identify

```bash
strings app | grep -m3 -E "rustc|/rustc/|\.cargo/registry"
strings app | grep -m3 "panicked at"
```

## Demangle

```bash
nm app | rustfilt | grep -i main
c++filt -s rust app
# v0 mangling (Rust 1.60+ default for -C symbol-mangling-version=v0)
rustfilt --no-legacy app
```

Legacy: `_ZN<len><crate><len><module>...<len><fn>17h<hash>E`.
v0: `_RNvNtNtCs<hash>_<crate>...`.

## Crate identification

```bash
strings app | grep -oE "[a-z0-9_]+-[0-9]+\.[0-9]+\.[0-9]+" | sort -u | head -20
```

Registry paths leak dependency names and versions.

## Type layouts

```rust
Option<&T>   -> *const T (null = None)          // niche
Option<u32>  -> u32 + discriminant (8 bytes)
Result<T,E>  -> tag + max(sizeof(T), sizeof(E)) union
String       -> { ptr, cap, len }               // 3 words, NOT NUL-terminated
&str         -> { ptr, len }                    // fat pointer, 2 words
Vec<T>       -> { ptr, cap, len }               // 3 words
```

`Box<T>` is a plain pointer. `Rc`/`Arc` point to `{ strong, weak, value }`.

## Code idioms

| Pattern | Meaning |
|---|---|
| `CALL core::panicking::panic_bounds_check` | slice index out of bounds |
| `CALL alloc::alloc::handle_alloc_error` | allocation failure |
| `LEA rdi, [rip+..]` + `MOV esi, len` + call | `&str` argument |
| repeated identical functions | monomorphized generics |
| `test rax, rax; je` right after a call | `Option`/`Result` check |

Monomorphization means one source function becomes N copies — match by structure, not address.

## Iterator chains

`Iterator` adapters compile to state machines with a `next()` method on a generated struct. Identifying them requires matching the vtable call (`call [rax+0x18]`) and the generated type name if symbols survive.

## Panic strings

`"panicked at src/main.rs:42:5"` gives source file, line, and column — the single most useful signal in a stripped Rust binary. Grep and map strings to code addresses via xrefs.

```bash
strings -t x app | grep "panicked at"
```

## Pitfalls

- Legacy vs v0 mangling requires different demanglers; `c++filt` fails on v0.
- Inlining across crates erases boundaries; only panic locations survive.
- `Option<NonZero*>` is pointer-sized with no tag — reading a tag byte gives garbage.

## Verification

A recovered function's argument widths must match the Rust type layout: `String` takes 3 words, `&str` takes 2, not 1.
