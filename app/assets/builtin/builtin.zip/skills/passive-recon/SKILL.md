---
name: passive-recon
description: "Passive reconnaissance: gathering intelligence without touching the target, using public sources, archives, and third-party data. Use this skill when stealth matters or before active scanning."
---

# Passive Recon

## Overview

No packets to the target. Sources: DNS, certificate transparency, archives, search engines, code repositories, breach data.

## DNS and certificates

```bash
dig +short target.com ANY
dig +short _dmarc.target.com TXT
dig +short target.com TXT | grep -i spf
curl -s "https://crt.sh/?q=%25.target.com&output=json" | jq -r '.[].name_value' | sort -u
```

Certificate SANs reveal sibling domains.

## Archives

```bash
curl -s "http://web.archive.org/cdx/search/cdx?url=target.com*&output=text&fl=original&collapse=urlkey" | head -100
gau --subs target.com
waybackurls target.com
```

Old URLs expose removed endpoints, debug pages, and API versions.

## Search engines

```
site:target.com -www
site:target.com filetype:pdf
site:target.com inurl:admin
"target.com" password
"@target.com" -site:target.com
```

## Code repositories

```bash
trufflehog github --org=target --only-verified
gitleaks detect --source=repo
# manual
github.com/search?q=org:target+password
```

## Breach / credential data

```bash
haveibeenpwned.com/API/v3/breachedaccount/user@target.com
dehashed.com (paid)
```

## Infrastructure

```bash
# ASN and netblocks
whois -h whois.radb.net AS12345
# reverse IP
curl "https://api.hackertarget.com/reverseiplookup/?q=1.2.3.4"
# shodan / censys
shodan search "org:Target Inc"
```

Shodan/Censys reveal exposed services without touching the host.

## Social

- LinkedIn: org chart, tech stack mentions in job postings.
- Job ads: "experience with Jenkins, AWS, Kubernetes" reveals infrastructure.
- GitHub org members: personal repos may leak internal code.

## Pitfalls

- crt.sh is rate-limited; cache results.
- Archive data may be years old — verify before relying.
- Breach data is sensitive; handle per engagement rules.

## Verification

Each passive finding must be corroborated by a second source before it enters the attack plan.
