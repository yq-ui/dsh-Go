---
name: js-reverse
description: "Reversing JavaScript in web apps: bundle deobfuscation, source map recovery, hooking browser APIs, and reconstructing client-side logic. Use this skill when a web application's logic or signing algorithm lives in JavaScript."
---

# JavaScript Reversing

## Overview

Modern web apps ship minified bundles with client-side crypto, signing, and anti-bot logic. The workflow: locate the bundle, beautify, find the sink, hook the browser, reproduce.

## Locate

```bash
curl -s https://target/ | grep -oE 'src="[^"]+\.js"' | sort -u
# source maps
curl -s https://target/static/js/main.js | tail -2
# {"version":3,"sources":[...],"mappings":"..."}
```

```bash
curl -s https://target/static/js/main.js.map -o main.js.map
npx source-map-cli extract main.js.map out/
```

A published `.map` restores the original TypeScript — always check first.

## Beautify and search

```bash
npx js-beautify min.js -o pretty.js
grep -n "encrypt\|sign\|token\|md5\|sha256" pretty.js | head -20
```

## Runtime hooking (browser)

```javascript
// intercept the request builder
const origOpen = XMLHttpRequest.prototype.open;
XMLHttpRequest.prototype.open = function (m, u) {
  console.log("XHR", m, u);
  return origOpen.apply(this, arguments);
};
const origSend = XMLHttpRequest.prototype.send;
XMLHttpRequest.prototype.send = function (body) {
  console.log("BODY", body);
  return origSend.apply(this, arguments);
};
// fetch
const of = window.fetch;
window.fetch = function (...a) { console.log("FETCH", a); return of.apply(this, a); };
```

Hook crypto:

```javascript
const oe = CryptoJS.AES.encrypt;
CryptoJS.AES.encrypt = function (msg, key, cfg) {
  console.log("AES key", key.toString(), "msg", msg.toString());
  return oe.apply(this, arguments);
};
```

## Automated deobfuscation

```bash
npx webcrack -i obf.js -o out      # unpacks webpack + deobfuscates
npx deobfuscator -i obf.js -o clean.js
```

`webcrack` handles webpack bundles, string arrays, and control-flow flattening well.

## Headless execution

```javascript
// run the bundle in a sandbox and call the exported function
const { JSDOM } = require("jsdom");
const dom = new JSDOM(`<html></html>`, { runScripts: "outside-only" });
dom.window.eval(fs.readFileSync("bundle.js", "utf8"));
console.log(dom.window.sign("payload"));
```

## Common signing schemes

| Pattern | Where |
|---|---|
| `md5(params + secret)` | mobile/web APIs |
| HMAC-SHA256 with a constant | modern APIs |
| AES-CBC with a fixed IV | legacy APIs |
| Timestamp + nonce + hash | anti-replay |
| WebAssembly module | heavier logic |

## WASM in the browser

Find the module URL, download, then `wasm2wat` / `wasm-decompile` (see `re-wasm`).

## Anti-bot

- Debugger detection via `debugger;` loops — strip them or use DevTools "Deactivate breakpoints".
- `Function.prototype.toString` checks — hook and return the original.
- Environment checks (`navigator.webdriver`) — override before the bundle runs.

```javascript
Object.defineProperty(navigator, "webdriver", { get: () => false });
```

## Pitfalls

- Minified code reuses short names; search by string constants, not identifiers.
- `eval`-based loaders hide code from static search — hook `eval` and log.
- Service workers cache an old bundle; clear them before re-testing.

## Verification

The reproduced request must be accepted by the server (2xx), proving signature and payload construction are correct.
