---
name: re-drm
description: "DRM system analysis: content encryption, license acquisition, and playback pipeline reversing. Use this skill when analyzing DRM-protected media or software (Widevine, PlayReady, FairPlay, Denuvo-like schemes)."
---

# DRM Analysis

## Overview

A DRM system: encrypted content, a license server, a client that decrypts and renders, and a robustness layer. The interesting parts are the license exchange and the decryption path.

## Components

| System | Client component |
|---|---|
| Widevine (L1/L3) | CDM library (`libwvcdm.so`, `widevinecdm.dll`) |
| PlayReady | `microsoft.playready.dll` |
| FairPlay | `coremedia`, `AVFoundation` on Apple |
| Adobe Primetime | `primetime` module |
| Denuvo | `denuvo64.dll`, per-title VM |

## License exchange

```
client -> license server: { content_id, challenge (signed by device key) }
server -> client: { content_key (wrapped), policies }
```

The content key is wrapped to the device's key — it never appears in plaintext for L1.

## Where keys live

- **L3 software CDM** — content key in process memory after license processing; findable with a memory scan after the license is processed.
- **L1 hardware CDM** — keys in the TEE; not extractable.
- **PlayReady** — hardware or software; software path keeps keys in memory.
- **FairPlay** — keys in the secure enclave on iOS; software path on macOS uses a keybag.

## Decryption pipeline

```
encrypted segments -> AES-CTR (or CENC AES-CBC) with content key -> decoder
```

The content key is derived per sample: `key = AES-CMAC(key_id, iv)` in CENC. Hook the CTR loop or the decoder input.

```javascript
// find the CTR keystream: look for inc32 counter updates
Memory.scan(base, size, "01 00 00 00 00 00 00 00", { onMatch(m) { console.log(m); }, onComplete(){} });
```

## CENC / MP4

```bash
# inspect encryption boxes
mp4dump --verbosity 3 file.mp4 | grep -i -A5 "encv\|senc\|tenc"
```

`tenc` gives the default key ID and IV size; `senc` gives per-sample IVs. With the key, decrypt with `mp4decrypt`.

## Robustness

- Anti-debug, integrity checks on the CDM module.
- Obfuscated control flow inside the CDM.
- Secure path: decrypted frames never reach normal memory (L1 + HDCP).

## Pitfalls

- L1 content is designed to be unrecoverable; research focuses on protocol and robustness, not key extraction.
- Keys rotate per title and per session.
- Screen capture detection is separate from decryption.

## Verification

A recovered key must decrypt a sample into frames that match the expected output (compare a frame hash against a known-good decode).
