---
name: harness-writing
description: "Writing fuzzing harnesses: isolating target code, feeding input, resetting state, and maximizing coverage per execution. Use this skill when a fuzzer must be pointed at a library, parser, or binary function."
---

# Harness Writing

## Overview

A harness is the adapter between the fuzzer's byte blob and the target's API. Quality determines whether fuzzing finds anything.

## Principles

1. **Reach the parser.** The first bytes must be able to construct a valid-ish input.
2. **Stay in-process.** Fork per input is 100× slower.
3. **Reset state.** No globals surviving between iterations.
4. **Fail fast on invalid input.** But not so fast that you never explore.
5. **No network, no filesystem, no sleeps.**

## C/C++ harness

```c
int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    if (size < 8) return 0;
    ctx_t *ctx = ctx_new();
    if (!ctx) return 0;
    parse(ctx, data, size);
    ctx_free(ctx);
    return 0;
}
```

## Binary harness (no source)

- **afl-qemu-trace** with a file/argv interface.
- **Frida mode** (`afl-fuzz -O`) for closed binaries.
- **Custom driver**: load the binary as a library and call the target function directly.

```c
typedef int (*fn_t)(const char*, size_t);
void *h = dlopen("./libtarget.so", RTLD_NOW);
fn_t f = (fn_t)dlsym(h, "parse");
int LLVMFuzzerTestOneInput(const uint8_t *d, size_t n) { return f((const char*)d, n); }
```

## Persistent mode with AFL

```c
__AFL_INIT();
while (__AFL_LOOP(10000)) {
    ssize_t n = read(0, buf, sizeof buf);
    if (n <= 0) break;
    target(buf, n);
}
```

## Determinism

Any nondeterminism (time, random, thread scheduling) makes coverage unstable. Stub it:

```c
time_t time(time_t *t) { return 1600000000; }
int rand(void) { return 0; }
```

## Measuring harness quality

```bash
afl-showmap -o map -- ./target < seed | wc -l
```

Compare coverage with a realistic input vs a random blob. If they are the same, the harness is not reaching the parser.

## Pitfalls

- A harness that validates magic bytes and returns early fuzzes nothing — feed the magic as a constant prefix.
- Leaking memory per iteration eventually OOMs; free everything.
- Catching all exceptions hides bugs; catch only the expected parse errors.

## Verification

Coverage with a valid seed must be substantially higher than with an invalid one.
