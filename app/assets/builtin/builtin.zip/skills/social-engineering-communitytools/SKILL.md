---
name: social-engineering-communitytools
description: "Social engineering tooling and resources: pretext frameworks, OSINT for targeting, and community tools for authorized assessments. Use this skill when planning the human layer of an engagement."
---

# SE Tooling

## Overview

Social engineering tools fall into: OSINT (who to target), pretext (what to say), and delivery (how to reach them).

## OSINT for targeting

```bash
# emails
theHarvester -d target.com -b all
hunter.io / phonebook.cz
# org structure
linkedin (manual), rocketreach
# breaches
haveibeenpwned.com
dehashed.com
```

```bash
# email format discovery
python3 emailharvester.py -d target.com
```

## Pretext frameworks

| Framework | Use |
|---|---|
| `Social-Engineer Toolkit (SET)` | credential harvesting, payload delivery |
| `Gophish` | campaign management with reporting |
| `evilginx2` | reverse-proxy phishing, MFA bypass |
| `Modlishka` | similar proxy approach |
| `King Phisher` | campaign server |

```bash
# Gophish
./gophish
# UI at https://127.0.0.1:3333
# create: sending profile -> landing page -> email template -> group -> campaign
```

## Payload delivery

```bash
# macro document
# LNK file
# ISO/IMG container (bypasses Mark-of-the-Web)
# HTML smuggling
```

HTML smuggling embeds a base64 blob in JS that writes a file client-side — bypasses email attachment scanning.

## Phone / vishing

- Caller ID spoofing (requires authorization and a provider).
- IVR cloning for pretext.
- Always record consent per the engagement rules.

## Physical

- Badge cloning (see `radio-sdr` for RFID).
- Tailgating pretexts.
- Lock bypass tools.

## Reporting

Track: target, pretext, channel, outcome, time. The report measures human resilience, not individual blame.

## Pitfalls

- Tools are irrelevant without a credible pretext.
- Over-automation produces obviously fake messages.
- Legal boundaries are strict — written authorization for every channel.

## Verification

Each technique must be authorized, scoped, and its results documented.
