---
name: re-frida-script-author
description: "Authoring robust Frida scripts: targeting by pattern instead of hardcoded offsets, handling overloads and ABI details, structuring multi-hook scripts, and shipping reusable instrumentation. Use this skill when writing a Frida script that must survive multiple app versions or hook many functions at once."
---

# Frida Script Authoring

## Overview

A good Frida script survives a rebuild. That means: resolve by pattern, verify before hooking, fail loudly but not fatally, and keep hooks independent.

## Structure

```javascript
// 1. resolve
// 2. verify
// 3. hook
// 4. report

function resolve(module, pattern) {
  const m = Process.getModuleByName(module);
  let hit = null;
  Memory.scanSync(m.base, m.size, pattern).forEach(x => { if (!hit) hit = x.address; });
  return hit;
}

const target = resolve("libfoo.so", "F0 4F BD A9 ?? ?? ?? ?? F4 4F 01 A9");
if (!target) { console.log("[!] pattern not found"); } else {
  Interceptor.attach(target, {
    onEnter(args) { console.log("[+] enter", args[0]); }
  });
}
```

Scan patterns with `??` wildcards; anchor them on prologue bytes plus a distinctive constant so a compiler update does not shift the match.

## Robust Java hooks

```javascript
setTimeout(function () {
  Java.perform(function () {
    let C;
    try { C = Java.use("com.app.net.Api"); } catch (e) { console.log("[!] class missing"); return; }
    C.request.overloads.forEach(function (o) {
      o.implementation = function () {
        const r = o.apply(this, arguments);
        console.log("[api]", o.argumentTypes.map(t => t.className).join(","), "->", r);
        return r;
      };
    });
  });
}, 0);
```

Hook **all overloads** unless you have a reason not to — a missed overload is the most common silent failure.

## ABI argument mapping

| Platform | args[i] |
|---|---|
| x86-64 SysV | rdi, rsi, rdx, rcx, r8, r9 |
| Windows x64 | rcx, rdx, r8, r9 |
| ARM64 | x0..x7 |
| ARM32 | r0..r3 |

For 32-bit ARM with `long long`, arguments split across register pairs.

## Native function replacement with state

```javascript
const orig = new NativeFunction(addr, "int", ["pointer", "int"]);
const hook = new NativeCallback(function (p, n) {
  const s = p.readUtf8String();
  console.log("[str]", s);
  return orig(p, n);
}, "int", ["pointer", "int"]);
Interceptor.replace(addr, hook);
```

## Passing data to the host

```javascript
send({ tag: "dump", addr: this.ptr.toString(), hex: hexdump(this.buf, { ansi: false }) });
```

```python
script.on("message", lambda m, d: open("dump.bin","wb").write(d) if d else print(m))
```

Binary payloads should go through the second callback argument, not JSON.

## Self-verifying scripts

```javascript
function must(cond, msg) {
  if (!cond) { send({ error: msg }); throw new Error(msg); }
}
```

Throwing inside `onEnter` kills only that hook's callback in recent Frida versions; prefer `try/catch` and `console.log`.

## Anti-detection hygiene

- Rename `frida-server` and change the default port (`frida-server -l 0.0.0.0:4444`).
- Avoid `frida-trace` on protected apps; default thread names are scanned.
- Patch `strstr` for "frida" / "gum" when hooking hardened targets.

## Verification

Run the script against two versions of the app; the resolve step must Succeed on both and report which pattern matched.
