---
name: re-go
description: "Reversing Go binaries: buildinfo, pclntab symbol recovery, goroutine and interface layout, and idiomatic Go code patterns in disassembly. Use this skill when the target is compiled with Go and standard C-oriented assumptions fail."
---

# Go Binary Reversing

## Overview

Go binaries are statically linked by default, huge (1–20 MB minimum), and keep a full function name table in `pclntab` even when stripped. Runtime structures (goroutines, interfaces, maps, strings) have fixed layouts you must know to read arguments.

## Identify

```bash
strings app | grep -m1 "go1\."
go version -m app          # module path, deps, build flags, VCS revision
go tool buildid app
```

## Symbol recovery

```bash
go tool nm app | head -20         # works even on stripped (pclntab)
go tool objdump -s main.main app
```

Tools for stripped binaries: `redress`, `GoReSym`, `go_parser` (IDA), `golang_loader_assist` (Ghidra).

```bash
GoReSym -t -d app > syms.json
```

## String layout

```go
type string struct {
  ptr *byte
  len int
}
```

Passed in two registers on amd64: `(rax=ptr, rbx=len)`. Not a NUL-terminated C string — reading it as `char*` gives garbage past the length.

```go
type slice struct { ptr *T; len, cap int }   // 3 words, register-returned
```

## Interface layout

```go
type iface struct { tab *itab; data unsafe.Pointer }
type itab struct { inter *interfacetype; _type *_type; hash uint32; fun [1]uintptr }
```

A method call goes through `itab.fun[n]`; the index maps to the interface method order (sorted alphabetically!). To identify which method is called, resolve the interface type, list methods alphabetically, index in.

## Goroutines

`runtime.g` structure at `FS`/`GS` base (`g` register is R14 on amd64 Go 1.17+, previously TLS). Key fields: `goid`, `stack`, `m`, `sched` (saved PC/SP).

```asm
MOVQ 0x1520(R14), AX    ; g.m
```

Multiplexed goroutines make the call stack hard to follow — use `runtime.gopanic` / `runtime.newproc` as anchors.

## Common idioms in disassembly

| Pattern | Meaning |
|---|---|
| `CMPQ SP, 0x10(R14); JBE morestack` | stack growth check, function prologue |
| `CALL runtime.newobject` | allocation |
| `CALL runtime.mapaccess1_faststr` | map lookup with string key |
| `CALL runtime.convT64` | boxing an int into an interface |
| `CALL runtime.growslice` | append |
| `MOVUPS xmm, 0(SP)` | bulk copy (memmove inline) |

## Decompiler notes

Go's ABI (register-based since 1.17) confuses older decompilers. IDA 8.3+/Ghidra 10.3+ handle it. Set the ABI to "Go internal" if the option exists, otherwise expect phantom stack variables.

## Pitfalls

- Go 1.17+ uses register ABI: arguments are in `RAX, RBX, RCX, RDI, RSI, R8-R11`, not on the stack.
- Panics show `runtime.gopanic` — trace the defer chain to find the actual check.
- `-ldflags "-s -w"` strips DWARF but not `pclntab`.

## Verification

`go tool nm` symbol list must cover the address you are analyzing; if not, GoReSym's recovered table should.
