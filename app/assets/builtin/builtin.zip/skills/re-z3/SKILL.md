---
name: re-z3
description: "Constraint solving with Z3: modeling a check as satisfiability, encoding arithmetic and bit-vector operations, and extracting a solution. Use this skill when a validation routine can be expressed as constraints."
---

# Z3

## Overview

Z3 solves constraints. Reverse engineering use: transcribe a check into bit-vector expressions, then `check()` and `model()`.

## Basic

```python
from z3 import *

flag = [BitVec(f"c{i}", 8) for i in range(16)]
s = Solver()
for c in flag:
    s.add(c >= 0x20, c <= 0x7e)

# checks from the binary
s.add(flag[0] == ord("f"))
acc = BitVecVal(0, 32)
for c in flag:
    acc = acc * 31 + ZeroExt(24, c)
s.add(acc == 0x12345678)

print(s.check())
m = s.model()
print("".join(chr(m[c].as_long()) for c in flag))
```

## Bit-vectors

```python
x = BitVec("x", 32)
s.add((x << 3) ^ 0xDEADBEEF == 0x12345678)
```

Operations: `+ - * / % << >> LShR & | ^ ~` and comparisons `== != < <=`.

Zero/sign extension: `ZeroExt(24, byte_var)` for a byte into 32 bits; `SignExt` for signed.

## Extracting expressions from assembly

```python
# mov eax, [x]      -> x
# add eax, 5        -> x + 5
# imul eax, eax, 31 -> x * 31
# xor eax, 0xDEAD   -> x ^ 0xDEAD
# shr eax, 3        -> LShR(x, 3)
# sar eax, 3        -> x >> 3
```

Build one expression per output check, then solve.

## Loop unrolling

```python
def transform(inp):
    acc = BitVecVal(0, 32)
    for c in inp:
        acc = (acc ^ ZeroExt(24, c)) * 0x01000193 & 0xFFFFFFFF
    return acc
```

FNV-1a. Model each round explicitly; the solver handles it.

## Arrays (S-boxes)

```python
SBOX = Array("sbox", BitVecSort(8), BitVecSort(8))
for i, v in enumerate(table):
    SBOX = Store(SBOX, i, v)
out = Select(SBOX, x)
```

## Optimization

```python
o = Optimize()
o.add(...)
o.minimize(flag[15])
```

## Common problems

| Symptom | Fix |
|---|---|
| `unknown` | nonlinear integer arithmetic; switch to BitVec, add bounds |
| slow | reduce variables, add intermediate constraints |
| unsat | transcription error — check operator direction and width |

## Pitfalls

- Mixing `Int` and `BitVec` produces errors; pick one.
- Python integers do not wrap: mask with `& 0xFFFFFFFF` and use `BitVecVal`.
- A correct model does not guarantee a *valid* input — add charset constraints.

## Verification

Feed the model back through the original binary; it must pass.
